import { useState, useEffect } from 'react';
import { createPortal } from 'react-dom';
import {
  X, Car, Users, Briefcase, MapPin, Calendar, Clock, ArrowRight,
  User, Mail, Phone, CreditCard, CheckCircle, Plane, Shield, Sparkles
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import { BookingAction } from '../lib/travelAgent';

interface TransferBookingModalProps {
  isOpen: boolean;
  onClose: () => void;
  bookingData: BookingAction;
  onComplete: (reference: string) => void;
}

const AIRPORT_NAMES: Record<string, string> = {
  PUJ: 'Punta Cana International Airport',
  SDQ: 'Santo Domingo Las Americas Airport',
  LRM: 'La Romana International Airport',
  POP: 'Puerto Plata Gregorio Luperon Airport',
};

export function TransferBookingModal({ isOpen, onClose, bookingData, onComplete }: TransferBookingModalProps) {
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [reference, setReference] = useState('');
  const [animateIn, setAnimateIn] = useState(false);

  const [transferDetails, setTransferDetails] = useState({
    pickupDate: '',
    pickupTime: '',
    flightNumber: '',
    returnDate: '',
    returnTime: '',
    returnFlightNumber: '',
  });

  const [customerInfo, setCustomerInfo] = useState({
    name: '',
    email: '',
    phone: '',
    specialRequests: '',
  });

  const [paymentMethod, setPaymentMethod] = useState<'card' | 'ideal' | 'paypal' | 'cash'>('card');
  const [cardDetails, setCardDetails] = useState({
    number: '',
    expiry: '',
    cvc: '',
    name: '',
  });
  const [selectedBank, setSelectedBank] = useState('');

  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
      setStep(1);
      setReference('');
      setLoading(false);
      setTransferDetails({
        pickupDate: '',
        pickupTime: '',
        flightNumber: '',
        returnDate: '',
        returnTime: '',
        returnFlightNumber: '',
      });
      setCustomerInfo({
        name: '',
        email: '',
        phone: '',
        specialRequests: '',
      });
      setPaymentMethod('card');
      setCardDetails({
        number: '',
        expiry: '',
        cvc: '',
        name: '',
      });
      setSelectedBank('');
      setTimeout(() => setAnimateIn(true), 50);
    } else {
      document.body.style.overflow = 'unset';
      setAnimateIn(false);
    }
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isOpen]);

  if (!isOpen) return null;

  const isRoundTrip = bookingData.tripType === 'Round trip';

  const handleTransferSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setStep(2);
  };

  const handleCustomerSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setStep(3);
  };

  const handlePaymentSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const bookingRef = `TRF-${Date.now().toString(36).toUpperCase()}-${Math.random().toString(36).substring(2, 6).toUpperCase()}`;

      const orderData = {
        booking_type: 'airport_transfer',
        item_name: `${bookingData.vehicle} Transfer - ${bookingData.airport} to ${bookingData.hotel}`,
        quantity: 1,
        unit_price: bookingData.price,
        total_price: bookingData.price,
        customer_email: customerInfo.email,
        customer_name: customerInfo.name,
        check_in_date: transferDetails.pickupDate,
        check_out_date: isRoundTrip ? transferDetails.returnDate : null,
        payment_method: paymentMethod,
        status: 'confirmed',
        payment_status: 'paid',
        stripe_payment_id: `sim_${paymentMethod}_${Math.random().toString(36).substr(2, 9)}`,
        details: {
          phone: customerInfo.phone,
          airport: bookingData.airport,
          airportName: AIRPORT_NAMES[bookingData.airport],
          hotel: bookingData.hotel,
          region: bookingData.region,
          vehicle: bookingData.vehicle,
          passengers: bookingData.passengers,
          suitcases: bookingData.suitcases,
          tripType: bookingData.tripType,
          pickupTime: transferDetails.pickupTime,
          flightNumber: transferDetails.flightNumber,
          returnDate: transferDetails.returnDate,
          returnTime: transferDetails.returnTime,
          returnFlightNumber: transferDetails.returnFlightNumber,
          specialRequests: customerInfo.specialRequests,
          bookingReference: bookingRef,
        }
      };

      await supabase.from('orders').insert(orderData);
      await new Promise(resolve => setTimeout(resolve, 1500));

      setReference(bookingRef);
      setStep(4);
      onComplete(bookingRef);
    } catch (error) {
      console.error('Booking error:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatCardNumber = (value: string) => {
    const v = value.replace(/\s+/g, '').replace(/[^0-9]/gi, '');
    const matches = v.match(/\d{4,16}/g);
    const match = (matches && matches[0]) || '';
    const parts = [];
    for (let i = 0, len = match.length; i < len; i += 4) {
      parts.push(match.substring(i, i + 4));
    }
    return parts.length ? parts.join(' ') : value;
  };

  const formatExpiry = (value: string) => {
    const v = value.replace(/\s+/g, '').replace(/[^0-9]/gi, '');
    if (v.length >= 2) {
      return v.substring(0, 2) + '/' + v.substring(2, 4);
    }
    return v;
  };

  const renderStep = () => {
    switch (step) {
      case 1:
        return (
          <form onSubmit={handleTransferSubmit} className="space-y-6">
            <div className="bg-gradient-to-r from-blue-500/10 to-cyan-500/10 border border-blue-500/20 rounded-2xl p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-white/70 text-xs uppercase tracking-wider">Private Transfer</p>
                  <h3 className="text-white text-xl font-bold">{bookingData.vehicle}</h3>
                </div>
                <div className="text-right">
                  <p className="text-white/70 text-xs">Total</p>
                  <p className="text-2xl font-bold text-white">${bookingData.price}</p>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="bg-white/5 rounded-xl p-3 border border-white/10">
                <div className="flex items-center gap-2 mb-1">
                  <Plane className="w-4 h-4 text-blue-400" />
                  <span className="text-white/50 text-xs">From</span>
                </div>
                <p className="text-white font-medium text-sm truncate" title={AIRPORT_NAMES[bookingData.airport] || bookingData.airport}>
                  {AIRPORT_NAMES[bookingData.airport] || bookingData.airport}
                </p>
                <p className="text-white/40 text-xs">{bookingData.airport}</p>
              </div>
              <div className="bg-white/5 rounded-xl p-3 border border-white/10">
                <div className="flex items-center gap-2 mb-1">
                  <MapPin className="w-4 h-4 text-emerald-400" />
                  <span className="text-white/50 text-xs">To</span>
                </div>
                <p className="text-white font-medium text-sm truncate" title={bookingData.hotel}>{bookingData.hotel}</p>
                <p className="text-white/40 text-xs">{bookingData.region}</p>
              </div>
              <div className="bg-white/5 rounded-xl p-3 border border-white/10">
                <div className="flex items-center gap-2 mb-1">
                  <Users className="w-4 h-4 text-amber-400" />
                  <span className="text-white/50 text-xs">Passengers</span>
                </div>
                <p className="text-white font-medium text-sm">{bookingData.passengers} people</p>
              </div>
              <div className="bg-white/5 rounded-xl p-3 border border-white/10">
                <div className="flex items-center gap-2 mb-1">
                  <Briefcase className="w-4 h-4 text-cyan-400" />
                  <span className="text-white/50 text-xs">Luggage</span>
                </div>
                <p className="text-white font-medium text-sm">{bookingData.suitcases} bags</p>
              </div>
            </div>

            <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-blue-500/10 border border-blue-500/20 rounded-full">
              <ArrowRight className="w-3.5 h-3.5 text-blue-400" />
              <span className="text-blue-400 text-sm font-medium">{bookingData.tripType}</span>
            </div>

            <div className="space-y-4">
              <h4 className="text-white font-semibold flex items-center gap-2">
                <Calendar className="w-4 h-4 text-blue-400" />
                Arrival Details
              </h4>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-white/60 text-xs mb-2">Pickup Date</label>
                  <input
                    type="date"
                    value={transferDetails.pickupDate}
                    onChange={(e) => setTransferDetails({ ...transferDetails, pickupDate: e.target.value })}
                    required
                    min={new Date().toISOString().split('T')[0]}
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500/50 transition-all"
                  />
                </div>
                <div>
                  <label className="block text-white/60 text-xs mb-2">Pickup Time</label>
                  <input
                    type="time"
                    value={transferDetails.pickupTime}
                    onChange={(e) => setTransferDetails({ ...transferDetails, pickupTime: e.target.value })}
                    required
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500/50 transition-all"
                  />
                </div>
              </div>

              <div>
                <label className="block text-white/60 text-xs mb-2">Flight Number (optional)</label>
                <div className="relative">
                  <Plane className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/40" />
                  <input
                    type="text"
                    value={transferDetails.flightNumber}
                    onChange={(e) => setTransferDetails({ ...transferDetails, flightNumber: e.target.value.toUpperCase() })}
                    placeholder="e.g., AA1234"
                    className="w-full bg-white/5 border border-white/10 rounded-xl pl-10 pr-4 py-3 text-white text-sm placeholder-white/30 focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500/50 transition-all"
                  />
                </div>
              </div>

              {isRoundTrip && (
                <>
                  <h4 className="text-white font-semibold flex items-center gap-2 pt-2">
                    <Calendar className="w-4 h-4 text-emerald-400" />
                    Return Details
                  </h4>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-white/60 text-xs mb-2">Return Date</label>
                      <input
                        type="date"
                        value={transferDetails.returnDate}
                        onChange={(e) => setTransferDetails({ ...transferDetails, returnDate: e.target.value })}
                        required
                        min={transferDetails.pickupDate || new Date().toISOString().split('T')[0]}
                        className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/50 focus:border-emerald-500/50 transition-all"
                      />
                    </div>
                    <div>
                      <label className="block text-white/60 text-xs mb-2">Return Time</label>
                      <input
                        type="time"
                        value={transferDetails.returnTime}
                        onChange={(e) => setTransferDetails({ ...transferDetails, returnTime: e.target.value })}
                        required
                        className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/50 focus:border-emerald-500/50 transition-all"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-white/60 text-xs mb-2">Return Flight Number (optional)</label>
                    <div className="relative">
                      <Plane className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/40" />
                      <input
                        type="text"
                        value={transferDetails.returnFlightNumber}
                        onChange={(e) => setTransferDetails({ ...transferDetails, returnFlightNumber: e.target.value.toUpperCase() })}
                        placeholder="e.g., AA5678"
                        className="w-full bg-white/5 border border-white/10 rounded-xl pl-10 pr-4 py-3 text-white text-sm placeholder-white/30 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 focus:border-emerald-500/50 transition-all"
                      />
                    </div>
                  </div>
                </>
              )}
            </div>

            <button
              type="submit"
              className="w-full py-4 rounded-xl bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white font-semibold transition-all shadow-lg shadow-blue-500/25 hover:shadow-blue-500/40 flex items-center justify-center gap-2"
            >
              Continue
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>
        );

      case 2:
        return (
          <form onSubmit={handleCustomerSubmit} className="space-y-6">
            <div className="text-center mb-2">
              <div className="w-14 h-14 rounded-full bg-gradient-to-br from-blue-500/20 to-cyan-500/20 flex items-center justify-center mx-auto mb-3">
                <User className="w-7 h-7 text-blue-400" />
              </div>
              <h3 className="text-white text-lg font-semibold">Contact Information</h3>
              <p className="text-white/50 text-sm">How can we reach you?</p>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-white/60 text-xs mb-2">Full Name</label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/40" />
                  <input
                    type="text"
                    value={customerInfo.name}
                    onChange={(e) => setCustomerInfo({ ...customerInfo, name: e.target.value })}
                    required
                    placeholder="John Smith"
                    className="w-full bg-white/5 border border-white/10 rounded-xl pl-10 pr-4 py-3 text-white text-sm placeholder-white/30 focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500/50 transition-all"
                  />
                </div>
              </div>

              <div>
                <label className="block text-white/60 text-xs mb-2">Email Address</label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/40" />
                  <input
                    type="email"
                    value={customerInfo.email}
                    onChange={(e) => setCustomerInfo({ ...customerInfo, email: e.target.value })}
                    required
                    placeholder="john@email.com"
                    className="w-full bg-white/5 border border-white/10 rounded-xl pl-10 pr-4 py-3 text-white text-sm placeholder-white/30 focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500/50 transition-all"
                  />
                </div>
              </div>

              <div>
                <label className="block text-white/60 text-xs mb-2">Phone Number</label>
                <div className="relative">
                  <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/40" />
                  <input
                    type="tel"
                    value={customerInfo.phone}
                    onChange={(e) => setCustomerInfo({ ...customerInfo, phone: e.target.value })}
                    required
                    placeholder="+1 555 123 4567"
                    className="w-full bg-white/5 border border-white/10 rounded-xl pl-10 pr-4 py-3 text-white text-sm placeholder-white/30 focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500/50 transition-all"
                  />
                </div>
              </div>

              <div>
                <label className="block text-white/60 text-xs mb-2">Special Requests (optional)</label>
                <textarea
                  value={customerInfo.specialRequests}
                  onChange={(e) => setCustomerInfo({ ...customerInfo, specialRequests: e.target.value })}
                  placeholder="Child seat, wheelchair access, extra stops..."
                  rows={3}
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white text-sm placeholder-white/30 focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500/50 transition-all resize-none"
                />
              </div>
            </div>

            <div className="flex gap-3">
              <button
                type="button"
                onClick={() => setStep(1)}
                className="flex-1 py-3 rounded-xl bg-white/5 border border-white/10 text-white font-medium hover:bg-white/10 transition-all"
              >
                Back
              </button>
              <button
                type="submit"
                className="flex-1 py-3 rounded-xl bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white font-semibold transition-all shadow-lg shadow-blue-500/25 flex items-center justify-center gap-2"
              >
                Continue
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </form>
        );

      case 3:
        return (
          <form onSubmit={handlePaymentSubmit} className="space-y-6">
            <div className="text-center mb-2">
              <div className="w-14 h-14 rounded-full bg-gradient-to-br from-emerald-500/20 to-teal-500/20 flex items-center justify-center mx-auto mb-3">
                <CreditCard className="w-7 h-7 text-emerald-400" />
              </div>
              <h3 className="text-white text-lg font-semibold">Payment</h3>
              <p className="text-white/50 text-sm">Secure checkout</p>
            </div>

            <div className="bg-gradient-to-r from-blue-500/10 to-cyan-500/10 border border-blue-500/20 rounded-xl p-4">
              <div className="flex justify-between items-center">
                <div>
                  <p className="text-white/60 text-xs">Total Amount</p>
                  <p className="text-2xl font-bold text-white">${bookingData.price} USD</p>
                </div>
                <div className="flex items-center gap-1.5 text-emerald-400">
                  <Shield className="w-4 h-4" />
                  <span className="text-xs font-medium">Secure</span>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-4 gap-2">
              {(['card', 'ideal', 'paypal', 'cash'] as const).map((method) => (
                <button
                  key={method}
                  type="button"
                  onClick={() => setPaymentMethod(method)}
                  className={`p-3 rounded-xl border-2 transition-all ${
                    paymentMethod === method
                      ? 'bg-blue-500/20 border-blue-500/50 text-blue-400'
                      : 'bg-white/5 border-white/10 text-white/60 hover:bg-white/10 hover:border-white/20'
                  }`}
                >
                  <span className="text-sm font-medium">
                    {method === 'card' ? 'Card' : method === 'ideal' ? 'iDEAL' : method === 'paypal' ? 'PayPal' : 'Cash'}
                  </span>
                </button>
              ))}
            </div>

            {paymentMethod === 'card' && (
              <div className="space-y-4">
                <div>
                  <label className="block text-white/60 text-xs mb-2">Card Number</label>
                  <input
                    type="text"
                    value={cardDetails.number}
                    onChange={(e) => setCardDetails({ ...cardDetails, number: formatCardNumber(e.target.value) })}
                    placeholder="4242 4242 4242 4242"
                    maxLength={19}
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white text-sm placeholder-white/30 focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500/50 transition-all font-mono"
                  />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-white/60 text-xs mb-2">Expiry</label>
                    <input
                      type="text"
                      value={cardDetails.expiry}
                      onChange={(e) => setCardDetails({ ...cardDetails, expiry: formatExpiry(e.target.value) })}
                      placeholder="MM/YY"
                      maxLength={5}
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white text-sm placeholder-white/30 focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500/50 transition-all font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-white/60 text-xs mb-2">CVC</label>
                    <input
                      type="text"
                      value={cardDetails.cvc}
                      onChange={(e) => setCardDetails({ ...cardDetails, cvc: e.target.value.replace(/\D/g, '') })}
                      placeholder="123"
                      maxLength={4}
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white text-sm placeholder-white/30 focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500/50 transition-all font-mono"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-white/60 text-xs mb-2">Cardholder Name</label>
                  <input
                    type="text"
                    value={cardDetails.name}
                    onChange={(e) => setCardDetails({ ...cardDetails, name: e.target.value.toUpperCase() })}
                    placeholder="JOHN SMITH"
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white text-sm placeholder-white/30 focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500/50 transition-all"
                  />
                </div>
              </div>
            )}

            {paymentMethod === 'ideal' && (
              <div className="space-y-4">
                <div className="flex items-center gap-3 bg-gradient-to-r from-pink-500/10 to-pink-600/10 border border-pink-500/20 rounded-xl p-3">
                  <div className="w-10 h-10 rounded-lg bg-white flex items-center justify-center flex-shrink-0">
                    <svg viewBox="0 0 24 24" className="w-6 h-6">
                      <circle cx="12" cy="12" r="10" fill="#CC0066" />
                      <path d="M7 12h10M12 7v10" stroke="white" strokeWidth="2" strokeLinecap="round" />
                    </svg>
                  </div>
                  <div>
                    <p className="text-white font-medium text-sm">iDEAL Payment</p>
                    <p className="text-white/50 text-xs">Secure Dutch bank transfer</p>
                  </div>
                </div>

                <div>
                  <label className="block text-white/60 text-xs mb-2">Select Your Bank</label>
                  <select
                    value={selectedBank}
                    onChange={(e) => setSelectedBank(e.target.value)}
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white text-sm focus:outline-none focus:ring-2 focus:ring-pink-500/50 focus:border-pink-500/50 transition-all appearance-none cursor-pointer"
                    style={{ backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 24 24' stroke='white'%3E%3Cpath stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M19 9l-7 7-7-7'%3E%3C/path%3E%3C/svg%3E")`, backgroundRepeat: 'no-repeat', backgroundPosition: 'right 12px center', backgroundSize: '20px' }}
                  >
                    <option value="" className="bg-slate-800">Choose your bank...</option>
                    <option value="abn_amro" className="bg-slate-800">ABN AMRO</option>
                    <option value="asn_bank" className="bg-slate-800">ASN Bank</option>
                    <option value="bunq" className="bg-slate-800">bunq</option>
                    <option value="ing" className="bg-slate-800">ING</option>
                    <option value="knab" className="bg-slate-800">Knab</option>
                    <option value="n26" className="bg-slate-800">N26</option>
                    <option value="nn" className="bg-slate-800">Nationale-Nederlanden</option>
                    <option value="rabobank" className="bg-slate-800">Rabobank</option>
                    <option value="regiobank" className="bg-slate-800">RegioBank</option>
                    <option value="revolut" className="bg-slate-800">Revolut</option>
                    <option value="sns_bank" className="bg-slate-800">SNS Bank</option>
                    <option value="triodos" className="bg-slate-800">Triodos Bank</option>
                    <option value="van_lanschot" className="bg-slate-800">Van Lanschot</option>
                    <option value="yoursafe" className="bg-slate-800">Yoursafe</option>
                  </select>
                </div>

                {selectedBank && (
                  <div className="bg-pink-500/10 border border-pink-500/20 rounded-xl p-4 animate-fadeIn">
                    <div className="flex items-center gap-3">
                      <CheckCircle className="w-5 h-5 text-pink-400" />
                      <div>
                        <p className="text-pink-400 font-medium text-sm">Ready to proceed</p>
                        <p className="text-pink-400/70 text-xs">You'll be redirected to your bank to authorize the payment of ${bookingData.price} USD</p>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}

            {paymentMethod === 'paypal' && (
              <div className="bg-white/5 rounded-xl p-6 text-center border border-white/10">
                <div className="w-12 h-12 rounded-full bg-blue-600/20 flex items-center justify-center mx-auto mb-3">
                  <span className="text-blue-400 font-bold text-lg">P</span>
                </div>
                <p className="text-white/60 text-sm mb-2">You will be redirected to PayPal</p>
                <p className="text-white font-semibold">${bookingData.price} USD</p>
              </div>
            )}

            {paymentMethod === 'cash' && (
              <div className="bg-amber-500/10 border border-amber-500/20 rounded-xl p-4">
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 rounded-full bg-amber-500/20 flex items-center justify-center flex-shrink-0">
                    <span className="text-amber-400">$</span>
                  </div>
                  <div>
                    <p className="text-amber-400 font-medium text-sm">Pay Cash to Driver</p>
                    <p className="text-amber-400/70 text-xs mt-1">Please have ${bookingData.price} USD ready upon arrival. Your driver will provide a receipt.</p>
                  </div>
                </div>
              </div>
            )}

            <div className="flex gap-3">
              <button
                type="button"
                onClick={() => setStep(2)}
                className="flex-1 py-3 rounded-xl bg-white/5 border border-white/10 text-white font-medium hover:bg-white/10 transition-all"
              >
                Back
              </button>
              <button
                type="submit"
                disabled={loading}
                className="flex-1 py-3 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 text-white font-semibold transition-all shadow-lg shadow-emerald-500/25 disabled:opacity-50 flex items-center justify-center gap-2"
              >
                {loading ? (
                  <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                ) : (
                  <>
                    Complete Booking
                    <CheckCircle className="w-4 h-4" />
                  </>
                )}
              </button>
            </div>
          </form>
        );

      case 4:
        return (
          <div className="text-center space-y-6 py-4">
            <div className="relative">
              <div className="w-20 h-20 rounded-full bg-gradient-to-br from-emerald-500/20 to-teal-500/20 flex items-center justify-center mx-auto animate-pulse">
                <CheckCircle className="w-10 h-10 text-emerald-400" />
              </div>
              <div className="absolute inset-0 flex items-center justify-center">
                <Sparkles className="w-6 h-6 text-amber-400 absolute -top-2 -right-8 animate-bounce" />
                <Sparkles className="w-4 h-4 text-blue-400 absolute -bottom-1 -left-6 animate-bounce delay-100" />
              </div>
            </div>

            <div>
              <h3 className="text-2xl font-bold text-white mb-2">Booking Confirmed!</h3>
              <p className="text-white/60">Your private transfer is all set</p>
            </div>

            <div className="bg-gradient-to-r from-emerald-500/10 to-teal-500/10 border border-emerald-500/20 rounded-xl p-4">
              <p className="text-white/50 text-xs mb-1">Confirmation Number</p>
              <p className="text-xl font-bold text-emerald-400 font-mono">{reference}</p>
            </div>

            <div className="bg-white/5 rounded-xl p-4 text-left space-y-3 border border-white/10">
              <div className="flex justify-between items-center gap-2">
                <span className="text-white/50 text-sm flex-shrink-0">Route</span>
                <span className="text-white text-sm font-medium text-right truncate">{bookingData.airport} → {bookingData.hotel}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-white/50 text-sm">Date</span>
                <span className="text-white text-sm font-medium">{transferDetails.pickupDate}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-white/50 text-sm">Time</span>
                <span className="text-white text-sm font-medium">{transferDetails.pickupTime}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-white/50 text-sm">Vehicle</span>
                <span className="text-white text-sm font-medium">{bookingData.vehicle}</span>
              </div>
              <div className="h-px bg-white/10" />
              <div className="flex justify-between items-center">
                <span className="text-white/50 text-sm">Total Paid</span>
                <span className="text-emerald-400 font-bold">${bookingData.price} USD</span>
              </div>
            </div>

            <div className="bg-blue-500/10 border border-blue-500/20 rounded-xl p-3">
              <p className="text-blue-400 text-sm">
                Confirmation sent to <span className="font-medium">{customerInfo.email}</span>
              </p>
            </div>

            <button
              onClick={onClose}
              className="w-full py-4 rounded-xl bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white font-semibold transition-all shadow-lg shadow-blue-500/25"
            >
              Done
            </button>
          </div>
        );

      default:
        return null;
    }
  };

  return createPortal(
    <div className="fixed inset-0 z-[9999] flex items-end sm:items-center justify-center">
      <div
        className={`absolute inset-0 bg-black/80 backdrop-blur-sm transition-opacity duration-300 ${
          animateIn ? 'opacity-100' : 'opacity-0'
        }`}
        onClick={step !== 4 ? onClose : undefined}
      />

      <div
        className={`relative w-full sm:max-w-md bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 rounded-t-3xl sm:rounded-3xl border-t sm:border border-white/10 shadow-2xl max-h-[92vh] sm:max-h-[90vh] overflow-hidden flex flex-col transition-all duration-500 ${
          animateIn ? 'translate-y-0 opacity-100' : 'translate-y-full sm:translate-y-8 opacity-0'
        }`}
      >
        <div className="flex items-center justify-between p-4 border-b border-white/10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center">
              <Car className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="text-white font-bold">Book Transfer</h2>
              {step < 4 && (
                <p className="text-white/50 text-xs">Step {step} of 3</p>
              )}
            </div>
          </div>

          {step !== 4 && (
            <button
              onClick={onClose}
              className="w-10 h-10 rounded-xl bg-white/5 hover:bg-white/10 flex items-center justify-center text-white/60 hover:text-white transition-all"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>

        {step < 4 && (
          <div className="px-4 pt-3">
            <div className="flex gap-1.5">
              {[1, 2, 3].map((s) => (
                <div
                  key={s}
                  className={`h-1 flex-1 rounded-full transition-all duration-500 ${
                    s < step ? 'bg-emerald-500' : s === step ? 'bg-blue-500' : 'bg-white/10'
                  }`}
                />
              ))}
            </div>
          </div>
        )}

        <div className="flex-1 overflow-y-auto p-4">
          {renderStep()}
        </div>
      </div>
    </div>,
    document.body
  );
}
