import { useState, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { X, Check } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { AirportPickupFlow } from './bookings/AirportPickupFlow';
import { HotelBookingFlow } from './bookings/HotelBookingFlow';
import { CarRentalFlow } from './bookings/CarRentalFlow';
import { TourActivityFlow } from './bookings/TourActivityFlow';
import { FlightBookingFlow } from './bookings/FlightBookingFlow';
import { CustomerInfoStep } from './bookings/CustomerInfoStep';
import { PaymentStep } from './bookings/PaymentStep';
import { SuccessStep } from './bookings/SuccessStep';

interface UnifiedBookingModalProps {
  isOpen: boolean;
  onClose: () => void;
  item: any;
  type: 'hotel' | 'service';
}

export function UnifiedBookingModal({ isOpen, onClose, item, type }: UnifiedBookingModalProps) {
  const [step, setStep] = useState(1);
  const [bookingData, setBookingData] = useState<any>(null);
  const [customerInfo, setCustomerInfo] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
      setStep(1);
      setBookingData(null);
      setCustomerInfo(null);
    } else {
      document.body.style.overflow = 'unset';
    }

    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isOpen]);

  if (!isOpen) return null;

  const getServiceType = () => {
    if (type === 'hotel') return 'hotel';
    return item.type;
  };

  const handleServiceDetailsComplete = (data: any) => {
    setBookingData(data);
    setStep(2);
  };

  const handleCustomerInfoComplete = (data: any) => {
    setCustomerInfo(data);
    setStep(3);
  };

  const handlePaymentComplete = async (paymentData: any) => {
    setLoading(true);

    try {
      const orderData = {
        booking_type: getServiceType(),
        reference_id: item.id,
        item_name: item.name,
        quantity: bookingData.quantity || 1,
        unit_price: type === 'hotel' ? item.price_per_night : item.price,
        total_price: bookingData.totalPrice,
        customer_email: customerInfo.customerEmail,
        customer_name: customerInfo.customerName,
        check_in_date: bookingData.checkInDate || bookingData.pickupDate || bookingData.departureDate || bookingData.activityDate || null,
        check_out_date: bookingData.checkOutDate || bookingData.returnDate || null,
        payment_method: paymentData.method,
        payment_details: paymentData.details,
        details: {
          phone: customerInfo.customerPhone,
          ...bookingData,
          customerRequests: customerInfo.specialRequests || bookingData.specialRequests,
          location: item.location
        }
      };

      const { data: order, error } = await supabase
        .from('orders')
        .insert(orderData)
        .select()
        .single();

      if (error) throw error;

      await new Promise(resolve => setTimeout(resolve, 1500));

      await supabase
        .from('orders')
        .update({
          status: 'confirmed',
          payment_status: 'paid',
          stripe_payment_id: `sim_${paymentData.method}_${Math.random().toString(36).substr(2, 9)}`
        })
        .eq('id', order.id);

      setStep(4);
    } catch (error) {
      console.error('Booking error:', error);
      alert('Booking failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const renderStepContent = () => {
    switch (step) {
      case 1:
        if (type === 'hotel') {
          return (
            <HotelBookingFlow
              hotel={item}
              onNext={handleServiceDetailsComplete}
              onBack={onClose}
            />
          );
        } else {
          const serviceType = getServiceType();

          switch (serviceType) {
            case 'airport_transfer':
              return (
                <AirportPickupFlow
                  service={item}
                  onNext={handleServiceDetailsComplete}
                  onBack={onClose}
                />
              );
            case 'car_rental':
              return (
                <CarRentalFlow
                  service={item}
                  onNext={handleServiceDetailsComplete}
                  onBack={onClose}
                />
              );
            case 'attraction':
              return (
                <TourActivityFlow
                  service={item}
                  onNext={handleServiceDetailsComplete}
                  onBack={onClose}
                />
              );
            case 'flight':
              return (
                <FlightBookingFlow
                  service={item}
                  onNext={handleServiceDetailsComplete}
                  onBack={onClose}
                />
              );
            default:
              return (
                <TourActivityFlow
                  service={item}
                  onNext={handleServiceDetailsComplete}
                  onBack={onClose}
                />
              );
          }
        }

      case 2:
        return (
          <CustomerInfoStep
            onNext={handleCustomerInfoComplete}
            onBack={() => setStep(1)}
          />
        );

      case 3:
        return (
          <PaymentStep
            item={item}
            bookingDetails={bookingData}
            totalPrice={bookingData.totalPrice}
            onBack={() => setStep(2)}
            onComplete={handlePaymentComplete}
            loading={loading}
          />
        );

      case 4:
        return (
          <SuccessStep
            item={item}
            bookingData={bookingData}
            customerInfo={customerInfo}
            totalPrice={bookingData.totalPrice}
            onClose={onClose}
          />
        );

      default:
        return null;
    }
  };

  return createPortal(
    <div className="fixed inset-0 z-[9999] overflow-hidden">
      <div
        className="absolute inset-0 bg-black/70 backdrop-blur-sm"
        onClick={step !== 4 ? onClose : undefined}
      />

      <div className="fixed inset-0 sm:inset-auto sm:top-1/2 sm:left-1/2 sm:-translate-x-1/2 sm:-translate-y-1/2 w-full h-full sm:w-full sm:max-w-lg sm:h-auto sm:max-h-[90vh] sm:rounded-3xl overflow-hidden z-10 animate-slideUp">
        <div className="w-full h-full bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 sm:border sm:border-white/20 shadow-2xl flex flex-col">
          <div
            className="flex-1 overflow-y-auto overscroll-contain"
            style={{
              WebkitOverflowScrolling: 'touch',
              paddingBottom: 'env(safe-area-inset-bottom, 0px)'
            }}
          >
            <div
              className="p-4 xs:p-5 sm:p-8 pb-6 sm:pb-8 relative min-h-full"
              style={{ paddingTop: 'max(1rem, env(safe-area-inset-top, 0px))' }}
            >
              {step !== 4 && (
                <button
                  onClick={onClose}
                  className="absolute top-3 right-3 xs:top-4 xs:right-4 w-9 h-9 xs:w-10 xs:h-10 rounded-full bg-white/10 hover:bg-white/20 active:bg-white/30 flex items-center justify-center text-gray-400 hover:text-white transition-all z-20 backdrop-blur-sm"
                  style={{ top: 'max(0.75rem, env(safe-area-inset-top, 0px))' }}
                >
                  <X className="w-5 h-5" />
                </button>
              )}

              {step !== 4 && (
                <div className="flex justify-center mb-5 xs:mb-6 sm:mb-8 pt-10 xs:pt-12 sm:pt-2">
                  <div className="flex items-center gap-1 xs:gap-1.5 sm:gap-2">
                    {[1, 2, 3, 4].map((stepNum) => (
                      <div key={stepNum} className="flex items-center">
                        <div className={`w-7 h-7 xs:w-8 xs:h-8 sm:w-9 sm:h-9 rounded-full flex items-center justify-center text-[11px] xs:text-xs sm:text-sm font-semibold transition-all ${
                          step >= stepNum
                            ? 'bg-gradient-to-br from-blue-500 to-blue-600 text-white shadow-lg shadow-blue-500/30'
                            : 'bg-white/10 text-gray-400'
                        }`}>
                          {step > stepNum ? <Check className="w-3.5 h-3.5 xs:w-4 xs:h-4" /> : stepNum}
                        </div>
                        {stepNum < 4 && (
                          <div className={`w-4 xs:w-6 sm:w-8 h-0.5 xs:h-1 mx-0.5 sm:mx-1 rounded-full transition-all ${
                            step > stepNum ? 'bg-gradient-to-r from-blue-500 to-blue-600' : 'bg-white/20'
                          }`} />
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {renderStepContent()}
            </div>
          </div>
        </div>
      </div>
    </div>,
    document.body
  );
}