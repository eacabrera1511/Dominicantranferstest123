import { useState, useEffect } from 'react';
import {
  Users, Building2, Calendar, TrendingUp, TrendingDown,
  DollarSign, Activity, Clock, AlertTriangle, ArrowUpRight,
  ArrowDownRight, Cpu, Zap, FileText
} from 'lucide-react';
import { supabase } from '../../lib/supabase';

interface MetricCardProps {
  title: string;
  value: string | number;
  change?: number;
  changeLabel?: string;
  icon: React.ElementType;
  color: string;
  prefix?: string;
  suffix?: string;
}

function MetricCard({ title, value, change, changeLabel, icon: Icon, color, prefix, suffix }: MetricCardProps) {
  const isPositive = change && change > 0;
  const colorClasses: Record<string, string> = {
    blue: 'from-blue-500 to-cyan-500',
    green: 'from-green-500 to-emerald-500',
    amber: 'from-amber-500 to-orange-500',
    red: 'from-red-500 to-rose-500',
    purple: 'from-fuchsia-500 to-pink-500',
  };

  return (
    <div className="bg-white/5 backdrop-blur-xl rounded-xl border border-white/10 p-5">
      <div className="flex items-start justify-between mb-3">
        <div className={`p-2.5 rounded-xl bg-gradient-to-br ${colorClasses[color]} bg-opacity-20`}>
          <Icon className="w-5 h-5 text-white" />
        </div>
        {change !== undefined && (
          <div className={`flex items-center gap-1 text-sm ${isPositive ? 'text-green-400' : 'text-red-400'}`}>
            {isPositive ? <ArrowUpRight className="w-4 h-4" /> : <ArrowDownRight className="w-4 h-4" />}
            {Math.abs(change).toFixed(1)}%
          </div>
        )}
      </div>
      <p className="text-gray-400 text-sm mb-1">{title}</p>
      <p className="text-2xl font-bold text-white">
        {prefix}{typeof value === 'number' ? value.toLocaleString() : value}{suffix}
      </p>
      {changeLabel && (
        <p className="text-gray-500 text-xs mt-1">{changeLabel}</p>
      )}
    </div>
  );
}

interface ChartBarProps {
  value: number;
  maxValue: number;
  label: string;
  color: string;
}

function ChartBar({ value, maxValue, label, color }: ChartBarProps) {
  const percentage = (value / maxValue) * 100;
  return (
    <div className="flex items-end gap-1 flex-1">
      <div className="flex-1 flex flex-col items-center">
        <div className="w-full bg-white/5 rounded-t-sm relative" style={{ height: '120px' }}>
          <div
            className={`absolute bottom-0 left-0 right-0 ${color} rounded-t-sm transition-all duration-500`}
            style={{ height: `${percentage}%` }}
          />
        </div>
        <span className="text-gray-500 text-xs mt-2">{label}</span>
      </div>
    </div>
  );
}

export function AdminOverview() {
  const [platformMetrics, setPlatformMetrics] = useState<any>(null);
  const [financialMetrics, setFinancialMetrics] = useState<any>(null);
  const [performanceMetrics, setPerformanceMetrics] = useState<any>(null);
  const [operationalMetrics, setOperationalMetrics] = useState<any>(null);
  const [weeklyData, setWeeklyData] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchMetrics();
  }, []);

  const fetchMetrics = async () => {
    const today = new Date().toISOString().split('T')[0];
    const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0];

    const [platformRes, financialRes, performanceRes, operationalRes, weeklyRes] = await Promise.all([
      supabase.from('platform_metrics').select('*').eq('metric_date', today).maybeSingle(),
      supabase.from('financial_metrics').select('*').eq('metric_date', today).maybeSingle(),
      supabase.from('performance_metrics').select('*').eq('metric_date', today).maybeSingle(),
      supabase.from('operational_metrics').select('*').eq('metric_date', today).maybeSingle(),
      supabase.from('financial_metrics').select('*').order('metric_date', { ascending: false }).limit(7),
    ]);

    const [platformYesterdayRes] = await Promise.all([
      supabase.from('platform_metrics').select('*').eq('metric_date', yesterday).maybeSingle(),
    ]);

    if (platformRes.data) {
      const yesterdayData = platformYesterdayRes.data;
      setPlatformMetrics({
        ...platformRes.data,
        dauChange: yesterdayData ? ((platformRes.data.daily_active_users - yesterdayData.daily_active_users) / yesterdayData.daily_active_users) * 100 : 0,
        partnerChange: yesterdayData ? ((platformRes.data.active_partners - yesterdayData.active_partners) / yesterdayData.active_partners) * 100 : 0,
      });
    }

    if (financialRes.data) setFinancialMetrics(financialRes.data);
    if (performanceRes.data) setPerformanceMetrics(performanceRes.data);
    if (operationalRes.data) setOperationalMetrics(operationalRes.data);
    if (weeklyRes.data) setWeeklyData(weeklyRes.data.reverse());

    setLoading(false);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="w-8 h-8 border-2 border-red-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  const totalCosts = financialMetrics
    ? Number(financialMetrics.llm_api_costs) +
      Number(financialMetrics.cloud_hosting_costs) +
      Number(financialMetrics.payment_processing_fees) +
      Number(financialMetrics.other_costs)
    : 0;

  const profitMargin = financialMetrics && financialMetrics.total_revenue > 0
    ? ((financialMetrics.net_profit / financialMetrics.total_revenue) * 100).toFixed(1)
    : '0';

  const maxRevenue = Math.max(...weeklyData.map(d => Number(d.total_revenue)));

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-white">Platform Overview</h1>
        <p className="text-gray-400 mt-1">Real-time metrics and performance indicators</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricCard
          title="Daily Active Users"
          value={platformMetrics?.daily_active_users || 0}
          change={platformMetrics?.dauChange}
          changeLabel="vs yesterday"
          icon={Users}
          color="blue"
        />
        <MetricCard
          title="Active Partners"
          value={platformMetrics?.active_partners || 0}
          change={platformMetrics?.partnerChange}
          changeLabel="vs yesterday"
          icon={Building2}
          color="green"
        />
        <MetricCard
          title="Today's Revenue"
          value={financialMetrics?.total_revenue?.toFixed(2) || '0.00'}
          prefix="EUR "
          icon={DollarSign}
          color="amber"
        />
        <MetricCard
          title="System Uptime"
          value={performanceMetrics?.uptime_percentage?.toFixed(2) || '99.99'}
          suffix="%"
          icon={Activity}
          color="green"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white/5 backdrop-blur-xl rounded-xl border border-white/10 p-5">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-lg font-semibold text-white">Revenue Trend</h2>
              <p className="text-gray-400 text-sm">Last 7 days</p>
            </div>
            <div className="text-right">
              <p className="text-2xl font-bold text-white">
                EUR {weeklyData.reduce((sum, d) => sum + Number(d.total_revenue), 0).toFixed(2)}
              </p>
              <p className="text-gray-400 text-sm">Total this week</p>
            </div>
          </div>

          <div className="flex items-end gap-2 h-40">
            {weeklyData.map((day, idx) => (
              <ChartBar
                key={idx}
                value={Number(day.total_revenue)}
                maxValue={maxRevenue}
                label={new Date(day.metric_date).toLocaleDateString('en', { weekday: 'short' })}
                color="bg-gradient-to-t from-red-500 to-orange-500"
              />
            ))}
          </div>
        </div>

        <div className="bg-white/5 backdrop-blur-xl rounded-xl border border-white/10 p-5">
          <h2 className="text-lg font-semibold text-white mb-4">Cost Breakdown</h2>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-3 h-3 rounded-full bg-blue-500" />
                <span className="text-gray-400 text-sm">LLM API</span>
              </div>
              <span className="text-white font-medium">
                EUR {Number(financialMetrics?.llm_api_costs || 0).toFixed(2)}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-3 h-3 rounded-full bg-green-500" />
                <span className="text-gray-400 text-sm">Cloud Hosting</span>
              </div>
              <span className="text-white font-medium">
                EUR {Number(financialMetrics?.cloud_hosting_costs || 0).toFixed(2)}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-3 h-3 rounded-full bg-amber-500" />
                <span className="text-gray-400 text-sm">Payment Fees</span>
              </div>
              <span className="text-white font-medium">
                EUR {Number(financialMetrics?.payment_processing_fees || 0).toFixed(2)}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-3 h-3 rounded-full bg-gray-500" />
                <span className="text-gray-400 text-sm">Other</span>
              </div>
              <span className="text-white font-medium">
                EUR {Number(financialMetrics?.other_costs || 0).toFixed(2)}
              </span>
            </div>
            <div className="pt-3 border-t border-white/10 flex items-center justify-between">
              <span className="text-gray-400 text-sm font-medium">Total Costs</span>
              <span className="text-white font-bold">EUR {totalCosts.toFixed(2)}</span>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricCard
          title="Total Listings"
          value={platformMetrics?.total_listings || 0}
          icon={FileText}
          color="purple"
        />
        <MetricCard
          title="Today's Bookings"
          value={platformMetrics?.total_bookings || 0}
          icon={Calendar}
          color="blue"
        />
        <MetricCard
          title="Profit Margin"
          value={profitMargin}
          suffix="%"
          icon={TrendingUp}
          color="green"
        />
        <MetricCard
          title="Error Rate"
          value={(performanceMetrics?.error_rate * 100 || 0).toFixed(3)}
          suffix="%"
          icon={AlertTriangle}
          color="red"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white/5 backdrop-blur-xl rounded-xl border border-white/10 p-5">
          <h2 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
            <Zap className="w-5 h-5 text-amber-400" />
            Performance Metrics
          </h2>
          <div className="space-y-4">
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-gray-400 text-sm">Avg Page Load Time</span>
                <span className="text-white font-medium">
                  {Number(performanceMetrics?.avg_page_load_time || 0).toFixed(0)}ms
                </span>
              </div>
              <div className="h-2 bg-white/10 rounded-full overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-green-500 to-emerald-500 rounded-full"
                  style={{ width: `${Math.min((performanceMetrics?.avg_page_load_time || 0) / 20, 100)}%` }}
                />
              </div>
            </div>
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-gray-400 text-sm">Avg API Response Time</span>
                <span className="text-white font-medium">
                  {Number(performanceMetrics?.avg_api_response_time || 0).toFixed(0)}ms
                </span>
              </div>
              <div className="h-2 bg-white/10 rounded-full overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-blue-500 to-cyan-500 rounded-full"
                  style={{ width: `${Math.min((performanceMetrics?.avg_api_response_time || 0) / 5, 100)}%` }}
                />
              </div>
            </div>
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-gray-400 text-sm">Successful Requests</span>
                <span className="text-white font-medium">
                  {(performanceMetrics?.successful_requests || 0).toLocaleString()}
                </span>
              </div>
              <div className="h-2 bg-white/10 rounded-full overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-green-500 to-emerald-500 rounded-full"
                  style={{
                    width: `${(performanceMetrics?.successful_requests /
                      (performanceMetrics?.successful_requests + performanceMetrics?.failed_requests || 1)) * 100}%`
                  }}
                />
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white/5 backdrop-blur-xl rounded-xl border border-white/10 p-5">
          <h2 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
            <Clock className="w-5 h-5 text-blue-400" />
            Operations Summary
          </h2>
          <div className="grid grid-cols-2 gap-4">
            <div className="p-4 rounded-xl bg-white/5">
              <p className="text-gray-400 text-sm mb-1">Open Tickets</p>
              <p className="text-2xl font-bold text-white">{operationalMetrics?.open_support_tickets || 0}</p>
            </div>
            <div className="p-4 rounded-xl bg-white/5">
              <p className="text-gray-400 text-sm mb-1">Resolved Today</p>
              <p className="text-2xl font-bold text-green-400">{operationalMetrics?.resolved_tickets || 0}</p>
            </div>
            <div className="p-4 rounded-xl bg-white/5">
              <p className="text-gray-400 text-sm mb-1">Avg Resolution</p>
              <p className="text-2xl font-bold text-white">
                {Number(operationalMetrics?.avg_resolution_time_hours || 0).toFixed(1)}h
              </p>
            </div>
            <div className="p-4 rounded-xl bg-white/5">
              <p className="text-gray-400 text-sm mb-1">Dev Hours Today</p>
              <p className="text-2xl font-bold text-white">
                {(Number(operationalMetrics?.dev_hours_features || 0) +
                  Number(operationalMetrics?.dev_hours_bugs || 0) +
                  Number(operationalMetrics?.dev_hours_maintenance || 0)).toFixed(1)}h
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
