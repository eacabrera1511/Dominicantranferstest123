import { useState } from 'react';
import { Plane, MapPin, Users, Clock, Calendar } from 'lucide-react';

interface AirportPickupFlowProps {
  service: any;
  onNext: (data: any) => void;
  onBack: () => void;
}

export function AirportPickupFlow({ service, onNext, onBack }: AirportPickupFlowProps) {
  const [formData, setFormData] = useState({
    pickupDate: '',
    pickupTime: '',
    flightNumber: '',
    pickupLocation: 'airport',
    dropoffAddress: '',
    passengers: 1,
    luggage: 1,
    specialRequests: ''
  });

  const isValid = formData.pickupDate && formData.pickupTime && formData.flightNumber && formData.dropoffAddress;

  return (
    <div className="space-y-3 xs:space-y-4 sm:space-y-6">
      <div className="text-center">
        <div className="w-12 h-12 xs:w-14 xs:h-14 sm:w-16 sm:h-16 bg-gradient-to-br from-blue-500/20 to-cyan-500/20 rounded-xl xs:rounded-2xl flex items-center justify-center mx-auto mb-2 xs:mb-3 sm:mb-4">
          <Plane className="w-6 h-6 xs:w-7 xs:h-7 sm:w-8 sm:h-8 text-blue-400" />
        </div>
        <h3 className="text-lg xs:text-xl sm:text-2xl font-bold text-white mb-1 xs:mb-2">Airport Pickup Details</h3>
        <p className="text-gray-300 text-xs xs:text-sm sm:text-base">{service.name}</p>
      </div>

      <div className="space-y-3 sm:space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
          <div>
            <label className="block text-white text-xs sm:text-sm font-medium mb-2">
              <Calendar className="w-3.5 h-3.5 sm:w-4 sm:h-4 inline mr-1" />
              Pickup Date *
            </label>
            <input
              type="date"
              value={formData.pickupDate}
              onChange={(e) => setFormData({...formData, pickupDate: e.target.value})}
              min={new Date().toISOString().split('T')[0]}
              className="w-full bg-white/10 border border-white/20 rounded-lg sm:rounded-xl px-3 sm:px-4 py-2.5 sm:py-3 text-white text-sm sm:text-base focus:outline-none focus:ring-2 focus:ring-blue-500/50"
            />
          </div>

          <div>
            <label className="block text-white text-xs sm:text-sm font-medium mb-2">
              <Clock className="w-3.5 h-3.5 sm:w-4 sm:h-4 inline mr-1" />
              Pickup Time *
            </label>
            <input
              type="time"
              value={formData.pickupTime}
              onChange={(e) => setFormData({...formData, pickupTime: e.target.value})}
              className="w-full bg-white/10 border border-white/20 rounded-lg sm:rounded-xl px-3 sm:px-4 py-2.5 sm:py-3 text-white text-sm sm:text-base focus:outline-none focus:ring-2 focus:ring-blue-500/50"
            />
          </div>
        </div>

        <div>
          <label className="block text-white text-xs sm:text-sm font-medium mb-2">
            <Plane className="w-3.5 h-3.5 sm:w-4 sm:h-4 inline mr-1" />
            Flight Number *
          </label>
          <input
            type="text"
            value={formData.flightNumber}
            onChange={(e) => setFormData({...formData, flightNumber: e.target.value})}
            placeholder="e.g., KL1234"
            className="w-full bg-white/10 border border-white/20 rounded-lg sm:rounded-xl px-3 sm:px-4 py-2.5 sm:py-3 text-white text-sm sm:text-base focus:outline-none focus:ring-2 focus:ring-blue-500/50"
          />
        </div>

        <div>
          <label className="block text-white text-xs sm:text-sm font-medium mb-2">
            <MapPin className="w-3.5 h-3.5 sm:w-4 sm:h-4 inline mr-1" />
            Pickup Location *
          </label>
          <select
            value={formData.pickupLocation}
            onChange={(e) => setFormData({...formData, pickupLocation: e.target.value})}
            className="w-full bg-white/10 border border-white/20 rounded-lg sm:rounded-xl px-3 sm:px-4 py-2.5 sm:py-3 text-white text-sm sm:text-base focus:outline-none focus:ring-2 focus:ring-blue-500/50"
          >
            <option value="airport" className="bg-slate-800">Airport Arrivals</option>
            <option value="hotel" className="bg-slate-800">Hotel</option>
            <option value="custom" className="bg-slate-800">Custom Address</option>
          </select>
        </div>

        <div>
          <label className="block text-white text-xs sm:text-sm font-medium mb-2">
            <MapPin className="w-3.5 h-3.5 sm:w-4 sm:h-4 inline mr-1" />
            Drop-off Address *
          </label>
          <input
            type="text"
            value={formData.dropoffAddress}
            onChange={(e) => setFormData({...formData, dropoffAddress: e.target.value})}
            placeholder="Enter destination address"
            className="w-full bg-white/10 border border-white/20 rounded-lg sm:rounded-xl px-3 sm:px-4 py-2.5 sm:py-3 text-white text-sm sm:text-base focus:outline-none focus:ring-2 focus:ring-blue-500/50"
          />
        </div>

        <div className="grid grid-cols-2 gap-3 sm:gap-4">
          <div>
            <label className="block text-white text-xs sm:text-sm font-medium mb-2">
              <Users className="w-3.5 h-3.5 sm:w-4 sm:h-4 inline mr-1" />
              Passengers
            </label>
            <select
              value={formData.passengers}
              onChange={(e) => setFormData({...formData, passengers: parseInt(e.target.value)})}
              className="w-full bg-white/10 border border-white/20 rounded-lg sm:rounded-xl px-3 sm:px-4 py-2.5 sm:py-3 text-white text-sm sm:text-base focus:outline-none focus:ring-2 focus:ring-blue-500/50"
            >
              {[1,2,3,4,5,6,7,8].map(num => (
                <option key={num} value={num} className="bg-slate-800">{num}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-white text-xs sm:text-sm font-medium mb-2">Luggage Pieces</label>
            <select
              value={formData.luggage}
              onChange={(e) => setFormData({...formData, luggage: parseInt(e.target.value)})}
              className="w-full bg-white/10 border border-white/20 rounded-lg sm:rounded-xl px-3 sm:px-4 py-2.5 sm:py-3 text-white text-sm sm:text-base focus:outline-none focus:ring-2 focus:ring-blue-500/50"
            >
              {[0,1,2,3,4,5,6].map(num => (
                <option key={num} value={num} className="bg-slate-800">{num}</option>
              ))}
            </select>
          </div>
        </div>

        <div>
          <label className="block text-white text-xs sm:text-sm font-medium mb-2">Special Requests (Optional)</label>
          <textarea
            value={formData.specialRequests}
            onChange={(e) => setFormData({...formData, specialRequests: e.target.value})}
            rows={3}
            placeholder="Child seat, wheelchair access, etc."
            className="w-full bg-white/10 border border-white/20 rounded-lg sm:rounded-xl px-3 sm:px-4 py-2.5 sm:py-3 text-white text-sm sm:text-base focus:outline-none focus:ring-2 focus:ring-blue-500/50 resize-none"
          />
        </div>
      </div>

      <div className="bg-white/5 rounded-lg sm:rounded-xl p-3 sm:p-4 border border-white/10">
        <div className="flex justify-between items-center text-white">
          <span className="text-base sm:text-lg font-semibold">Total Price:</span>
          <span className="text-xl sm:text-2xl font-bold">${service.price * formData.passengers}</span>
        </div>
        <p className="text-gray-400 text-xs sm:text-sm mt-1">
          ${service.price} × {formData.passengers} {formData.passengers === 1 ? 'passenger' : 'passengers'}
        </p>
      </div>

      <div className="flex gap-2 sm:gap-3 pt-2 sticky bottom-0 bg-gradient-to-t from-slate-900 via-slate-900/95 to-transparent -mx-4 xs:-mx-5 sm:-mx-8 px-4 xs:px-5 sm:px-8 pb-1">
        <button
          onClick={onBack}
          className="flex-1 bg-white/10 hover:bg-white/20 active:bg-white/30 text-white font-semibold py-2.5 xs:py-3 sm:py-4 rounded-xl transition-all duration-300 text-xs xs:text-sm sm:text-base"
        >
          Back
        </button>
        <button
          onClick={() => onNext({
            ...formData,
            totalPrice: service.price * formData.passengers,
            quantity: formData.passengers
          })}
          disabled={!isValid}
          className="flex-1 bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 disabled:from-gray-600 disabled:to-gray-700 text-white font-semibold py-2.5 xs:py-3 sm:py-4 rounded-xl transition-all duration-300 disabled:cursor-not-allowed text-xs xs:text-sm sm:text-base"
        >
          Continue
        </button>
      </div>
    </div>
  );
}