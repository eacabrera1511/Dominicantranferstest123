import { useState, useEffect } from 'react';
import { createPortal } from 'react-dom';
import {
  X, Car, Users, Briefcase, MapPin, Calendar, Clock,
  User, Mail, Phone, CreditCard, CheckCircle, Plane
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import { BookingAction } from '../lib/travelAgent';

interface ChatBookingModalProps {
  isOpen: boolean;
  onClose: () => void;
  bookingData: BookingAction;
  onComplete: (reference: string) => void;
}

const AIRPORT_NAMES: Record<string, string> = {
  PUJ: 'Punta Cana International Airport (PUJ)',
  SDQ: 'Santo Domingo Las Americas Airport (SDQ)',
  LRM: 'La Romana Airport (LRM)',
  POP: 'Puerto Plata Gregorio Luperon Airport (POP)',
};

export function ChatBookingModal({ isOpen, onClose, bookingData, onComplete }: ChatBookingModalProps) {
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [reference, setReference] = useState('');

  const [transferDetails, setTransferDetails] = useState({
    pickupDate: '',
    pickupTime: '',
    flightNumber: '',
    returnDate: '',
    returnTime: '',
    returnFlightNumber: '',
  });

  const [customerInfo, setCustomerInfo] = useState({
    name: '',
    email: '',
    phone: '',
    specialRequests: '',
  });

  const [paymentMethod, setPaymentMethod] = useState<'card' | 'paypal' | 'cash'>('card');
  const [cardDetails, setCardDetails] = useState({
    number: '',
    expiry: '',
    cvc: '',
    name: '',
  });

  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
      setStep(1);
      setReference('');
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isOpen]);

  if (!isOpen) return null;

  const isRoundTrip = bookingData.tripType === 'Round trip';

  const handleTransferSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setStep(2);
  };

  const handleCustomerSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setStep(3);
  };

  const handlePaymentSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const bookingRef = `TRF-${Date.now().toString(36).toUpperCase()}-${Math.random().toString(36).substring(2, 6).toUpperCase()}`;

      const orderData = {
        booking_type: 'airport_transfer',
        item_name: `${bookingData.vehicle} Transfer - ${bookingData.airport} to ${bookingData.hotel}`,
        quantity: 1,
        unit_price: bookingData.price,
        total_price: bookingData.price,
        customer_email: customerInfo.email,
        customer_name: customerInfo.name,
        check_in_date: transferDetails.pickupDate,
        check_out_date: isRoundTrip ? transferDetails.returnDate : null,
        payment_method: paymentMethod,
        status: 'confirmed',
        payment_status: 'paid',
        stripe_payment_id: `sim_${paymentMethod}_${Math.random().toString(36).substr(2, 9)}`,
        details: {
          phone: customerInfo.phone,
          airport: bookingData.airport,
          airportName: AIRPORT_NAMES[bookingData.airport],
          hotel: bookingData.hotel,
          region: bookingData.region,
          vehicle: bookingData.vehicle,
          passengers: bookingData.passengers,
          suitcases: bookingData.suitcases,
          tripType: bookingData.tripType,
          pickupTime: transferDetails.pickupTime,
          flightNumber: transferDetails.flightNumber,
          returnDate: transferDetails.returnDate,
          returnTime: transferDetails.returnTime,
          returnFlightNumber: transferDetails.returnFlightNumber,
          specialRequests: customerInfo.specialRequests,
          bookingReference: bookingRef,
        }
      };

      await supabase.from('orders').insert(orderData);

      await new Promise(resolve => setTimeout(resolve, 1500));

      setReference(bookingRef);
      setStep(4);
      onComplete(bookingRef);
    } catch (error) {
      console.error('Booking error:', error);
    } finally {
      setLoading(false);
    }
  };

  const inputClass = "w-full bg-white/5 border border-white/20 rounded-lg px-3 py-2.5 min-[480px]:py-3 md:py-3.5 text-white text-sm min-[480px]:text-base focus:outline-none focus:ring-2 focus:ring-teal-500/50 placeholder-gray-500";
  const inputWithIconClass = "w-full bg-white/5 border border-white/20 rounded-lg pl-9 min-[480px]:pl-10 pr-3 py-2.5 min-[480px]:py-3 md:py-3.5 text-white text-sm min-[480px]:text-base focus:outline-none focus:ring-2 focus:ring-teal-500/50 placeholder-gray-500";
  const labelClass = "block text-gray-400 text-xs min-[480px]:text-sm mb-1 min-[480px]:mb-1.5";
  const iconClass = "absolute left-2.5 min-[480px]:left-3 top-1/2 -translate-y-1/2 w-4 h-4 min-[480px]:w-5 min-[480px]:h-5 text-gray-400";

  const renderStep = () => {
    switch (step) {
      case 1:
        return (
          <form onSubmit={handleTransferSubmit} className="p-3 min-[480px]:p-4 md:p-6 space-y-4 min-[480px]:space-y-5">
            <div className="bg-gradient-to-r from-teal-500/10 to-cyan-500/10 rounded-xl p-3 min-[480px]:p-4 border border-teal-500/20">
              <h3 className="text-white font-semibold mb-2 min-[480px]:mb-3 flex items-center gap-2 text-sm min-[480px]:text-base">
                <Car className="w-4 h-4 min-[480px]:w-5 min-[480px]:h-5 text-teal-400" />
                Transfer Details
              </h3>
              <div className="grid grid-cols-2 gap-x-3 gap-y-1.5 min-[480px]:gap-2 text-xs min-[480px]:text-sm">
                <div className="flex items-center gap-1.5">
                  <Plane className="w-3.5 h-3.5 text-gray-400 flex-shrink-0" />
                  <span className="text-gray-400">Airport:</span>
                  <span className="text-white truncate">{bookingData.airport}</span>
                </div>
                <div className="flex items-center gap-1.5 min-w-0">
                  <MapPin className="w-3.5 h-3.5 text-gray-400 flex-shrink-0" />
                  <span className="text-gray-400">Hotel:</span>
                  <span className="text-white truncate">{bookingData.hotel}</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <Car className="w-3.5 h-3.5 text-gray-400 flex-shrink-0" />
                  <span className="text-gray-400">Vehicle:</span>
                  <span className="text-white truncate">{bookingData.vehicle}</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <Users className="w-3.5 h-3.5 text-gray-400 flex-shrink-0" />
                  <span className="text-gray-400">Pax:</span>
                  <span className="text-white">{bookingData.passengers}</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <Briefcase className="w-3.5 h-3.5 text-gray-400 flex-shrink-0" />
                  <span className="text-gray-400">Bags:</span>
                  <span className="text-white">{bookingData.suitcases}</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="text-gray-400">Trip:</span>
                  <span className="text-white truncate">{bookingData.tripType}</span>
                </div>
              </div>
              <div className="mt-3 pt-3 border-t border-white/10 flex justify-between items-center">
                <span className="text-gray-400 text-xs min-[480px]:text-sm">Total:</span>
                <span className="text-xl min-[480px]:text-2xl font-bold text-teal-400">${bookingData.price} USD</span>
              </div>
            </div>

            <div className="space-y-3 min-[480px]:space-y-4">
              <h3 className="text-white font-semibold text-sm min-[480px]:text-base">Arrival Details</h3>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className={labelClass}>Pickup Date *</label>
                  <div className="relative">
                    <Calendar className={iconClass} />
                    <input
                      type="date"
                      value={transferDetails.pickupDate}
                      onChange={(e) => setTransferDetails({ ...transferDetails, pickupDate: e.target.value })}
                      required
                      min={new Date().toISOString().split('T')[0]}
                      className={inputWithIconClass}
                    />
                  </div>
                </div>
                <div>
                  <label className={labelClass}>Pickup Time *</label>
                  <div className="relative">
                    <Clock className={iconClass} />
                    <input
                      type="time"
                      value={transferDetails.pickupTime}
                      onChange={(e) => setTransferDetails({ ...transferDetails, pickupTime: e.target.value })}
                      required
                      className={inputWithIconClass}
                    />
                  </div>
                </div>
              </div>
              <div>
                <label className={labelClass}>Flight Number (optional)</label>
                <div className="relative">
                  <Plane className={iconClass} />
                  <input
                    type="text"
                    value={transferDetails.flightNumber}
                    onChange={(e) => setTransferDetails({ ...transferDetails, flightNumber: e.target.value })}
                    placeholder="e.g., AA1234"
                    className={inputWithIconClass}
                  />
                </div>
              </div>

              {isRoundTrip && (
                <>
                  <h3 className="text-white font-semibold pt-2 text-sm min-[480px]:text-base">Return Details</h3>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className={labelClass}>Return Date *</label>
                      <div className="relative">
                        <Calendar className={iconClass} />
                        <input
                          type="date"
                          value={transferDetails.returnDate}
                          onChange={(e) => setTransferDetails({ ...transferDetails, returnDate: e.target.value })}
                          required
                          min={transferDetails.pickupDate || new Date().toISOString().split('T')[0]}
                          className={inputWithIconClass}
                        />
                      </div>
                    </div>
                    <div>
                      <label className={labelClass}>Return Time *</label>
                      <div className="relative">
                        <Clock className={iconClass} />
                        <input
                          type="time"
                          value={transferDetails.returnTime}
                          onChange={(e) => setTransferDetails({ ...transferDetails, returnTime: e.target.value })}
                          required
                          className={inputWithIconClass}
                        />
                      </div>
                    </div>
                  </div>
                  <div>
                    <label className={labelClass}>Return Flight (optional)</label>
                    <div className="relative">
                      <Plane className={iconClass} />
                      <input
                        type="text"
                        value={transferDetails.returnFlightNumber}
                        onChange={(e) => setTransferDetails({ ...transferDetails, returnFlightNumber: e.target.value })}
                        placeholder="e.g., AA5678"
                        className={inputWithIconClass}
                      />
                    </div>
                  </div>
                </>
              )}
            </div>

            <button
              type="submit"
              className="w-full py-3 min-[480px]:py-3.5 rounded-xl bg-gradient-to-r from-teal-500 to-cyan-500 text-white text-sm min-[480px]:text-base font-semibold hover:from-teal-600 hover:to-cyan-600 transition-all active:scale-[0.98]"
            >
              Continue to Contact Info
            </button>
          </form>
        );

      case 2:
        return (
          <form onSubmit={handleCustomerSubmit} className="p-3 min-[480px]:p-4 md:p-6 space-y-4 min-[480px]:space-y-5">
            <h3 className="text-white font-semibold flex items-center gap-2 text-sm min-[480px]:text-base">
              <User className="w-4 h-4 min-[480px]:w-5 min-[480px]:h-5 text-teal-400" />
              Contact Information
            </h3>

            <div className="space-y-3 min-[480px]:space-y-4">
              <div>
                <label className={labelClass}>Full Name *</label>
                <div className="relative">
                  <User className={iconClass} />
                  <input
                    type="text"
                    value={customerInfo.name}
                    onChange={(e) => setCustomerInfo({ ...customerInfo, name: e.target.value })}
                    required
                    placeholder="John Smith"
                    className={inputWithIconClass}
                  />
                </div>
              </div>

              <div>
                <label className={labelClass}>Email Address *</label>
                <div className="relative">
                  <Mail className={iconClass} />
                  <input
                    type="email"
                    value={customerInfo.email}
                    onChange={(e) => setCustomerInfo({ ...customerInfo, email: e.target.value })}
                    required
                    placeholder="john@email.com"
                    className={inputWithIconClass}
                  />
                </div>
              </div>

              <div>
                <label className={labelClass}>Phone Number *</label>
                <div className="relative">
                  <Phone className={iconClass} />
                  <input
                    type="tel"
                    value={customerInfo.phone}
                    onChange={(e) => setCustomerInfo({ ...customerInfo, phone: e.target.value })}
                    required
                    placeholder="+1 555 123 4567"
                    className={inputWithIconClass}
                  />
                </div>
              </div>

              <div>
                <label className={labelClass}>Special Requests (optional)</label>
                <textarea
                  value={customerInfo.specialRequests}
                  onChange={(e) => setCustomerInfo({ ...customerInfo, specialRequests: e.target.value })}
                  placeholder="Child seat, wheelchair, extra stops..."
                  rows={2}
                  className={`${inputClass} resize-none`}
                />
              </div>
            </div>

            <div className="flex gap-3">
              <button
                type="button"
                onClick={() => setStep(1)}
                className="flex-1 py-3 min-[480px]:py-3.5 rounded-xl bg-white/5 border border-white/20 text-white text-sm min-[480px]:text-base font-medium hover:bg-white/10 transition-all active:scale-[0.98]"
              >
                Back
              </button>
              <button
                type="submit"
                className="flex-1 py-3 min-[480px]:py-3.5 rounded-xl bg-gradient-to-r from-teal-500 to-cyan-500 text-white text-sm min-[480px]:text-base font-semibold hover:from-teal-600 hover:to-cyan-600 transition-all active:scale-[0.98]"
              >
                Continue
              </button>
            </div>
          </form>
        );

      case 3:
        return (
          <form onSubmit={handlePaymentSubmit} className="p-3 min-[480px]:p-4 md:p-6 space-y-4 min-[480px]:space-y-5">
            <h3 className="text-white font-semibold flex items-center gap-2 text-sm min-[480px]:text-base">
              <CreditCard className="w-4 h-4 min-[480px]:w-5 min-[480px]:h-5 text-teal-400" />
              Payment - ${bookingData.price} USD
            </h3>

            <div className="grid grid-cols-3 gap-2 min-[480px]:gap-3">
              {(['card', 'paypal', 'cash'] as const).map((method) => (
                <button
                  key={method}
                  type="button"
                  onClick={() => setPaymentMethod(method)}
                  className={`py-2.5 min-[480px]:py-3 px-2 rounded-xl border transition-all active:scale-[0.98] ${
                    paymentMethod === method
                      ? 'bg-teal-500/20 border-teal-500/50 text-teal-400'
                      : 'bg-white/5 border-white/20 text-gray-400 hover:bg-white/10'
                  }`}
                >
                  <span className="text-xs min-[480px]:text-sm font-medium capitalize">{method === 'card' ? 'Card' : method}</span>
                </button>
              ))}
            </div>

            {paymentMethod === 'card' && (
              <div className="space-y-3 min-[480px]:space-y-4">
                <div>
                  <label className={labelClass}>Card Number</label>
                  <input
                    type="text"
                    value={cardDetails.number}
                    onChange={(e) => setCardDetails({ ...cardDetails, number: e.target.value })}
                    placeholder="4242 4242 4242 4242"
                    maxLength={19}
                    className={inputClass}
                  />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className={labelClass}>Expiry</label>
                    <input
                      type="text"
                      value={cardDetails.expiry}
                      onChange={(e) => setCardDetails({ ...cardDetails, expiry: e.target.value })}
                      placeholder="MM/YY"
                      maxLength={5}
                      className={inputClass}
                    />
                  </div>
                  <div>
                    <label className={labelClass}>CVC</label>
                    <input
                      type="text"
                      value={cardDetails.cvc}
                      onChange={(e) => setCardDetails({ ...cardDetails, cvc: e.target.value })}
                      placeholder="123"
                      maxLength={4}
                      className={inputClass}
                    />
                  </div>
                </div>
                <div>
                  <label className={labelClass}>Name on Card</label>
                  <input
                    type="text"
                    value={cardDetails.name}
                    onChange={(e) => setCardDetails({ ...cardDetails, name: e.target.value })}
                    placeholder="JOHN SMITH"
                    className={inputClass}
                  />
                </div>
              </div>
            )}

            {paymentMethod === 'paypal' && (
              <div className="bg-white/5 rounded-xl p-4 min-[480px]:p-6 text-center">
                <p className="text-gray-400 text-sm min-[480px]:text-base mb-3">You will be redirected to PayPal.</p>
                <div className="text-xl min-[480px]:text-2xl font-bold text-white">${bookingData.price} USD</div>
              </div>
            )}

            {paymentMethod === 'cash' && (
              <div className="bg-amber-500/10 border border-amber-500/20 rounded-xl p-3 min-[480px]:p-4">
                <p className="text-amber-400 text-xs min-[480px]:text-sm">Pay cash to your driver upon arrival. Please have the exact amount ready in USD.</p>
              </div>
            )}

            <div className="flex gap-3">
              <button
                type="button"
                onClick={() => setStep(2)}
                className="flex-1 py-3 min-[480px]:py-3.5 rounded-xl bg-white/5 border border-white/20 text-white text-sm min-[480px]:text-base font-medium hover:bg-white/10 transition-all active:scale-[0.98]"
              >
                Back
              </button>
              <button
                type="submit"
                disabled={loading}
                className="flex-1 py-3 min-[480px]:py-3.5 rounded-xl bg-gradient-to-r from-teal-500 to-cyan-500 text-white text-sm min-[480px]:text-base font-semibold hover:from-teal-600 hover:to-cyan-600 disabled:opacity-50 transition-all flex items-center justify-center gap-2 active:scale-[0.98]"
              >
                {loading ? (
                  <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                ) : (
                  'Complete'
                )}
              </button>
            </div>
          </form>
        );

      case 4:
        return (
          <div className="p-3 min-[480px]:p-4 md:p-6 text-center space-y-4 min-[480px]:space-y-5">
            <div className="w-14 h-14 min-[480px]:w-16 min-[480px]:h-16 md:w-20 md:h-20 rounded-full bg-green-500/20 flex items-center justify-center mx-auto">
              <CheckCircle className="w-7 h-7 min-[480px]:w-8 min-[480px]:h-8 md:w-10 md:h-10 text-green-400" />
            </div>

            <div>
              <h3 className="text-lg min-[480px]:text-xl md:text-2xl font-bold text-white mb-1">Booking Confirmed!</h3>
              <p className="text-gray-400 text-sm min-[480px]:text-base">Your transfer has been booked.</p>
            </div>

            <div className="bg-white/5 rounded-xl p-3 min-[480px]:p-4">
              <p className="text-gray-400 text-xs min-[480px]:text-sm mb-1">Booking Reference</p>
              <p className="text-base min-[480px]:text-lg md:text-2xl font-bold text-teal-400 font-mono break-all">{reference}</p>
            </div>

            <div className="bg-white/5 rounded-xl p-3 min-[480px]:p-4 text-left space-y-2 text-xs min-[480px]:text-sm">
              <div className="flex justify-between gap-2">
                <span className="text-gray-400 flex-shrink-0">Transfer:</span>
                <span className="text-white text-right truncate">{bookingData.airport} to {bookingData.hotel}</span>
              </div>
              <div className="flex justify-between gap-2">
                <span className="text-gray-400 flex-shrink-0">Date:</span>
                <span className="text-white text-right">{transferDetails.pickupDate} at {transferDetails.pickupTime}</span>
              </div>
              <div className="flex justify-between gap-2">
                <span className="text-gray-400 flex-shrink-0">Vehicle:</span>
                <span className="text-white">{bookingData.vehicle}</span>
              </div>
              <div className="flex justify-between gap-2">
                <span className="text-gray-400 flex-shrink-0">Total Paid:</span>
                <span className="text-teal-400 font-semibold">${bookingData.price} USD</span>
              </div>
            </div>

            <p className="text-gray-400 text-xs min-[480px]:text-sm">
              Confirmation sent to <span className="text-white break-all">{customerInfo.email}</span>
            </p>

            <button
              onClick={onClose}
              className="w-full py-3 min-[480px]:py-3.5 rounded-xl bg-gradient-to-r from-teal-500 to-cyan-500 text-white text-sm min-[480px]:text-base font-semibold hover:from-teal-600 hover:to-cyan-600 transition-all active:scale-[0.98]"
            >
              Close
            </button>
          </div>
        );

      default:
        return null;
    }
  };

  const stepTitles = ['Transfer Details', 'Contact Info', 'Payment', 'Confirmation'];

  return createPortal(
    <div className="fixed inset-0 z-50 flex items-end min-[480px]:items-center justify-center min-[480px]:p-4">
      <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" onClick={onClose} />

      <div className="relative w-full min-[480px]:max-w-md md:max-w-lg bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 rounded-t-2xl min-[480px]:rounded-2xl border border-white/10 shadow-2xl max-h-[90vh] min-[480px]:max-h-[85vh] overflow-hidden flex flex-col">
        <div className="p-3 min-[480px]:p-4 border-b border-white/10 flex items-center justify-between flex-shrink-0">
          <div className="min-w-0 flex-1">
            <h2 className="text-base min-[480px]:text-lg font-bold text-white truncate">Book Airport Transfer</h2>
            {step < 4 && (
              <p className="text-gray-400 text-xs min-[480px]:text-sm">Step {step} of 3 - {stepTitles[step - 1]}</p>
            )}
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 min-[480px]:w-10 min-[480px]:h-10 rounded-xl bg-white/5 hover:bg-white/10 flex items-center justify-center text-gray-400 hover:text-white transition-colors flex-shrink-0 ml-2 active:scale-95"
          >
            <X className="w-4 h-4 min-[480px]:w-5 min-[480px]:h-5" />
          </button>
        </div>

        {step < 4 && (
          <div className="px-3 min-[480px]:px-4 pt-3 min-[480px]:pt-4 flex-shrink-0">
            <div className="flex gap-1.5 min-[480px]:gap-2">
              {[1, 2, 3].map((s) => (
                <div
                  key={s}
                  className={`h-1 min-[480px]:h-1.5 flex-1 rounded-full transition-colors ${
                    s <= step ? 'bg-teal-500' : 'bg-white/10'
                  }`}
                />
              ))}
            </div>
          </div>
        )}

        <div className="flex-1 overflow-y-auto min-h-0 overscroll-contain">
          {renderStep()}
        </div>
      </div>
    </div>,
    document.body
  );
}
