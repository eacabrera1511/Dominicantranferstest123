import { Sparkles } from 'lucide-react';

interface SuggestionChipsProps {
  suggestions: string[];
  onSelect: (suggestion: string) => void;
}

export function SuggestionChips({ suggestions, onSelect }: SuggestionChipsProps) {
  if (suggestions.length === 0) return null;

  return (
    <div className="mb-6 animate-slideIn">
      <div className="flex items-center gap-2 mb-3 px-1">
        <Sparkles className="w-4 h-4 text-yellow-500 dark:text-yellow-400" />
        <span className="text-slate-500 dark:text-gray-400 text-sm font-medium">Suggestions</span>
      </div>

      <div className="flex flex-wrap gap-2">
        {suggestions.map((suggestion, index) => (
          <button
            key={index}
            onClick={() => onSelect(suggestion)}
            className="px-4 py-2.5 bg-white/80 dark:bg-white/5 hover:bg-slate-100 dark:hover:bg-white/10 backdrop-blur-xl border border-slate-200/50 dark:border-white/20 rounded-2xl text-sm text-slate-700 dark:text-gray-300 hover:text-slate-900 dark:hover:text-white transition-all duration-300 hover:scale-105 hover:shadow-lg"
          >
            {suggestion}
          </button>
        ))}
      </div>
    </div>
  );
}
