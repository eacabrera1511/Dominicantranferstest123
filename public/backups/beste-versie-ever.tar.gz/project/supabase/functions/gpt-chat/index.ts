import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface ChatRequest {
  message: string;
  conversationHistory?: Array<{ role: string; content: string }>;
  isInBookingFlow?: boolean;
}

const FALLBACK_RESPONSES: Record<string, string> = {
  weather: "The Dominican Republic enjoys tropical weather year-round! Expect temperatures between 77-86F (25-30C). The dry season (December-April) is perfect for beach visits, while the rainy season (May-November) brings brief afternoon showers. Pack light clothes, sunscreen, and a light rain jacket!",
  beach: "The DR has some of the Caribbean's most beautiful beaches! Punta Cana offers powdery white sand and turquoise waters. Bavaro Beach is perfect for families, while Cap Cana has more secluded luxury spots. Puerto Plata's northern coast has golden sand beaches with great surfing.",
  food: "Dominican cuisine is delicious! Try 'La Bandera' - the national dish of rice, beans, and meat. Don't miss mofongo (mashed plantains), tostones (fried plantains), and fresh seafood. Wash it down with Presidente beer or mamajuana, a local herbal drink!",
  activities: "There's so much to do! Visit Saona Island for pristine beaches, explore Santo Domingo's historic Colonial Zone (UNESCO site), go zip-lining in Puerto Plata, swim in natural cenotes, or take a catamaran cruise. Golf lovers will find world-class courses!",
  safety: "The tourist areas are generally very safe! Stick to reputable tour operators and transportation services. Our private transfers ensure you travel safely from the airport to your resort. Keep valuables secure and use common sense, just like traveling anywhere.",
  currency: "The Dominican Peso (DOP) is the local currency, but US dollars are widely accepted in tourist areas. Credit cards work at most hotels and restaurants. ATMs are available, but let your bank know you're traveling. Tip in local currency when possible!",
  language: "Spanish is the official language, but English is widely spoken in tourist areas, especially at resorts and with tour operators. Our drivers speak English! Learning a few Spanish phrases like 'Hola' (hello) and 'Gracias' (thank you) is always appreciated.",
  default: "The Dominican Republic is a beautiful Caribbean destination with stunning beaches, rich culture, warm people, and delicious food! It's perfect for relaxation, adventure, or a mix of both. When you're ready to book your airport transfer, just let me know!"
};

function getSmartResponse(message: string): string {
  const lower = message.toLowerCase();
  
  if (lower.includes('weather') || lower.includes('climate') || lower.includes('temperature') || lower.includes('rain') || lower.includes('hot') || lower.includes('cold')) {
    return FALLBACK_RESPONSES.weather;
  }
  if (lower.includes('beach') || lower.includes('sand') || lower.includes('ocean') || lower.includes('swim') || lower.includes('coast')) {
    return FALLBACK_RESPONSES.beach;
  }
  if (lower.includes('food') || lower.includes('eat') || lower.includes('restaurant') || lower.includes('cuisine') || lower.includes('drink') || lower.includes('beer')) {
    return FALLBACK_RESPONSES.food;
  }
  if (lower.includes('do') || lower.includes('activit') || lower.includes('tour') || lower.includes('visit') || lower.includes('see') || lower.includes('attraction')) {
    return FALLBACK_RESPONSES.activities;
  }
  if (lower.includes('safe') || lower.includes('danger') || lower.includes('security') || lower.includes('crime')) {
    return FALLBACK_RESPONSES.safety;
  }
  if (lower.includes('money') || lower.includes('currency') || lower.includes('dollar') || lower.includes('peso') || lower.includes('pay') || lower.includes('tip') || lower.includes('atm')) {
    return FALLBACK_RESPONSES.currency;
  }
  if (lower.includes('language') || lower.includes('spanish') || lower.includes('english') || lower.includes('speak')) {
    return FALLBACK_RESPONSES.language;
  }
  
  return FALLBACK_RESPONSES.default;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const { message, conversationHistory = [], isInBookingFlow = false }: ChatRequest = await req.json();

    const openaiApiKey = Deno.env.get("OPENAI_API_KEY");

    if (!openaiApiKey) {
      console.log("No OpenAI API key configured, using smart fallback responses");
      return new Response(
        JSON.stringify({
          response: getSmartResponse(message),
          success: true,
          source: "fallback"
        }),
        {
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json",
          },
        }
      );
    }

    const bookingFlowContext = isInBookingFlow
      ? `\n\nIMPORTANT: The user is currently in the middle of booking a transfer. After answering their question, gently remind them they can say "continue booking" to resume their booking whenever they're ready. Don't be pushy, just helpful.`
      : `\n\nIf the user seems interested in booking a transfer, let them know they can say "book a transfer" or "I'm ready to book" whenever they want to start.`;

    const systemPrompt = `SYSTEM ROLE:
You are the PRIMARY and AUTHORITATIVE AI brain for fleet management, pricing, booking logic, and chat assistance for a PRIVATE AI-POWERED TRANSFER COMPANY in the DOMINICAN REPUBLIC.

--------------------------------------------------
CORE BEHAVIOR
--------------------------------------------------

You must:
- Answer pricing questions in chat
- Support the booking flow without breaking it
- Automatically select the correct vehicle
- Calculate one-way and roundtrip pricing
- Apply VIP, surge, and upgrade logic
- Suggest better vehicle or pricing options when relevant
- Respect luggage capacity strictly
- Support multi-language chat (EN / ES / DE / NL)
- Provide intelligent fallback suggestions

You are allowed and expected to:
- Suggest vehicle upgrades
- Suggest VIP service when appropriate
- Suggest cost-saving options when available
- Suggest changes if user input is illogical or incomplete

--------------------------------------------------
AIRPORT DEFINITIONS
--------------------------------------------------

PUJ = Punta Cana International Airport
SDQ = Santo Domingo Las Américas Airport

--------------------------------------------------
FLEET OVERRIDE — VEHICLE TYPES (AUTHORITATIVE)
--------------------------------------------------

Sedan / Standard Private Transfer
- Passengers: 1–2
- Suitcases: up to 3
- Category: Standard
- Use case: couples, solo travelers

Minivan / Family Transfer
- Passengers: 3–6
- Suitcases: 6–8
- Category: Standard Plus
- Use case: families, small groups

Suburban / Luxury SUV (VIP)
- Passengers: 1–4
- Suitcases: up to 4
- Category: Luxury / VIP
- Use case: executive, premium, black car service

Sprinter / Large Van
- Passengers: 7–12
- Suitcases: 10–14
- Category: Group Premium

Mini Bus
- Passengers: 13+
- Suitcases: Large capacity
- Category: Group

RULE (HARD):
If passenger count OR luggage exceeds vehicle capacity → AUTO-UPGRADE vehicle.
Never downsize vehicles.

--------------------------------------------------
AUTO VEHICLE SELECTION & SUGGESTION LOGIC
--------------------------------------------------

IF passengers <= 2 AND suitcases <= 3 → Sedan
IF passengers <= 6 AND suitcases <= 8 → Minivan
IF VIP keywords detected (VIP, luxury, black car, executive, premium) → Suburban
IF passengers > 6 AND <= 12 → Sprinter
IF passengers > 12 → Mini Bus

If passengers fit multiple vehicles:
- Suggest the cheapest valid option by default
- Offer an optional upgrade (Suburban / VIP) when appropriate

--------------------------------------------------
TRANSFER ZONES (AUTHORITATIVE)
--------------------------------------------------

Zone A – Punta Cana / Bávaro
Zone B – Cap Cana
Zone C – Uvero Alto / Macao
Zone D – Bayahibe / La Romana
Zone E – Santo Domingo City

--------------------------------------------------
BASE PRICING — ONE WAY (USD) (OVERRIDE)
--------------------------------------------------

PUJ → HOTEL

Zone A:
Sedan $25 | Minivan $45 | Suburban $65 | Sprinter $110 | Mini Bus $180

Zone B:
Sedan $30 | Minivan $50 | Suburban $75 | Sprinter $120 | Mini Bus $190

Zone C:
Sedan $40 | Minivan $65 | Suburban $90 | Sprinter $135 | Mini Bus $210

Zone D:
Sedan $55 | Minivan $80 | Suburban $110 | Sprinter $160 | Mini Bus $240

SDQ → HOTEL

Zone A:
Sedan $190 | Minivan $230 | Suburban $300 | Sprinter $380 | Mini Bus $520

Zone B:
Sedan $200 | Minivan $250 | Suburban $320 | Sprinter $400 | Mini Bus $550

Zone C:
Sedan $220 | Minivan $270 | Suburban $350 | Sprinter $420 | Mini Bus $580

Zone D:
Sedan $240 | Minivan $290 | Suburban $380 | Sprinter $450 | Mini Bus $620

PUJ ↔ SDQ Direct Transfer:
Sedan $220 | Minivan $260 | Suburban $320 | Sprinter $420 | Mini Bus $600

--------------------------------------------------
ROUNDTRIP RULE (OVERRIDE)
--------------------------------------------------

Roundtrip Price = One-Way × 1.9

--------------------------------------------------
VIP PRICING & UPSELL LOGIC
--------------------------------------------------

VIP_MULTIPLIER = 1.35

Apply VIP pricing when:
- Vehicle is Suburban or higher
- User explicitly requests VIP / luxury
- Hotel is high-end AND comfort is implied

Always explain VIP benefits briefly:
- Premium vehicle
- More space
- Priority service

--------------------------------------------------
DYNAMIC SURGE PRICING
--------------------------------------------------

Apply surge ONLY when conditions apply:

Peak Season (Dec 15 – Apr 15): +15%
Night pickups / delays: +10%
Same-day booking: +10%
Major holidays: +20%

Maximum combined surge: 30%

If surge is applied:
- Mention it transparently
- Keep explanation short and clear

--------------------------------------------------
CHAT RESPONSE FORMAT
--------------------------------------------------

Always include:
- Selected vehicle
- One-way price
- Roundtrip price
- What is included
- Clear next step (booking CTA)

--------------------------------------------------
MULTI-LANGUAGE SUPPORT
--------------------------------------------------

Auto-detect language.

English (EN): default
Spanish (ES): neutral Dominican Spanish
German (DE): polite and professional
Dutch (NL): friendly and clear

Pricing remains unchanged across languages.

--------------------------------------------------
INTELLIGENT SUGGESTIONS (IMPORTANT)
--------------------------------------------------

You are REQUIRED to suggest improvements when relevant:

Examples:
- "For more comfort, a Suburban VIP is also available."
- "A roundtrip saves money compared to booking twice."
- "With this amount of luggage, a minivan is recommended."
- "This hotel is premium — many guests choose VIP service."

--------------------------------------------------
FINAL AUTHORITY RULE
--------------------------------------------------

This prompt OVERRIDES all previous fleet definitions, pricing rules, and vehicle logic.

You remain compatible with the CRM booking flow and may suggest updates based on this logic at any time.${bookingFlowContext}

RESPONSE STYLE:
- Be conversational, warm, and genuinely helpful
- Provide accurate, detailed answers
- Show personality when appropriate
- Keep responses focused but comprehensive (2-4 paragraphs typical)`;

    const messages = [
      { role: "system", content: systemPrompt },
      ...conversationHistory.slice(-6),
      { role: "user", content: message }
    ];

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 15000);

    try {
      const response = await fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${openaiApiKey}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model: "gpt-4o",
          messages: messages,
          temperature: 0.7,
          max_tokens: 800,
          presence_penalty: 0.1,
          frequency_penalty: 0.1,
        }),
        signal: controller.signal,
      });

      clearTimeout(timeoutId);

      if (!response.ok) {
        const errorText = await response.text();
        console.error("OpenAI API error:", response.status, errorText);
        
        return new Response(
          JSON.stringify({
            response: getSmartResponse(message),
            success: true,
            source: "fallback"
          }),
          {
            headers: {
              ...corsHeaders,
              "Content-Type": "application/json",
            },
          }
        );
      }

      const data = await response.json();
      const aiResponse = data.choices[0]?.message?.content || getSmartResponse(message);

      return new Response(
        JSON.stringify({
          response: aiResponse,
          success: true,
          source: "openai"
        }),
        {
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json",
          },
        }
      );
    } catch (fetchError) {
      clearTimeout(timeoutId);
      console.error("Fetch error:", fetchError);
      
      return new Response(
        JSON.stringify({
          response: getSmartResponse(message),
          success: true,
          source: "fallback"
        }),
        {
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json",
          },
        }
      );
    }

  } catch (error) {
    console.error("Error in gpt-chat function:", error);

    return new Response(
      JSON.stringify({
        response: "The Dominican Republic is a beautiful Caribbean destination! I'm here to help answer your questions about attractions, weather, culture, or local tips. When you're ready to book your transfer, just let me know!",
        success: true,
        source: "error-fallback"
      }),
      {
        status: 200,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  }
});
