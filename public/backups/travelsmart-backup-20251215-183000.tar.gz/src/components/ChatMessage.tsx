import { User } from 'lucide-react';

interface ChatMessageProps {
  role: 'user' | 'assistant';
  content: string;
  vehicleImage?: {
    url: string;
    alt: string;
    caption: string;
  };
}

export function ChatMessage({ role, content, vehicleImage }: ChatMessageProps) {
  const isUser = role === 'user';

  return (
    <div className={`flex gap-3 ${isUser ? 'justify-end' : 'justify-start'} mb-6 animate-slideIn`}>
      {!isUser && (
        <div className="flex-shrink-0 w-10 h-10 rounded-2xl bg-gradient-to-br from-teal-500/20 to-cyan-500/20 backdrop-blur-xl border border-slate-200/50 dark:border-white/20 flex items-center justify-center shadow-lg text-2xl">
          🚕
        </div>
      )}

      <div
        className={`max-w-[75%] rounded-3xl px-5 py-3 shadow-xl ${
          isUser
            ? 'bg-gradient-to-br from-teal-500 to-cyan-600 text-white'
            : 'bg-white/80 dark:bg-white/10 backdrop-blur-2xl border border-slate-200/50 dark:border-white/20 text-slate-800 dark:text-gray-100'
        }`}
        style={{
          backdropFilter: 'blur(20px) saturate(180%)',
        }}
      >
        <p className="text-[15px] leading-relaxed whitespace-pre-wrap">{content}</p>

        {vehicleImage && (
          <div className="mt-4">
            <img
              src={vehicleImage.url}
              alt={vehicleImage.alt}
              className="w-full rounded-2xl shadow-lg border border-slate-200/50 dark:border-white/20"
            />
            <p className="text-xs text-slate-500 dark:text-gray-300 mt-2 text-center">{vehicleImage.caption}</p>
          </div>
        )}
      </div>

      {isUser && (
        <div className="flex-shrink-0 w-10 h-10 rounded-2xl bg-gradient-to-br from-teal-500/20 to-cyan-500/20 backdrop-blur-xl border border-slate-200/50 dark:border-white/20 flex items-center justify-center shadow-lg">
          <User className="w-5 h-5 text-teal-500 dark:text-teal-400" />
        </div>
      )}
    </div>
  );
}
