import { Download, X } from 'lucide-react';

interface DownloadBackupsProps {
  onClose: () => void;
}

export default function DownloadBackups({ onClose }: DownloadBackupsProps) {
  const backups = [
    {
      name: 'ZIP Backup',
      filename: 'edwinbooking-backup-20251214-130628.zip',
      size: 'Full project backup (ZIP format)',
      path: '/backups/edwinbooking-backup-20251214-130628.zip'
    },
    {
      name: 'TAR.GZ Backup',
      filename: 'edwinbooking-backup-20251214-130618.tar.gz',
      size: 'Full project backup (TAR.GZ format)',
      path: '/backups/edwinbooking-backup-20251214-130618.tar.gz'
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-slate-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 py-12 px-4">
      <div className="max-w-3xl mx-auto">
        <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-8">
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-3">
              <Download className="w-8 h-8 text-blue-600 dark:text-blue-400" />
              <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
                Download Backups
              </h1>
            </div>
            <button
              onClick={onClose}
              className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
              title="Close"
            >
              <X className="w-6 h-6 text-gray-600 dark:text-gray-400" />
            </button>
          </div>

          <p className="text-gray-600 dark:text-gray-300 mb-8">
            Click on any backup below to download it to your computer.
          </p>

          <div className="space-y-4">
            {backups.map((backup) => (
              <a
                key={backup.filename}
                href={backup.path}
                download={backup.filename}
                className="block p-6 bg-gradient-to-r from-blue-50 to-purple-50 dark:from-gray-700 dark:to-gray-600 rounded-xl border-2 border-transparent hover:border-blue-500 dark:hover:border-blue-400 transition-all duration-200 hover:shadow-lg group"
              >
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-1 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
                      {backup.name}
                    </h3>
                    <p className="text-sm text-gray-600 dark:text-gray-300 mb-1">
                      {backup.size}
                    </p>
                    <p className="text-xs text-gray-500 dark:text-gray-400 font-mono">
                      {backup.filename}
                    </p>
                  </div>
                  <Download className="w-8 h-8 text-blue-600 dark:text-blue-400 group-hover:scale-110 transition-transform" />
                </div>
              </a>
            ))}
          </div>

          <div className="mt-8 p-4 bg-blue-50 dark:bg-gray-700 rounded-lg">
            <p className="text-sm text-gray-700 dark:text-gray-300">
              <strong>Note:</strong> Both files contain the same backup content in different compression formats.
              Choose the format that works best for your system.
            </p>
          </div>

          <div className="mt-6 text-center">
            <button
              onClick={onClose}
              className="text-blue-600 dark:text-blue-400 hover:underline"
            >
              ← Back to Home
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
