import { useState, useEffect } from 'react';
import { createPortal } from 'react-dom';
import {
  X, Car, Users, Briefcase, MapPin, Calendar, Clock, ArrowRight,
  User, Mail, Phone, CreditCard, CheckCircle, Plane, Shield, Sparkles
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import { BookingAction } from '../lib/travelAgent';
import { StripeService, PricingResult } from '../lib/stripe';

interface TransferBookingModalProps {
  isOpen: boolean;
  onClose: () => void;
  bookingData: BookingAction;
  onComplete: (reference: string) => void;
}

const AIRPORT_NAMES: Record<string, string> = {
  PUJ: 'Punta Cana International Airport',
  SDQ: 'Santo Domingo Las Americas Airport',
  LRM: 'La Romana International Airport',
  POP: 'Puerto Plata Gregorio Luperon Airport',
};

export function TransferBookingModal({ isOpen, onClose, bookingData, onComplete }: TransferBookingModalProps) {
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [reference, setReference] = useState('');
  const [animateIn, setAnimateIn] = useState(false);
  const [routePrice, setRoutePrice] = useState<PricingResult | null>(null);
  const [loadingPrice, setLoadingPrice] = useState(false);

  const [transferDetails, setTransferDetails] = useState({
    pickupDate: '',
    pickupTime: '',
    flightNumber: '',
    returnDate: '',
    returnTime: '',
    returnFlightNumber: '',
  });

  const [customerInfo, setCustomerInfo] = useState({
    name: '',
    email: '',
    phone: '',
    specialRequests: '',
  });

  const [paymentMethod, setPaymentMethod] = useState<'card' | 'ideal' | 'paypal' | 'cash'>('card');
  const [cardDetails, setCardDetails] = useState({
    number: '',
    expiry: '',
    cvc: '',
    name: '',
  });
  const [selectedBank, setSelectedBank] = useState('');

  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
      setStep(1);
      setReference('');
      setLoading(false);
      setTransferDetails({
        pickupDate: '',
        pickupTime: '',
        flightNumber: '',
        returnDate: '',
        returnTime: '',
        returnFlightNumber: '',
      });
      setCustomerInfo({
        name: '',
        email: '',
        phone: '',
        specialRequests: '',
      });
      setPaymentMethod('card');
      setCardDetails({
        number: '',
        expiry: '',
        cvc: '',
        name: '',
      });
      setSelectedBank('');
      setTimeout(() => setAnimateIn(true), 50);

      fetchRoutePrice();
    } else {
      document.body.style.overflow = 'unset';
      setAnimateIn(false);
    }
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isOpen]);

  const fetchRoutePrice = async () => {
    if (!bookingData) return;

    setLoadingPrice(true);
    try {
      const airportName = AIRPORT_NAMES[bookingData.airport] || bookingData.airport;
      const tripType = bookingData.tripType === 'Round trip' ? 'roundtrip' : 'oneway';

      console.log('Fetching price for:', {
        airport: bookingData.airport,
        airportName,
        region: bookingData.region,
        vehicle: bookingData.vehicle,
        tripType,
        fallbackPrice: bookingData.price,
      });

      const pricing = await StripeService.getRoutePrice(
        airportName,
        bookingData.region,
        bookingData.vehicle,
        tripType
      );

      console.log('Price fetched:', pricing);
      setRoutePrice(pricing);
    } catch (error) {
      console.error('Error fetching route price:', error);
    } finally {
      setLoadingPrice(false);
    }
  };

  const calculatedPrice = routePrice?.totalPrice || bookingData.price || 0;

  if (!isOpen) return null;

  const isRoundTrip = bookingData.tripType === 'Round trip';

  const handleTransferSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setStep(2);
  };

  const handleCustomerSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setStep(3);
  };

  const handleStripeCheckout = async () => {
    console.log('handleStripeCheckout called with price:', calculatedPrice);

    if (calculatedPrice <= 0) {
      alert('Unable to calculate price for this route. Please select Pay Cash.');
      return;
    }

    setLoading(true);
    try {
      console.log('Creating booking and Stripe checkout...');
      const bookingRef = `TRF-${Date.now().toString(36).toUpperCase()}-${Math.random().toString(36).substring(2, 6).toUpperCase()}`;

      const nameParts = customerInfo.name.trim().split(' ');
      const firstName = nameParts[0] || '';
      const lastName = nameParts.slice(1).join(' ') || nameParts[0] || '';

      let customerId: string;
      const { data: existingCustomer } = await supabase
        .from('customers')
        .select('id')
        .eq('email', customerInfo.email)
        .maybeSingle();

      if (existingCustomer) {
        customerId = existingCustomer.id;
        await supabase
          .from('customers')
          .update({
            phone: customerInfo.phone,
            last_booking_at: new Date().toISOString(),
            updated_at: new Date().toISOString(),
          })
          .eq('id', customerId);
      } else {
        const { data: newCustomer, error: customerError } = await supabase
          .from('customers')
          .insert({
            email: customerInfo.email,
            phone: customerInfo.phone,
            first_name: firstName,
            last_name: lastName,
            customer_type: 'individual',
            vip_status: false,
            total_bookings: 0,
            total_spent: 0,
          })
          .select('id')
          .single();

        if (customerError || !newCustomer) {
          throw new Error('Failed to create customer');
        }
        customerId = newCustomer.id;
      }

      const pickupDateTime = `${transferDetails.pickupDate}T${transferDetails.pickupTime}:00`;
      const airportName = AIRPORT_NAMES[bookingData.airport] || bookingData.airport;

      const { data: crmBooking, error: bookingError } = await supabase
        .from('bookings')
        .insert({
          customer_id: customerId,
          booking_type: 'airport_transfer',
          reference_id: crypto.randomUUID(),
          pickup_address: airportName,
          dropoff_address: bookingData.hotel,
          pickup_datetime: pickupDateTime,
          vehicle_type: bookingData.vehicle,
          passenger_count: bookingData.passengers,
          luggage_count: bookingData.suitcases,
          special_requests: customerInfo.specialRequests,
          price: calculatedPrice,
          status: 'pending',
          payment_status: 'pending',
          workflow_status: 'awaiting_payment',
          details: {
            bookingReference: bookingRef,
            airport: bookingData.airport,
            airportName: airportName,
            region: bookingData.region,
            tripType: bookingData.tripType,
            flightNumber: transferDetails.flightNumber,
            returnDate: transferDetails.returnDate,
            returnTime: transferDetails.returnTime,
            returnFlightNumber: transferDetails.returnFlightNumber,
            paymentMethod: 'stripe',
          },
        })
        .select('id')
        .single();

      if (bookingError || !crmBooking) {
        throw new Error('Failed to create booking');
      }

      const baseUrl = window.location.origin;
      console.log('Calling Stripe checkout with:', {
        bookingId: crmBooking.id,
        amount: calculatedPrice,
        productName: `${bookingData.vehicle} Transfer`,
      });

      const checkoutSession = await StripeService.createDynamicCheckout({
        bookingId: crmBooking.id,
        amount: calculatedPrice,
        currency: 'usd',
        productName: `${bookingData.vehicle} Transfer`,
        productDescription: `${airportName} to ${bookingData.hotel} - ${bookingData.tripType}`,
        customerEmail: customerInfo.email,
        customerName: customerInfo.name,
        successUrl: `${baseUrl}?payment=success&ref=${bookingRef}`,
        cancelUrl: `${baseUrl}?payment=cancelled`,
        metadata: {
          booking_reference: bookingRef,
          route: `${bookingData.airport} to ${bookingData.hotel}`,
          vehicle_type: bookingData.vehicle,
        },
      });

      console.log('Checkout session created:', checkoutSession);

      if (checkoutSession && checkoutSession.url) {
        console.log('Redirecting to Stripe:', checkoutSession.url);
        window.location.href = checkoutSession.url;
      } else {
        throw new Error('Failed to create Stripe checkout session');
      }
    } catch (error: any) {
      console.error('Stripe checkout error:', error);
      const errorMessage = error?.message || 'Unknown error';
      alert(`Payment error: ${errorMessage}. Please try again or select Pay Cash.`);
      setLoading(false);
    }
  };

  const handlePaymentSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Payment submit triggered:', { paymentMethod, calculatedPrice, loading });

    if (paymentMethod === 'card' && calculatedPrice > 0) {
      console.log('Routing to Stripe checkout...');
      await handleStripeCheckout();
      return;
    }

    if (paymentMethod === 'card' && calculatedPrice <= 0) {
      alert('Price not available. Please refresh or select Pay Cash.');
      return;
    }

    setLoading(true);

    try {
      const bookingRef = `TRF-${Date.now().toString(36).toUpperCase()}-${Math.random().toString(36).substring(2, 6).toUpperCase()}`;

      // Split customer name into first and last name
      const nameParts = customerInfo.name.trim().split(' ');
      const firstName = nameParts[0] || '';
      const lastName = nameParts.slice(1).join(' ') || nameParts[0] || '';

      // 1. Create or find customer in CRM
      let customerId: string;
      const { data: existingCustomer } = await supabase
        .from('customers')
        .select('id')
        .eq('email', customerInfo.email)
        .maybeSingle();

      if (existingCustomer) {
        customerId = existingCustomer.id;
        // Update customer info
        await supabase
          .from('customers')
          .update({
            phone: customerInfo.phone,
            last_booking_at: new Date().toISOString(),
            updated_at: new Date().toISOString(),
          })
          .eq('id', customerId);
      } else {
        // Create new customer
        const { data: newCustomer, error: customerError } = await supabase
          .from('customers')
          .insert({
            email: customerInfo.email,
            phone: customerInfo.phone,
            first_name: firstName,
            last_name: lastName,
            customer_type: 'individual',
            vip_status: false,
            total_bookings: 0,
            total_spent: 0,
          })
          .select('id')
          .single();

        if (customerError || !newCustomer) {
          throw new Error('Failed to create customer');
        }
        customerId = newCustomer.id;
      }

      // 2. Create booking in CRM
      const pickupDateTime = `${transferDetails.pickupDate}T${transferDetails.pickupTime}:00`;
      const airportName = AIRPORT_NAMES[bookingData.airport] || bookingData.airport;

      const { data: crmBooking, error: bookingError } = await supabase
        .from('bookings')
        .insert({
          customer_id: customerId,
          booking_type: 'airport_transfer',
          reference_id: crypto.randomUUID(),
          pickup_address: airportName,
          dropoff_address: bookingData.hotel,
          pickup_datetime: pickupDateTime,
          vehicle_type: bookingData.vehicle,
          passenger_count: bookingData.passengers,
          luggage_count: bookingData.suitcases,
          special_requests: customerInfo.specialRequests,
          price: calculatedPrice,
          status: 'confirmed',
          payment_status: 'paid',
          workflow_status: 'pending_dispatch',
          details: {
            bookingReference: bookingRef,
            airport: bookingData.airport,
            airportName: airportName,
            region: bookingData.region,
            tripType: bookingData.tripType,
            flightNumber: transferDetails.flightNumber,
            returnDate: transferDetails.returnDate,
            returnTime: transferDetails.returnTime,
            returnFlightNumber: transferDetails.returnFlightNumber,
            paymentMethod: paymentMethod,
          },
        })
        .select('id')
        .single();

      if (bookingError || !crmBooking) {
        throw new Error('Failed to create CRM booking');
      }

      const orderData = {
        booking_type: 'airport_transfer',
        reference_id: crypto.randomUUID(),
        item_name: `${bookingData.vehicle} Transfer - ${bookingData.airport} to ${bookingData.hotel}`,
        quantity: 1,
        unit_price: calculatedPrice,
        total_price: calculatedPrice,
        customer_email: customerInfo.email,
        customer_name: customerInfo.name,
        check_in_date: transferDetails.pickupDate,
        check_out_date: isRoundTrip ? transferDetails.returnDate : null,
        payment_method: paymentMethod,
        status: 'confirmed',
        payment_status: 'paid',
        stripe_payment_id: `sim_${paymentMethod}_${Math.random().toString(36).substr(2, 9)}`,
        details: {
          phone: customerInfo.phone,
          airport: bookingData.airport,
          airportName: airportName,
          hotel: bookingData.hotel,
          region: bookingData.region,
          vehicle: bookingData.vehicle,
          passengers: bookingData.passengers,
          suitcases: bookingData.suitcases,
          tripType: bookingData.tripType,
          pickupTime: transferDetails.pickupTime,
          flightNumber: transferDetails.flightNumber,
          returnDate: transferDetails.returnDate,
          returnTime: transferDetails.returnTime,
          returnFlightNumber: transferDetails.returnFlightNumber,
          specialRequests: customerInfo.specialRequests,
          bookingReference: bookingRef,
          crmBookingId: crmBooking.id,
        }
      };

      await supabase.from('orders').insert(orderData);

      // 4. Trigger auto-dispatch to assign driver and vehicle
      try {
        const dispatchResponse = await fetch(
          `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/auto-dispatch`,
          {
            method: 'POST',
            headers: {
              'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              booking_id: crmBooking.id,
              vehicle_type: bookingData.vehicle,
              pickup_datetime: pickupDateTime,
            }),
          }
        );

        if (dispatchResponse.ok) {
          const dispatchData = await dispatchResponse.json();
          console.log('Auto-dispatch successful:', dispatchData);
        } else {
          console.warn('Auto-dispatch failed, will need manual assignment');
        }
      } catch (dispatchError) {
        console.warn('Auto-dispatch error:', dispatchError);
        // Continue even if dispatch fails - admin can manually assign
      }

      await new Promise(resolve => setTimeout(resolve, 1500));

      setReference(bookingRef);
      setStep(4);
      onComplete(bookingRef);
    } catch (error) {
      console.error('Booking error:', error);
      alert('Failed to complete booking. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const formatCardNumber = (value: string) => {
    const v = value.replace(/\s+/g, '').replace(/[^0-9]/gi, '');
    const matches = v.match(/\d{4,16}/g);
    const match = (matches && matches[0]) || '';
    const parts = [];
    for (let i = 0, len = match.length; i < len; i += 4) {
      parts.push(match.substring(i, i + 4));
    }
    return parts.length ? parts.join(' ') : value;
  };

  const formatExpiry = (value: string) => {
    const v = value.replace(/\s+/g, '').replace(/[^0-9]/gi, '');
    if (v.length >= 2) {
      return v.substring(0, 2) + '/' + v.substring(2, 4);
    }
    return v;
  };

  const renderStep = () => {
    switch (step) {
      case 1:
        return (
          <form onSubmit={handleTransferSubmit} className="space-y-6">
            <div className="bg-gradient-to-r from-blue-500/10 to-cyan-500/10 border border-blue-500/20 rounded-2xl p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-white/70 text-xs uppercase tracking-wider">Private Transfer</p>
                  <h3 className="text-white text-xl font-bold">{bookingData.vehicle}</h3>
                </div>
                <div className="text-right">
                  <p className="text-white/70 text-xs">Total</p>
                  <p className="text-2xl font-bold text-white">${calculatedPrice}</p>
                  {loadingPrice && <p className="text-white/50 text-xs">Loading...</p>}
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="bg-white/5 rounded-xl p-3 border border-white/10">
                <div className="flex items-center gap-2 mb-1">
                  <Plane className="w-4 h-4 text-blue-400" />
                  <span className="text-white/50 text-xs">From</span>
                </div>
                <p className="text-white font-medium text-sm truncate" title={AIRPORT_NAMES[bookingData.airport] || bookingData.airport}>
                  {AIRPORT_NAMES[bookingData.airport] || bookingData.airport}
                </p>
                <p className="text-white/40 text-xs">{bookingData.airport}</p>
              </div>
              <div className="bg-white/5 rounded-xl p-3 border border-white/10">
                <div className="flex items-center gap-2 mb-1">
                  <MapPin className="w-4 h-4 text-emerald-400" />
                  <span className="text-white/50 text-xs">To</span>
                </div>
                <p className="text-white font-medium text-sm truncate" title={bookingData.hotel}>{bookingData.hotel}</p>
                <p className="text-white/40 text-xs">{bookingData.region}</p>
              </div>
              <div className="bg-white/5 rounded-xl p-3 border border-white/10">
                <div className="flex items-center gap-2 mb-1">
                  <Users className="w-4 h-4 text-amber-400" />
                  <span className="text-white/50 text-xs">Passengers</span>
                </div>
                <p className="text-white font-medium text-sm">{bookingData.passengers} people</p>
              </div>
              <div className="bg-white/5 rounded-xl p-3 border border-white/10">
                <div className="flex items-center gap-2 mb-1">
                  <Briefcase className="w-4 h-4 text-cyan-400" />
                  <span className="text-white/50 text-xs">Luggage</span>
                </div>
                <p className="text-white font-medium text-sm">{bookingData.suitcases} bags</p>
              </div>
            </div>

            <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-blue-500/10 border border-blue-500/20 rounded-full">
              <ArrowRight className="w-3.5 h-3.5 text-blue-400" />
              <span className="text-blue-400 text-sm font-medium">{bookingData.tripType}</span>
            </div>

            <div className="space-y-4">
              <h4 className="text-white font-semibold flex items-center gap-2">
                <Calendar className="w-4 h-4 text-blue-400" />
                Arrival Details
              </h4>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-white/60 text-xs mb-2">Pickup Date</label>
                  <input
                    type="date"
                    value={transferDetails.pickupDate}
                    onChange={(e) => setTransferDetails({ ...transferDetails, pickupDate: e.target.value })}
                    required
                    min={new Date().toISOString().split('T')[0]}
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500/50 transition-all"
                  />
                </div>
                <div>
                  <label className="block text-white/60 text-xs mb-2">Pickup Time</label>
                  <input
                    type="time"
                    value={transferDetails.pickupTime}
                    onChange={(e) => setTransferDetails({ ...transferDetails, pickupTime: e.target.value })}
                    required
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500/50 transition-all"
                  />
                </div>
              </div>

              <div>
                <label className="block text-white/60 text-xs mb-2">Flight Number (optional)</label>
                <div className="relative">
                  <Plane className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/40" />
                  <input
                    type="text"
                    value={transferDetails.flightNumber}
                    onChange={(e) => setTransferDetails({ ...transferDetails, flightNumber: e.target.value.toUpperCase() })}
                    placeholder="e.g., AA1234"
                    className="w-full bg-white/5 border border-white/10 rounded-xl pl-10 pr-4 py-3 text-white text-sm placeholder-white/30 focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500/50 transition-all"
                  />
                </div>
              </div>

              {isRoundTrip && (
                <>
                  <h4 className="text-white font-semibold flex items-center gap-2 pt-2">
                    <Calendar className="w-4 h-4 text-emerald-400" />
                    Return Details
                  </h4>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-white/60 text-xs mb-2">Return Date</label>
                      <input
                        type="date"
                        value={transferDetails.returnDate}
                        onChange={(e) => setTransferDetails({ ...transferDetails, returnDate: e.target.value })}
                        required
                        min={transferDetails.pickupDate || new Date().toISOString().split('T')[0]}
                        className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/50 focus:border-emerald-500/50 transition-all"
                      />
                    </div>
                    <div>
                      <label className="block text-white/60 text-xs mb-2">Return Time</label>
                      <input
                        type="time"
                        value={transferDetails.returnTime}
                        onChange={(e) => setTransferDetails({ ...transferDetails, returnTime: e.target.value })}
                        required
                        className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/50 focus:border-emerald-500/50 transition-all"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-white/60 text-xs mb-2">Return Flight Number (optional)</label>
                    <div className="relative">
                      <Plane className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/40" />
                      <input
                        type="text"
                        value={transferDetails.returnFlightNumber}
                        onChange={(e) => setTransferDetails({ ...transferDetails, returnFlightNumber: e.target.value.toUpperCase() })}
                        placeholder="e.g., AA5678"
                        className="w-full bg-white/5 border border-white/10 rounded-xl pl-10 pr-4 py-3 text-white text-sm placeholder-white/30 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 focus:border-emerald-500/50 transition-all"
                      />
                    </div>
                  </div>
                </>
              )}
            </div>

            <button
              type="submit"
              className="w-full py-4 rounded-xl bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white font-semibold transition-all shadow-lg shadow-blue-500/25 hover:shadow-blue-500/40 flex items-center justify-center gap-2"
            >
              Continue
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>
        );

      case 2:
        return (
          <form onSubmit={handleCustomerSubmit} className="space-y-6">
            <div className="text-center mb-2">
              <div className="w-14 h-14 rounded-full bg-gradient-to-br from-blue-500/20 to-cyan-500/20 flex items-center justify-center mx-auto mb-3">
                <User className="w-7 h-7 text-blue-400" />
              </div>
              <h3 className="text-white text-lg font-semibold">Contact Information</h3>
              <p className="text-white/50 text-sm">How can we reach you?</p>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-white/60 text-xs mb-2">Full Name</label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/40" />
                  <input
                    type="text"
                    value={customerInfo.name}
                    onChange={(e) => setCustomerInfo({ ...customerInfo, name: e.target.value })}
                    required
                    placeholder="John Smith"
                    className="w-full bg-white/5 border border-white/10 rounded-xl pl-10 pr-4 py-3 text-white text-sm placeholder-white/30 focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500/50 transition-all"
                  />
                </div>
              </div>

              <div>
                <label className="block text-white/60 text-xs mb-2">Email Address</label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/40" />
                  <input
                    type="email"
                    value={customerInfo.email}
                    onChange={(e) => setCustomerInfo({ ...customerInfo, email: e.target.value })}
                    required
                    placeholder="john@email.com"
                    className="w-full bg-white/5 border border-white/10 rounded-xl pl-10 pr-4 py-3 text-white text-sm placeholder-white/30 focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500/50 transition-all"
                  />
                </div>
              </div>

              <div>
                <label className="block text-white/60 text-xs mb-2">Phone Number</label>
                <div className="relative">
                  <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/40" />
                  <input
                    type="tel"
                    value={customerInfo.phone}
                    onChange={(e) => setCustomerInfo({ ...customerInfo, phone: e.target.value })}
                    required
                    placeholder="+1 555 123 4567"
                    className="w-full bg-white/5 border border-white/10 rounded-xl pl-10 pr-4 py-3 text-white text-sm placeholder-white/30 focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500/50 transition-all"
                  />
                </div>
              </div>

              <div>
                <label className="block text-white/60 text-xs mb-2">Special Requests (optional)</label>
                <textarea
                  value={customerInfo.specialRequests}
                  onChange={(e) => setCustomerInfo({ ...customerInfo, specialRequests: e.target.value })}
                  placeholder="Child seat, wheelchair access, extra stops..."
                  rows={3}
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white text-sm placeholder-white/30 focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500/50 transition-all resize-none"
                />
              </div>
            </div>

            <div className="flex gap-3">
              <button
                type="button"
                onClick={() => setStep(1)}
                className="flex-1 py-3 rounded-xl bg-white/5 border border-white/10 text-white font-medium hover:bg-white/10 transition-all"
              >
                Back
              </button>
              <button
                type="submit"
                className="flex-1 py-3 rounded-xl bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white font-semibold transition-all shadow-lg shadow-blue-500/25 flex items-center justify-center gap-2"
              >
                Continue
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </form>
        );

      case 3:
        return (
          <form onSubmit={handlePaymentSubmit} className="space-y-6">
            <div className="text-center mb-2">
              <div className="w-14 h-14 rounded-full bg-gradient-to-br from-emerald-500/20 to-teal-500/20 flex items-center justify-center mx-auto mb-3">
                <CreditCard className="w-7 h-7 text-emerald-400" />
              </div>
              <h3 className="text-white text-lg font-semibold">Payment</h3>
              <p className="text-white/50 text-sm">Secure checkout</p>
            </div>

            <div className="bg-gradient-to-r from-blue-500/10 to-cyan-500/10 border border-blue-500/20 rounded-xl p-4">
              <div className="flex justify-between items-center">
                <div>
                  <p className="text-white/60 text-xs">Total Amount</p>
                  <p className="text-2xl font-bold text-white">${calculatedPrice} USD</p>
                </div>
                <div className="flex items-center gap-1.5 text-emerald-400">
                  <Shield className="w-4 h-4" />
                  <span className="text-xs font-medium">Secure</span>
                </div>
              </div>
            </div>

            <div className="space-y-3">
              <button
                type="button"
                onClick={() => setPaymentMethod('card')}
                className={`w-full p-4 rounded-xl border-2 transition-all text-left ${
                  paymentMethod === 'card'
                    ? 'bg-blue-500/20 border-blue-500/50'
                    : 'bg-white/5 border-white/10 hover:bg-white/10 hover:border-white/20'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                    paymentMethod === 'card' ? 'bg-blue-500/30' : 'bg-white/10'
                  }`}>
                    <CreditCard className={`w-5 h-5 ${paymentMethod === 'card' ? 'text-blue-400' : 'text-white/60'}`} />
                  </div>
                  <div className="flex-1">
                    <p className={`font-medium text-sm ${paymentMethod === 'card' ? 'text-blue-400' : 'text-white'}`}>
                      Pay with Card via Stripe
                    </p>
                    <p className={`text-xs ${paymentMethod === 'card' ? 'text-blue-400/70' : 'text-white/50'}`}>
                      Secure payment processing
                    </p>
                  </div>
                  {paymentMethod === 'card' && (
                    <CheckCircle className="w-5 h-5 text-blue-400" />
                  )}
                </div>
              </button>

              <button
                type="button"
                onClick={() => setPaymentMethod('cash')}
                className={`w-full p-4 rounded-xl border-2 transition-all text-left ${
                  paymentMethod === 'cash'
                    ? 'bg-amber-500/20 border-amber-500/50'
                    : 'bg-white/5 border-white/10 hover:bg-white/10 hover:border-white/20'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                    paymentMethod === 'cash' ? 'bg-amber-500/30' : 'bg-white/10'
                  }`}>
                    <span className={`text-lg ${paymentMethod === 'cash' ? 'text-amber-400' : 'text-white/60'}`}>$</span>
                  </div>
                  <div className="flex-1">
                    <p className={`font-medium text-sm ${paymentMethod === 'cash' ? 'text-amber-400' : 'text-white'}`}>
                      Pay Cash to Driver
                    </p>
                    <p className={`text-xs ${paymentMethod === 'cash' ? 'text-amber-400/70' : 'text-white/50'}`}>
                      Pay ${calculatedPrice} USD upon arrival
                    </p>
                  </div>
                  {paymentMethod === 'cash' && (
                    <CheckCircle className="w-5 h-5 text-amber-400" />
                  )}
                </div>
              </button>
            </div>

            {paymentMethod === 'card' && (
              <div className="bg-blue-500/10 border border-blue-500/20 rounded-xl p-4">
                <div className="flex items-start gap-3">
                  <Shield className="w-5 h-5 text-blue-400 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="text-blue-400 font-medium text-sm">Secure Stripe Checkout</p>
                    <p className="text-blue-400/70 text-xs mt-1">You'll be redirected to Stripe's secure payment page to complete your booking.</p>
                  </div>
                </div>
              </div>
            )}

            <div className="flex gap-3">
              <button
                type="button"
                onClick={() => setStep(2)}
                className="flex-1 py-3 rounded-xl bg-white/5 border border-white/10 text-white font-medium hover:bg-white/10 transition-all"
              >
                Back
              </button>
              <button
                type="submit"
                disabled={loading || (paymentMethod === 'card' && calculatedPrice <= 0)}
                className="flex-1 py-3 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 text-white font-semibold transition-all shadow-lg shadow-emerald-500/25 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                title={paymentMethod === 'card' && calculatedPrice <= 0 ? 'Price unavailable. Please select "Pay Cash"' : ''}
              >
                {loading ? (
                  <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                ) : (
                  <>
                    {paymentMethod === 'card' ? (calculatedPrice > 0 ? 'Pay with Stripe' : 'Price Unavailable') : 'Complete Booking'}
                    <CheckCircle className="w-4 h-4" />
                  </>
                )}
              </button>
            </div>
          </form>
        );

      case 4:
        return (
          <div className="text-center space-y-6 py-4">
            <div className="relative">
              <div className="w-20 h-20 rounded-full bg-gradient-to-br from-emerald-500/20 to-teal-500/20 flex items-center justify-center mx-auto animate-pulse">
                <CheckCircle className="w-10 h-10 text-emerald-400" />
              </div>
              <div className="absolute inset-0 flex items-center justify-center">
                <Sparkles className="w-6 h-6 text-amber-400 absolute -top-2 -right-8 animate-bounce" />
                <Sparkles className="w-4 h-4 text-blue-400 absolute -bottom-1 -left-6 animate-bounce delay-100" />
              </div>
            </div>

            <div>
              <h3 className="text-2xl font-bold text-white mb-2">Booking Confirmed!</h3>
              <p className="text-white/60">Your private transfer is all set</p>
            </div>

            <div className="bg-gradient-to-r from-emerald-500/10 to-teal-500/10 border border-emerald-500/20 rounded-xl p-4">
              <p className="text-white/50 text-xs mb-1">Confirmation Number</p>
              <p className="text-xl font-bold text-emerald-400 font-mono">{reference}</p>
            </div>

            <div className="bg-white/5 rounded-xl p-4 text-left space-y-3 border border-white/10">
              <div className="flex justify-between items-center gap-2">
                <span className="text-white/50 text-sm flex-shrink-0">Route</span>
                <span className="text-white text-sm font-medium text-right truncate">{bookingData.airport} → {bookingData.hotel}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-white/50 text-sm">Date</span>
                <span className="text-white text-sm font-medium">{transferDetails.pickupDate}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-white/50 text-sm">Time</span>
                <span className="text-white text-sm font-medium">{transferDetails.pickupTime}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-white/50 text-sm">Vehicle</span>
                <span className="text-white text-sm font-medium">{bookingData.vehicle}</span>
              </div>
              <div className="h-px bg-white/10" />
              <div className="flex justify-between items-center">
                <span className="text-white/50 text-sm">Total Paid</span>
                <span className="text-emerald-400 font-bold">${calculatedPrice} USD</span>
              </div>
            </div>

            <div className="bg-blue-500/10 border border-blue-500/20 rounded-xl p-3">
              <p className="text-blue-400 text-sm">
                Confirmation sent to <span className="font-medium">{customerInfo.email}</span>
              </p>
            </div>

            <button
              onClick={onClose}
              className="w-full py-4 rounded-xl bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white font-semibold transition-all shadow-lg shadow-blue-500/25"
            >
              Done
            </button>
          </div>
        );

      default:
        return null;
    }
  };

  return createPortal(
    <div className="fixed inset-0 z-[9999] flex items-end sm:items-center justify-center">
      <div
        className={`absolute inset-0 bg-black/80 backdrop-blur-sm transition-opacity duration-300 ${
          animateIn ? 'opacity-100' : 'opacity-0'
        }`}
        onClick={step !== 4 ? onClose : undefined}
      />

      <div
        className={`relative w-full sm:max-w-md bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 rounded-t-3xl sm:rounded-3xl border-t sm:border border-white/10 shadow-2xl max-h-[92vh] sm:max-h-[90vh] overflow-hidden flex flex-col transition-all duration-500 ${
          animateIn ? 'translate-y-0 opacity-100' : 'translate-y-full sm:translate-y-8 opacity-0'
        }`}
      >
        <div className="flex items-center justify-between p-4 border-b border-white/10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center">
              <Car className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="text-white font-bold">Book Transfer</h2>
              {step < 4 && (
                <p className="text-white/50 text-xs">Step {step} of 3</p>
              )}
            </div>
          </div>

          {step !== 4 && (
            <button
              onClick={onClose}
              className="w-10 h-10 rounded-xl bg-white/5 hover:bg-white/10 flex items-center justify-center text-white/60 hover:text-white transition-all"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>

        {step < 4 && (
          <div className="px-4 pt-3">
            <div className="flex gap-1.5">
              {[1, 2, 3].map((s) => (
                <div
                  key={s}
                  className={`h-1 flex-1 rounded-full transition-all duration-500 ${
                    s < step ? 'bg-emerald-500' : s === step ? 'bg-blue-500' : 'bg-white/10'
                  }`}
                />
              ))}
            </div>
          </div>
        )}

        <div className="flex-1 overflow-y-auto p-4">
          {renderStep()}
        </div>
      </div>
    </div>,
    document.body
  );
}
