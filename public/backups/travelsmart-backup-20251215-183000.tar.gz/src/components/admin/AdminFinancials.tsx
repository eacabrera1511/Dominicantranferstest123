import { useState, useEffect } from 'react';
import {
  DollarSign, TrendingUp, TrendingDown, CreditCard, Cpu,
  Cloud, Percent, Download, Calendar, ArrowUpRight, ArrowDownRight
} from 'lucide-react';
import { supabase } from '../../lib/supabase';

interface FinancialData {
  metric_date: string;
  total_revenue: number;
  total_bookings_value: number;
  commission_earned: number;
  llm_api_costs: number;
  cloud_hosting_costs: number;
  payment_processing_fees: number;
  other_costs: number;
  net_profit: number;
}

interface LLMUsage {
  model: string;
  total_tokens: number;
  total_cost: number;
  call_count: number;
}

export function AdminFinancials() {
  const [dateRange, setDateRange] = useState<'7d' | '30d' | '90d'>('30d');
  const [financialData, setFinancialData] = useState<FinancialData[]>([]);
  const [llmUsage, setLlmUsage] = useState<LLMUsage[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchFinancialData();
  }, [dateRange]);

  const fetchFinancialData = async () => {
    setLoading(true);
    const days = dateRange === '7d' ? 7 : dateRange === '30d' ? 30 : 90;
    const startDate = new Date(Date.now() - days * 86400000).toISOString().split('T')[0];

    const [financialRes, llmRes] = await Promise.all([
      supabase
        .from('financial_metrics')
        .select('*')
        .gte('metric_date', startDate)
        .order('metric_date', { ascending: true }),
      supabase
        .from('llm_usage_logs')
        .select('model, tokens_input, tokens_output, cost')
        .gte('timestamp', new Date(Date.now() - days * 86400000).toISOString()),
    ]);

    if (financialRes.data) {
      setFinancialData(financialRes.data);
    }

    if (llmRes.data) {
      const grouped = llmRes.data.reduce((acc: Record<string, LLMUsage>, log) => {
        if (!acc[log.model]) {
          acc[log.model] = { model: log.model, total_tokens: 0, total_cost: 0, call_count: 0 };
        }
        acc[log.model].total_tokens += (log.tokens_input || 0) + (log.tokens_output || 0);
        acc[log.model].total_cost += Number(log.cost) || 0;
        acc[log.model].call_count += 1;
        return acc;
      }, {});
      setLlmUsage(Object.values(grouped));
    }

    setLoading(false);
  };

  const totals = financialData.reduce(
    (acc, d) => ({
      revenue: acc.revenue + Number(d.total_revenue),
      bookingsValue: acc.bookingsValue + Number(d.total_bookings_value),
      commission: acc.commission + Number(d.commission_earned),
      llmCosts: acc.llmCosts + Number(d.llm_api_costs),
      hostingCosts: acc.hostingCosts + Number(d.cloud_hosting_costs),
      paymentFees: acc.paymentFees + Number(d.payment_processing_fees),
      otherCosts: acc.otherCosts + Number(d.other_costs),
      netProfit: acc.netProfit + Number(d.net_profit),
    }),
    { revenue: 0, bookingsValue: 0, commission: 0, llmCosts: 0, hostingCosts: 0, paymentFees: 0, otherCosts: 0, netProfit: 0 }
  );

  const totalCosts = totals.llmCosts + totals.hostingCosts + totals.paymentFees + totals.otherCosts;
  const profitMargin = totals.revenue > 0 ? (totals.netProfit / totals.revenue) * 100 : 0;

  const exportCSV = () => {
    const headers = ['Date', 'Revenue', 'GMV', 'Commission', 'LLM Costs', 'Hosting', 'Payment Fees', 'Other', 'Net Profit'];
    const rows = financialData.map(d => [
      d.metric_date,
      d.total_revenue,
      d.total_bookings_value,
      d.commission_earned,
      d.llm_api_costs,
      d.cloud_hosting_costs,
      d.payment_processing_fees,
      d.other_costs,
      d.net_profit
    ]);

    const csv = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `financial-report-${dateRange}.csv`;
    a.click();
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="w-8 h-8 border-2 border-red-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white">Financial Metrics</h1>
          <p className="text-gray-400 mt-1">Revenue, costs, and profitability analysis</p>
        </div>

        <div className="flex items-center gap-3">
          <div className="flex bg-white/5 rounded-xl p-1">
            {(['7d', '30d', '90d'] as const).map((range) => (
              <button
                key={range}
                onClick={() => setDateRange(range)}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                  dateRange === range
                    ? 'bg-red-500/20 text-red-400'
                    : 'text-gray-400 hover:text-white'
                }`}
              >
                {range === '7d' ? '7 Days' : range === '30d' ? '30 Days' : '90 Days'}
              </button>
            ))}
          </div>
          <button
            onClick={exportCSV}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-white/5 text-gray-400 hover:bg-white/10 hover:text-white transition-all"
          >
            <Download className="w-4 h-4" />
            Export
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white/5 backdrop-blur-xl rounded-xl border border-white/10 p-5">
          <div className="flex items-center justify-between mb-3">
            <div className="p-2.5 rounded-xl bg-green-500/20">
              <DollarSign className="w-5 h-5 text-green-400" />
            </div>
            <TrendingUp className="w-5 h-5 text-green-400" />
          </div>
          <p className="text-gray-400 text-sm mb-1">Total Revenue</p>
          <p className="text-2xl font-bold text-white">EUR {totals.revenue.toFixed(2)}</p>
        </div>

        <div className="bg-white/5 backdrop-blur-xl rounded-xl border border-white/10 p-5">
          <div className="flex items-center justify-between mb-3">
            <div className="p-2.5 rounded-xl bg-blue-500/20">
              <CreditCard className="w-5 h-5 text-blue-400" />
            </div>
          </div>
          <p className="text-gray-400 text-sm mb-1">Gross Merchandise Value</p>
          <p className="text-2xl font-bold text-white">EUR {totals.bookingsValue.toFixed(2)}</p>
        </div>

        <div className="bg-white/5 backdrop-blur-xl rounded-xl border border-white/10 p-5">
          <div className="flex items-center justify-between mb-3">
            <div className="p-2.5 rounded-xl bg-red-500/20">
              <TrendingDown className="w-5 h-5 text-red-400" />
            </div>
          </div>
          <p className="text-gray-400 text-sm mb-1">Total Costs</p>
          <p className="text-2xl font-bold text-white">EUR {totalCosts.toFixed(2)}</p>
        </div>

        <div className="bg-white/5 backdrop-blur-xl rounded-xl border border-white/10 p-5">
          <div className="flex items-center justify-between mb-3">
            <div className="p-2.5 rounded-xl bg-amber-500/20">
              <Percent className="w-5 h-5 text-amber-400" />
            </div>
            {profitMargin > 0 ? (
              <ArrowUpRight className="w-5 h-5 text-green-400" />
            ) : (
              <ArrowDownRight className="w-5 h-5 text-red-400" />
            )}
          </div>
          <p className="text-gray-400 text-sm mb-1">Profit Margin</p>
          <p className={`text-2xl font-bold ${profitMargin > 0 ? 'text-green-400' : 'text-red-400'}`}>
            {profitMargin.toFixed(1)}%
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white/5 backdrop-blur-xl rounded-xl border border-white/10 p-5">
          <h2 className="text-lg font-semibold text-white mb-4">Cost Breakdown</h2>

          <div className="space-y-4">
            <div>
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <Cpu className="w-4 h-4 text-blue-400" />
                  <span className="text-gray-400 text-sm">LLM API Costs</span>
                </div>
                <span className="text-white font-medium">EUR {totals.llmCosts.toFixed(2)}</span>
              </div>
              <div className="h-3 bg-white/10 rounded-full overflow-hidden">
                <div
                  className="h-full bg-blue-500 rounded-full"
                  style={{ width: `${(totals.llmCosts / totalCosts) * 100}%` }}
                />
              </div>
              <p className="text-gray-500 text-xs mt-1">
                {((totals.llmCosts / totalCosts) * 100).toFixed(1)}% of total costs
              </p>
            </div>

            <div>
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <Cloud className="w-4 h-4 text-green-400" />
                  <span className="text-gray-400 text-sm">Cloud Hosting</span>
                </div>
                <span className="text-white font-medium">EUR {totals.hostingCosts.toFixed(2)}</span>
              </div>
              <div className="h-3 bg-white/10 rounded-full overflow-hidden">
                <div
                  className="h-full bg-green-500 rounded-full"
                  style={{ width: `${(totals.hostingCosts / totalCosts) * 100}%` }}
                />
              </div>
              <p className="text-gray-500 text-xs mt-1">
                {((totals.hostingCosts / totalCosts) * 100).toFixed(1)}% of total costs
              </p>
            </div>

            <div>
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <CreditCard className="w-4 h-4 text-amber-400" />
                  <span className="text-gray-400 text-sm">Payment Processing</span>
                </div>
                <span className="text-white font-medium">EUR {totals.paymentFees.toFixed(2)}</span>
              </div>
              <div className="h-3 bg-white/10 rounded-full overflow-hidden">
                <div
                  className="h-full bg-amber-500 rounded-full"
                  style={{ width: `${(totals.paymentFees / totalCosts) * 100}%` }}
                />
              </div>
              <p className="text-gray-500 text-xs mt-1">
                {((totals.paymentFees / totalCosts) * 100).toFixed(1)}% of total costs
              </p>
            </div>

            <div>
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 rounded-full bg-gray-500" />
                  <span className="text-gray-400 text-sm">Other Costs</span>
                </div>
                <span className="text-white font-medium">EUR {totals.otherCosts.toFixed(2)}</span>
              </div>
              <div className="h-3 bg-white/10 rounded-full overflow-hidden">
                <div
                  className="h-full bg-gray-500 rounded-full"
                  style={{ width: `${(totals.otherCosts / totalCosts) * 100}%` }}
                />
              </div>
              <p className="text-gray-500 text-xs mt-1">
                {((totals.otherCosts / totalCosts) * 100).toFixed(1)}% of total costs
              </p>
            </div>
          </div>
        </div>

        <div className="bg-white/5 backdrop-blur-xl rounded-xl border border-white/10 p-5">
          <h2 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
            <Cpu className="w-5 h-5 text-blue-400" />
            LLM Usage by Model
          </h2>

          {llmUsage.length === 0 ? (
            <p className="text-gray-500 text-center py-8">No LLM usage data available</p>
          ) : (
            <div className="space-y-4">
              {llmUsage.map((usage) => (
                <div key={usage.model} className="p-4 rounded-xl bg-white/5">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-white font-medium">{usage.model}</span>
                    <span className="text-green-400 font-medium">EUR {usage.total_cost.toFixed(4)}</span>
                  </div>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <p className="text-gray-500">Total Tokens</p>
                      <p className="text-gray-300">{usage.total_tokens.toLocaleString()}</p>
                    </div>
                    <div>
                      <p className="text-gray-500">API Calls</p>
                      <p className="text-gray-300">{usage.call_count.toLocaleString()}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      <div className="bg-white/5 backdrop-blur-xl rounded-xl border border-white/10 p-5">
        <h2 className="text-lg font-semibold text-white mb-4">Daily Financial Summary</h2>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-white/10">
                <th className="text-left text-gray-400 text-sm font-medium pb-3">Date</th>
                <th className="text-right text-gray-400 text-sm font-medium pb-3">Revenue</th>
                <th className="text-right text-gray-400 text-sm font-medium pb-3">GMV</th>
                <th className="text-right text-gray-400 text-sm font-medium pb-3">LLM Costs</th>
                <th className="text-right text-gray-400 text-sm font-medium pb-3">Hosting</th>
                <th className="text-right text-gray-400 text-sm font-medium pb-3">Net Profit</th>
              </tr>
            </thead>
            <tbody>
              {financialData.slice(-10).reverse().map((day) => (
                <tr key={day.metric_date} className="border-b border-white/5">
                  <td className="py-3 text-white text-sm">
                    {new Date(day.metric_date).toLocaleDateString('en', { month: 'short', day: 'numeric' })}
                  </td>
                  <td className="py-3 text-right text-white text-sm">EUR {Number(day.total_revenue).toFixed(2)}</td>
                  <td className="py-3 text-right text-gray-400 text-sm">EUR {Number(day.total_bookings_value).toFixed(2)}</td>
                  <td className="py-3 text-right text-gray-400 text-sm">EUR {Number(day.llm_api_costs).toFixed(2)}</td>
                  <td className="py-3 text-right text-gray-400 text-sm">EUR {Number(day.cloud_hosting_costs).toFixed(2)}</td>
                  <td className={`py-3 text-right text-sm font-medium ${Number(day.net_profit) > 0 ? 'text-green-400' : 'text-red-400'}`}>
                    EUR {Number(day.net_profit).toFixed(2)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
