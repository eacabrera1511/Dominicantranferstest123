import { useState, useEffect } from 'react';
import { Calendar, Search, Filter, Eye, MapPin, User, DollarSign, Clock, MessageSquare } from 'lucide-react';
import { supabase } from '../../lib/supabase';

interface Booking {
  id: string;
  reference: string;
  customer_name: string;
  customer_email: string;
  customer_phone: string;
  pickup_location: string;
  dropoff_location: string;
  pickup_datetime: string;
  passengers: number;
  total_price: number;
  status: 'pending' | 'confirmed' | 'in_progress' | 'completed' | 'cancelled';
  payment_status: 'pending' | 'paid' | 'refunded';
  source: 'chat' | 'web' | 'phone' | 'partner';
  special_requests?: string;
  created_at: string;
}

export function AdminBookings() {
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [sourceFilter, setSourceFilter] = useState<string>('all');
  const [selectedBooking, setSelectedBooking] = useState<Booking | null>(null);

  useEffect(() => {
    fetchBookings();

    const subscription = supabase
      .channel('bookings_changes')
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'bookings'
      }, () => {
        fetchBookings();
      })
      .subscribe();

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  const fetchBookings = async () => {
    setLoading(true);

    const { data } = await supabase
      .from('bookings')
      .select('*')
      .order('created_at', { ascending: false });

    if (data) {
      setBookings(data);
    }

    setLoading(false);
  };

  const updateBookingStatus = async (id: string, status: Booking['status']) => {
    const { error } = await supabase
      .from('bookings')
      .update({ status })
      .eq('id', id);

    if (!error) {
      fetchBookings();
      if (selectedBooking?.id === id) {
        setSelectedBooking({ ...selectedBooking, status });
      }
    }
  };

  const filteredBookings = bookings.filter(b => {
    const matchesSearch =
      b.customer_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      b.customer_email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      b.reference.toLowerCase().includes(searchTerm.toLowerCase()) ||
      b.pickup_location.toLowerCase().includes(searchTerm.toLowerCase()) ||
      b.dropoff_location.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesStatus = statusFilter === 'all' || b.status === statusFilter;
    const matchesSource = sourceFilter === 'all' || b.source === sourceFilter;

    return matchesSearch && matchesStatus && matchesSource;
  });

  const stats = {
    total: bookings.length,
    pending: bookings.filter(b => b.status === 'pending').length,
    confirmed: bookings.filter(b => b.status === 'confirmed').length,
    inProgress: bookings.filter(b => b.status === 'in_progress').length,
    completed: bookings.filter(b => b.status === 'completed').length,
    totalRevenue: bookings
      .filter(b => b.payment_status === 'paid')
      .reduce((sum, b) => sum + b.total_price, 0),
    chatBookings: bookings.filter(b => b.source === 'chat').length,
  };

  const statusColors = {
    pending: 'text-amber-400 bg-amber-500/20',
    confirmed: 'text-blue-400 bg-blue-500/20',
    in_progress: 'text-cyan-400 bg-cyan-500/20',
    completed: 'text-green-400 bg-green-500/20',
    cancelled: 'text-red-400 bg-red-500/20',
  };

  const sourceIcons = {
    chat: <MessageSquare className="w-3 h-3" />,
    web: <Calendar className="w-3 h-3" />,
    phone: <User className="w-3 h-3" />,
    partner: <MapPin className="w-3 h-3" />,
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="w-8 h-8 border-2 border-red-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white">Bookings</h1>
          <p className="text-gray-400 mt-1">All bookings including AI chat reservations</p>
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
        <div className="bg-white/5 backdrop-blur-xl rounded-xl border border-white/10 p-4">
          <p className="text-gray-400 text-xs mb-1">Total</p>
          <p className="text-xl font-bold text-white">{stats.total}</p>
        </div>
        <div className="bg-white/5 backdrop-blur-xl rounded-xl border border-white/10 p-4">
          <p className="text-gray-400 text-xs mb-1">Pending</p>
          <p className="text-xl font-bold text-amber-400">{stats.pending}</p>
        </div>
        <div className="bg-white/5 backdrop-blur-xl rounded-xl border border-white/10 p-4">
          <p className="text-gray-400 text-xs mb-1">Confirmed</p>
          <p className="text-xl font-bold text-blue-400">{stats.confirmed}</p>
        </div>
        <div className="bg-white/5 backdrop-blur-xl rounded-xl border border-white/10 p-4">
          <p className="text-gray-400 text-xs mb-1">In Progress</p>
          <p className="text-xl font-bold text-cyan-400">{stats.inProgress}</p>
        </div>
        <div className="bg-white/5 backdrop-blur-xl rounded-xl border border-white/10 p-4">
          <p className="text-gray-400 text-xs mb-1">Completed</p>
          <p className="text-xl font-bold text-green-400">{stats.completed}</p>
        </div>
        <div className="bg-white/5 backdrop-blur-xl rounded-xl border border-white/10 p-4">
          <p className="text-gray-400 text-xs mb-1">AI Chat</p>
          <p className="text-xl font-bold text-teal-400">{stats.chatBookings}</p>
        </div>
      </div>

      <div className="bg-gradient-to-r from-teal-500/20 to-cyan-500/20 border border-teal-500/30 rounded-xl p-4">
        <div className="flex items-center gap-3">
          <MessageSquare className="w-5 h-5 text-teal-400" />
          <div>
            <p className="text-white font-medium">AI Chat Integration Active</p>
            <p className="text-gray-300 text-sm">Bookings made through your AI chat appear here automatically</p>
          </div>
        </div>
      </div>

      <div className="bg-white/5 backdrop-blur-xl rounded-xl border border-white/10 p-5">
        <div className="flex flex-col lg:flex-row gap-3 mb-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              type="text"
              placeholder="Search bookings..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 rounded-lg bg-white/5 border border-white/10 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-red-500/50"
            />
          </div>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-4 py-2 rounded-lg bg-white/5 border border-white/10 text-white focus:outline-none focus:ring-2 focus:ring-red-500/50"
          >
            <option value="all">All Status</option>
            <option value="pending">Pending</option>
            <option value="confirmed">Confirmed</option>
            <option value="in_progress">In Progress</option>
            <option value="completed">Completed</option>
            <option value="cancelled">Cancelled</option>
          </select>
          <select
            value={sourceFilter}
            onChange={(e) => setSourceFilter(e.target.value)}
            className="px-4 py-2 rounded-lg bg-white/5 border border-white/10 text-white focus:outline-none focus:ring-2 focus:ring-red-500/50"
          >
            <option value="all">All Sources</option>
            <option value="chat">AI Chat</option>
            <option value="web">Website</option>
            <option value="phone">Phone</option>
            <option value="partner">Partner</option>
          </select>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-white/10">
                <th className="text-left text-gray-400 text-sm font-medium pb-3">Booking</th>
                <th className="text-left text-gray-400 text-sm font-medium pb-3">Customer</th>
                <th className="text-left text-gray-400 text-sm font-medium pb-3">Route</th>
                <th className="text-left text-gray-400 text-sm font-medium pb-3">Pickup Time</th>
                <th className="text-left text-gray-400 text-sm font-medium pb-3">Amount</th>
                <th className="text-left text-gray-400 text-sm font-medium pb-3">Status</th>
                <th className="text-right text-gray-400 text-sm font-medium pb-3">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredBookings.map((booking) => (
                <tr key={booking.id} className="border-b border-white/5 hover:bg-white/5">
                  <td className="py-4">
                    <div>
                      <div className="flex items-center gap-2">
                        <p className="text-white font-medium">{booking.reference}</p>
                        <span className="inline-flex items-center gap-1 text-xs text-gray-400">
                          {sourceIcons[booking.source]}
                          {booking.source}
                        </span>
                      </div>
                      <p className="text-gray-400 text-xs">
                        {new Date(booking.created_at).toLocaleDateString()}
                      </p>
                    </div>
                  </td>
                  <td className="py-4">
                    <div>
                      <p className="text-white">{booking.customer_name}</p>
                      <p className="text-gray-400 text-sm">{booking.customer_email}</p>
                    </div>
                  </td>
                  <td className="py-4">
                    <div className="space-y-1">
                      <div className="flex items-start gap-1.5">
                        <MapPin className="w-3 h-3 text-green-400 mt-0.5 flex-shrink-0" />
                        <p className="text-gray-300 text-sm line-clamp-1">{booking.pickup_location}</p>
                      </div>
                      <div className="flex items-start gap-1.5">
                        <MapPin className="w-3 h-3 text-red-400 mt-0.5 flex-shrink-0" />
                        <p className="text-gray-300 text-sm line-clamp-1">{booking.dropoff_location}</p>
                      </div>
                    </div>
                  </td>
                  <td className="py-4">
                    <div className="flex items-center gap-2">
                      <Clock className="w-4 h-4 text-gray-400" />
                      <div>
                        <p className="text-white text-sm">
                          {new Date(booking.pickup_datetime).toLocaleDateString('en', {
                            month: 'short',
                            day: 'numeric',
                          })}
                        </p>
                        <p className="text-gray-400 text-xs">
                          {new Date(booking.pickup_datetime).toLocaleTimeString('en', {
                            hour: '2-digit',
                            minute: '2-digit',
                          })}
                        </p>
                      </div>
                    </div>
                  </td>
                  <td className="py-4">
                    <p className="text-white font-medium">${booking.total_price}</p>
                    <p className={`text-xs ${booking.payment_status === 'paid' ? 'text-green-400' : 'text-amber-400'}`}>
                      {booking.payment_status}
                    </p>
                  </td>
                  <td className="py-4">
                    <span className={`px-3 py-1 rounded-lg text-xs font-medium capitalize ${statusColors[booking.status]}`}>
                      {booking.status.replace('_', ' ')}
                    </span>
                  </td>
                  <td className="py-4">
                    <div className="flex items-center justify-end">
                      <button
                        onClick={() => setSelectedBooking(booking)}
                        className="p-2 rounded-lg bg-white/5 text-blue-400 hover:bg-white/10 transition-all"
                      >
                        <Eye className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {selectedBooking && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-[100]">
          <div className="bg-slate-800 rounded-2xl border border-white/10 p-6 max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h2 className="text-xl font-bold text-white">Booking Details</h2>
                <p className="text-gray-400 text-sm">Reference: {selectedBooking.reference}</p>
              </div>
              <button
                onClick={() => setSelectedBooking(null)}
                className="p-2 rounded-lg bg-white/5 text-gray-400 hover:bg-white/10"
              >
                ✕
              </button>
            </div>

            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-gray-400 text-sm mb-1">Customer Name</p>
                  <p className="text-white">{selectedBooking.customer_name}</p>
                </div>
                <div>
                  <p className="text-gray-400 text-sm mb-1">Email</p>
                  <p className="text-white">{selectedBooking.customer_email}</p>
                </div>
                <div>
                  <p className="text-gray-400 text-sm mb-1">Phone</p>
                  <p className="text-white">{selectedBooking.customer_phone}</p>
                </div>
                <div>
                  <p className="text-gray-400 text-sm mb-1">Passengers</p>
                  <p className="text-white">{selectedBooking.passengers}</p>
                </div>
              </div>

              <div>
                <p className="text-gray-400 text-sm mb-2">Route</p>
                <div className="space-y-2">
                  <div className="flex items-start gap-3 p-3 rounded-lg bg-green-500/10 border border-green-500/20">
                    <MapPin className="w-4 h-4 text-green-400 mt-0.5" />
                    <div>
                      <p className="text-green-400 text-xs font-medium mb-1">Pickup</p>
                      <p className="text-white">{selectedBooking.pickup_location}</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3 p-3 rounded-lg bg-red-500/10 border border-red-500/20">
                    <MapPin className="w-4 h-4 text-red-400 mt-0.5" />
                    <div>
                      <p className="text-red-400 text-xs font-medium mb-1">Dropoff</p>
                      <p className="text-white">{selectedBooking.dropoff_location}</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-gray-400 text-sm mb-1">Pickup Date & Time</p>
                  <p className="text-white">
                    {new Date(selectedBooking.pickup_datetime).toLocaleString()}
                  </p>
                </div>
                <div>
                  <p className="text-gray-400 text-sm mb-1">Total Price</p>
                  <p className="text-white text-2xl font-bold">${selectedBooking.total_price}</p>
                </div>
              </div>

              {selectedBooking.special_requests && (
                <div>
                  <p className="text-gray-400 text-sm mb-2">Special Requests</p>
                  <p className="text-white p-3 rounded-lg bg-white/5">
                    {selectedBooking.special_requests}
                  </p>
                </div>
              )}

              <div>
                <p className="text-gray-400 text-sm mb-2">Update Status</p>
                <div className="grid grid-cols-2 gap-2">
                  {(['pending', 'confirmed', 'in_progress', 'completed'] as const).map(status => (
                    <button
                      key={status}
                      onClick={() => updateBookingStatus(selectedBooking.id, status)}
                      className={`px-4 py-2 rounded-lg text-sm font-medium capitalize transition-all ${
                        selectedBooking.status === status
                          ? statusColors[status]
                          : 'bg-white/5 text-gray-400 hover:bg-white/10'
                      }`}
                    >
                      {status.replace('_', ' ')}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
