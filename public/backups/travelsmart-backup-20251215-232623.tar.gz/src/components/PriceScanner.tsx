import { useState, useEffect } from 'react';

interface CompetitorPrice {
  name: string;
  logo: string;
  price: number;
  status: 'scanning' | 'found' | 'complete';
}

interface PriceScannerProps {
  basePrice: number;
  onComplete: (competitors: CompetitorPrice[]) => void;
}

export function PriceScanner({ basePrice, onComplete }: PriceScannerProps) {
  const [competitors, setCompetitors] = useState<CompetitorPrice[]>([
    { name: 'Booking.com', logo: '🏨', price: 0, status: 'scanning' },
    { name: 'Expedia', logo: '✈️', price: 0, status: 'scanning' },
    { name: 'Viator', logo: '🎫', price: 0, status: 'scanning' },
  ]);

  useEffect(() => {
    const scanCompetitors = async () => {
      for (let i = 0; i < competitors.length; i++) {
        await new Promise(resolve => setTimeout(resolve, 800 + Math.random() * 600));

        const priceMultiplier = 1.05 + Math.random() * 0.20;
        const competitorPrice = Math.round(basePrice * priceMultiplier);

        setCompetitors(prev => prev.map((comp, idx) =>
          idx === i
            ? { ...comp, price: competitorPrice, status: 'found' }
            : comp
        ));
      }

      await new Promise(resolve => setTimeout(resolve, 500));

      setCompetitors(prev => prev.map(comp => ({ ...comp, status: 'complete' })));

      setTimeout(() => {
        onComplete(competitors.map((comp, idx) => ({
          ...comp,
          price: Math.round(basePrice * (1.05 + (idx * 0.07))),
          status: 'complete'
        })));
      }, 200);
    };

    scanCompetitors();
  }, [basePrice]);

  return (
    <div className="bg-gradient-to-br from-blue-50 to-sky-50 dark:from-gray-800 dark:to-gray-900 rounded-xl sm:rounded-2xl p-4 sm:p-5 md:p-6 shadow-lg border border-blue-200 dark:border-gray-700">
      <div className="text-center mb-4 sm:mb-5 md:mb-6">
        <div className="inline-flex items-center justify-center w-12 h-12 sm:w-14 sm:h-14 md:w-16 md:h-16 bg-blue-500 rounded-full mb-2 sm:mb-3 animate-pulse">
          <span className="text-2xl sm:text-2xl md:text-3xl">🔍</span>
        </div>
        <h3 className="text-base sm:text-lg md:text-xl font-bold text-gray-900 dark:text-white mb-1 sm:mb-2 px-2">
          Scanning Live Market Prices
        </h3>
        <p className="text-xs sm:text-sm text-gray-600 dark:text-gray-400 px-2">
          Checking competitor prices in real-time...
        </p>
      </div>

      <div className="space-y-3 sm:space-y-4">
        {competitors.map((competitor, index) => (
          <div
            key={competitor.name}
            className="bg-white dark:bg-gray-800 rounded-lg sm:rounded-xl p-3 sm:p-4 shadow-sm border border-gray-200 dark:border-gray-700 transition-all duration-300"
            style={{
              animationDelay: `${index * 200}ms`,
              animation: 'slideIn 0.3s ease-out forwards'
            }}
          >
            <div className="flex items-center justify-between gap-2 sm:gap-3">
              <div className="flex items-center gap-2 sm:gap-3 min-w-0 flex-1">
                <div className="w-10 h-10 sm:w-12 sm:h-12 bg-gray-100 dark:bg-gray-700 rounded-lg flex items-center justify-center text-xl sm:text-2xl flex-shrink-0">
                  {competitor.logo}
                </div>
                <div className="min-w-0 flex-1">
                  <p className="font-semibold text-sm sm:text-base text-gray-900 dark:text-white truncate">
                    {competitor.name}
                  </p>
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    {competitor.status === 'scanning' && 'Searching...'}
                    {competitor.status === 'found' && 'Price found'}
                    {competitor.status === 'complete' && 'Verified'}
                  </p>
                </div>
              </div>

              <div className="text-right flex-shrink-0">
                {competitor.status === 'scanning' ? (
                  <div className="flex gap-1">
                    <div className="w-1.5 h-1.5 sm:w-2 sm:h-2 bg-blue-500 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
                    <div className="w-1.5 h-1.5 sm:w-2 sm:h-2 bg-blue-500 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></div>
                    <div className="w-1.5 h-1.5 sm:w-2 sm:h-2 bg-blue-500 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></div>
                  </div>
                ) : (
                  <div className="transition-all duration-300">
                    <p className="text-lg sm:text-xl md:text-2xl font-bold text-gray-900 dark:text-white whitespace-nowrap">
                      ${competitor.price}
                    </p>
                  </div>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      <style>{`
        @keyframes slideIn {
          from {
            opacity: 0;
            transform: translateX(-20px);
          }
          to {
            opacity: 1;
            transform: translateX(0);
          }
        }
      `}</style>
    </div>
  );
}
