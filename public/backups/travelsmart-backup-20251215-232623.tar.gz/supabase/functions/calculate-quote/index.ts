import { createClient } from 'npm:@supabase/supabase-js@2.57.4';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Client-Info, Apikey',
};

interface QuoteRequest {
  from_address: string;
  to_address: string;
  pickup_datetime: string;
  vehicle_type: string;
  passenger_count?: number;
  luggage_count?: number;
  customer_id?: string;
  corporate_account_id?: string;
}

interface Zone {
  id: string;
  zone_name: string;
  zone_code: string;
  center_point: { lat: number; lng: number };
}

interface PricingRule {
  id: string;
  rule_name: string;
  rule_type: string;
  priority: number;
  vehicle_types: string[];
  from_zone_id?: string;
  to_zone_id?: string;
  base_price?: number;
  price_per_mile?: number;
  price_per_minute?: number;
  time_multiplier?: number;
  day_of_week?: number[];
  time_range_start?: string;
  time_range_end?: string;
  minimum_charge?: number;
  maximum_charge?: number;
}

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const quoteRequest: QuoteRequest = await req.json();

    // Validate required fields
    if (!quoteRequest.from_address || !quoteRequest.to_address || !quoteRequest.vehicle_type) {
      return new Response(
        JSON.stringify({ error: 'Missing required fields: from_address, to_address, vehicle_type' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    let distance_miles = 15.5;
    let duration_minutes = 25;
    let distance_calculated_via_api = false;

    try {
      const { data: googleMapsIntegration } = await supabase
        .from('api_integrations')
        .select('*')
        .eq('integration_name', 'google_maps')
        .eq('is_active', true)
        .maybeSingle();

      if (googleMapsIntegration && googleMapsIntegration.api_key) {
        const distanceResponse = await fetch(`${supabaseUrl}/functions/v1/calculate-distance`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${supabaseKey}`,
          },
          body: JSON.stringify({
            origin: quoteRequest.from_address,
            destination: quoteRequest.to_address,
            mode: 'driving',
          }),
        });

        if (distanceResponse.ok) {
          const distanceData = await distanceResponse.json();
          if (distanceData.success && distanceData.distance) {
            distance_miles = Math.round(distanceData.distance.value / 1609.34 * 10) / 10;
            duration_minutes = Math.round(distanceData.duration.value / 60);
            distance_calculated_via_api = true;
          }
        }
      }
    } catch (error) {
      console.log('Google Maps API not available, using estimated distance:', error);
    }

    // Detect zones based on addresses (simplified - in production use Google Geocoding)
    const { data: zones } = await supabase
      .from('pricing_zones')
      .select('*')
      .eq('is_active', true);

    let from_zone_id = null;
    let to_zone_id = null;

    // Simple zone matching logic (in production, use geocoding + polygon containment)
    if (zones) {
      for (const zone of zones as Zone[]) {
        if (quoteRequest.from_address.toLowerCase().includes(zone.zone_name.toLowerCase())) {
          from_zone_id = zone.id;
        }
        if (quoteRequest.to_address.toLowerCase().includes(zone.zone_name.toLowerCase())) {
          to_zone_id = zone.id;
        }
      }
    }

    // Fetch applicable pricing rules
    const { data: rules } = await supabase
      .from('pricing_rules')
      .select('*')
      .eq('is_active', true)
      .order('priority', { ascending: true });

    let base_price = 0;
    let distance_price = 0;
    let time_price = 0;
    const multipliers_applied: any[] = [];
    const rules_applied: string[] = [];

    const pickupDate = new Date(quoteRequest.pickup_datetime);
    const dayOfWeek = pickupDate.getDay() === 0 ? 7 : pickupDate.getDay(); // Convert Sunday from 0 to 7
    const pickupTime = pickupDate.toTimeString().slice(0, 5); // HH:MM format

    if (rules) {
      for (const rule of rules as PricingRule[]) {
        // Check if rule applies to this vehicle type
        if (rule.vehicle_types && rule.vehicle_types.length > 0) {
          if (!rule.vehicle_types.includes(quoteRequest.vehicle_type)) {
            continue;
          }
        }

        // Check day of week
        if (rule.day_of_week && rule.day_of_week.length > 0) {
          if (!rule.day_of_week.includes(dayOfWeek)) {
            continue;
          }
        }

        // Check time range
        if (rule.time_range_start && rule.time_range_end) {
          if (pickupTime < rule.time_range_start || pickupTime > rule.time_range_end) {
            continue;
          }
        }

        // Apply rule based on type
        switch (rule.rule_type) {
          case 'base_rate':
            if (rule.base_price) {
              base_price += rule.base_price;
              rules_applied.push(rule.id);
            }
            break;

          case 'distance':
            if (rule.price_per_mile) {
              distance_price += distance_miles * rule.price_per_mile;
              rules_applied.push(rule.id);
            }
            break;

          case 'zone_to_zone':
            if (rule.from_zone_id === from_zone_id && rule.to_zone_id === to_zone_id) {
              if (rule.base_price) {
                base_price = rule.base_price;
                rules_applied.push(rule.id);
              }
            }
            break;

          case 'time_multiplier':
            if (rule.time_multiplier && rule.time_multiplier !== 1.0) {
              multipliers_applied.push({
                rule_id: rule.id,
                rule_name: rule.rule_name,
                multiplier: rule.time_multiplier,
              });
              rules_applied.push(rule.id);
            }
            break;
        }
      }
    }

    // Calculate subtotal
    let subtotal = base_price + distance_price + time_price;

    // Apply multipliers
    for (const mult of multipliers_applied) {
      subtotal *= mult.multiplier;
    }

    // Check for corporate rate cards
    if (quoteRequest.corporate_account_id) {
      const { data: rateCards } = await supabase
        .from('corporate_rate_cards')
        .select('*')
        .eq('corporate_account_id', quoteRequest.corporate_account_id)
        .eq('is_active', true)
        .lte('valid_from', new Date().toISOString())
        .or(`valid_until.is.null,valid_until.gte.${new Date().toISOString()}`);

      if (rateCards && rateCards.length > 0) {
        const applicableRate = rateCards.find(
          (rc: any) =>
            rc.vehicle_type === quoteRequest.vehicle_type &&
            (!rc.from_zone_id || rc.from_zone_id === from_zone_id) &&
            (!rc.to_zone_id || rc.to_zone_id === to_zone_id)
        );

        if (applicableRate) {
          if (applicableRate.flat_rate) {
            subtotal = applicableRate.flat_rate;
          } else if (applicableRate.discount_percentage) {
            subtotal *= 1 - applicableRate.discount_percentage / 100;
          }
        }
      }
    }

    // Apply minimum charge from rules
    const minChargeRules = (rules as PricingRule[] || []).filter(
      (r) => r.minimum_charge && (!r.vehicle_types || r.vehicle_types.length === 0 || r.vehicle_types.includes(quoteRequest.vehicle_type))
    );
    const minCharge = Math.max(...minChargeRules.map((r) => r.minimum_charge || 0), 0);
    if (minCharge > 0 && subtotal < minCharge) {
      subtotal = minCharge;
    }

    const total_price = Math.round(subtotal * 100) / 100; // Round to 2 decimals

    // Generate quote number
    const quote_number = `QT-${new Date().toISOString().slice(0, 10).replace(/-/g, '')}-${Math.floor(Math.random() * 10000).toString().padStart(4, '0')}`;

    // Calculate expiry (24 hours from now)
    const expires_at = new Date();
    expires_at.setHours(expires_at.getHours() + 24);

    // Save quote to database
    const { data: quote, error: quoteError } = await supabase
      .from('price_quotes')
      .insert({
        quote_number,
        customer_id: quoteRequest.customer_id || null,
        corporate_account_id: quoteRequest.corporate_account_id || null,
        from_address: quoteRequest.from_address,
        to_address: quoteRequest.to_address,
        from_zone_id,
        to_zone_id,
        distance_miles,
        duration_minutes,
        vehicle_type: quoteRequest.vehicle_type,
        pickup_datetime: quoteRequest.pickup_datetime,
        base_price,
        distance_price,
        time_price,
        multipliers_applied: JSON.stringify(multipliers_applied),
        total_price,
        rules_applied: JSON.stringify(rules_applied),
        expires_at: expires_at.toISOString(),
        status: 'draft',
        created_by: 'system',
      })
      .select()
      .single();

    if (quoteError) {
      throw quoteError;
    }

    return new Response(
      JSON.stringify({
        success: true,
        quote,
      }),
      {
        status: 200,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  } catch (error) {
    console.error('Error calculating quote:', error);
    return new Response(
      JSON.stringify({ error: error.message || 'Internal server error' }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});