import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface ChatRequest {
  message: string;
  conversationHistory?: Array<{ role: string; content: string }>;
}

const FALLBACK_RESPONSES: Record<string, string> = {
  weather: "The Dominican Republic enjoys tropical weather year-round! Expect temperatures between 77-86F (25-30C). The dry season (December-April) is perfect for beach visits, while the rainy season (May-November) brings brief afternoon showers. Pack light clothes, sunscreen, and a light rain jacket!",
  beach: "The DR has some of the Caribbean's most beautiful beaches! Punta Cana offers powdery white sand and turquoise waters. Bavaro Beach is perfect for families, while Cap Cana has more secluded luxury spots. Puerto Plata's northern coast has golden sand beaches with great surfing.",
  food: "Dominican cuisine is delicious! Try 'La Bandera' - the national dish of rice, beans, and meat. Don't miss mofongo (mashed plantains), tostones (fried plantains), and fresh seafood. Wash it down with Presidente beer or mamajuana, a local herbal drink!",
  activities: "There's so much to do! Visit Saona Island for pristine beaches, explore Santo Domingo's historic Colonial Zone (UNESCO site), go zip-lining in Puerto Plata, swim in natural cenotes, or take a catamaran cruise. Golf lovers will find world-class courses!",
  safety: "The tourist areas are generally very safe! Stick to reputable tour operators and transportation services. Our private transfers ensure you travel safely from the airport to your resort. Keep valuables secure and use common sense, just like traveling anywhere.",
  currency: "The Dominican Peso (DOP) is the local currency, but US dollars are widely accepted in tourist areas. Credit cards work at most hotels and restaurants. ATMs are available, but let your bank know you're traveling. Tip in local currency when possible!",
  language: "Spanish is the official language, but English is widely spoken in tourist areas, especially at resorts and with tour operators. Our drivers speak English! Learning a few Spanish phrases like 'Hola' (hello) and 'Gracias' (thank you) is always appreciated.",
  default: "The Dominican Republic is a beautiful Caribbean destination with stunning beaches, rich culture, warm people, and delicious food! It's perfect for relaxation, adventure, or a mix of both. When you're ready to book your airport transfer, just let me know!"
};

function getSmartResponse(message: string): string {
  const lower = message.toLowerCase();
  
  if (lower.includes('weather') || lower.includes('climate') || lower.includes('temperature') || lower.includes('rain') || lower.includes('hot') || lower.includes('cold')) {
    return FALLBACK_RESPONSES.weather;
  }
  if (lower.includes('beach') || lower.includes('sand') || lower.includes('ocean') || lower.includes('swim') || lower.includes('coast')) {
    return FALLBACK_RESPONSES.beach;
  }
  if (lower.includes('food') || lower.includes('eat') || lower.includes('restaurant') || lower.includes('cuisine') || lower.includes('drink') || lower.includes('beer')) {
    return FALLBACK_RESPONSES.food;
  }
  if (lower.includes('do') || lower.includes('activit') || lower.includes('tour') || lower.includes('visit') || lower.includes('see') || lower.includes('attraction')) {
    return FALLBACK_RESPONSES.activities;
  }
  if (lower.includes('safe') || lower.includes('danger') || lower.includes('security') || lower.includes('crime')) {
    return FALLBACK_RESPONSES.safety;
  }
  if (lower.includes('money') || lower.includes('currency') || lower.includes('dollar') || lower.includes('peso') || lower.includes('pay') || lower.includes('tip') || lower.includes('atm')) {
    return FALLBACK_RESPONSES.currency;
  }
  if (lower.includes('language') || lower.includes('spanish') || lower.includes('english') || lower.includes('speak')) {
    return FALLBACK_RESPONSES.language;
  }
  
  return FALLBACK_RESPONSES.default;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const { message, conversationHistory = [] }: ChatRequest = await req.json();

    const openaiApiKey = Deno.env.get("OPENAI_API_KEY");
    
    if (!openaiApiKey) {
      console.log("No OpenAI API key configured, using smart fallback responses");
      return new Response(
        JSON.stringify({
          response: getSmartResponse(message),
          success: true,
          source: "fallback"
        }),
        {
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json",
          },
        }
      );
    }

    const systemPrompt = `You are a friendly and knowledgeable customer service assistant for Dominican Transfers, a premium airport transfer service in the Dominican Republic.

Your role is to answer general questions about:
- The Dominican Republic (attractions, culture, weather, best times to visit, beaches, activities, etc.)
- General travel advice for the Dominican Republic
- Local tips and recommendations
- General service questions

Important guidelines:
- Be warm, friendly, and professional
- Keep responses concise and helpful (2-4 sentences max)
- Always be positive about the Dominican Republic
- If asked about booking, pricing, transfers, or any booking-related topics, politely redirect: "I'd be happy to help you book a transfer! Just say 'I'm ready to book' and I'll get you started."
- If asked about specific transfer details (airports, hotels, pricing), say: "For transfer quotes and bookings, please let me know when you're ready to book!"
- Never discuss competitors or pricing comparisons
- Focus on being helpful and creating excitement about their Dominican Republic trip

Remember: You're here to answer general questions and build excitement. The booking system handles all transfer-related queries.`;

    const messages = [
      { role: "system", content: systemPrompt },
      ...conversationHistory.slice(-6),
      { role: "user", content: message }
    ];

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 15000);

    try {
      const response = await fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${openaiApiKey}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model: "gpt-4o-mini",
          messages: messages,
          temperature: 0.7,
          max_tokens: 300,
        }),
        signal: controller.signal,
      });

      clearTimeout(timeoutId);

      if (!response.ok) {
        const errorText = await response.text();
        console.error("OpenAI API error:", response.status, errorText);
        
        return new Response(
          JSON.stringify({
            response: getSmartResponse(message),
            success: true,
            source: "fallback"
          }),
          {
            headers: {
              ...corsHeaders,
              "Content-Type": "application/json",
            },
          }
        );
      }

      const data = await response.json();
      const aiResponse = data.choices[0]?.message?.content || getSmartResponse(message);

      return new Response(
        JSON.stringify({
          response: aiResponse,
          success: true,
          source: "openai"
        }),
        {
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json",
          },
        }
      );
    } catch (fetchError) {
      clearTimeout(timeoutId);
      console.error("Fetch error:", fetchError);
      
      return new Response(
        JSON.stringify({
          response: getSmartResponse(message),
          success: true,
          source: "fallback"
        }),
        {
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json",
          },
        }
      );
    }

  } catch (error) {
    console.error("Error in gpt-chat function:", error);

    return new Response(
      JSON.stringify({
        response: "The Dominican Republic is a beautiful Caribbean destination! I'm here to help answer your questions about attractions, weather, culture, or local tips. When you're ready to book your transfer, just let me know!",
        success: true,
        source: "error-fallback"
      }),
      {
        status: 200,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  }
});