import { Sparkles } from 'lucide-react';

interface SuggestionChipsProps {
  suggestions: string[];
  onSelect: (suggestion: string) => void;
}

export function SuggestionChips({ suggestions, onSelect }: SuggestionChipsProps) {
  if (suggestions.length === 0) return null;

  return (
    <div className="mb-6 animate-slideIn">
      <div className="flex items-center gap-2 mb-3 px-1">
        <Sparkles className="w-4 h-4 text-yellow-500 dark:text-yellow-400" />
        <span className="text-slate-500 dark:text-gray-400 text-sm font-medium">Suggestions</span>
      </div>

      <div className="flex flex-wrap gap-2.5">
        {suggestions.map((suggestion, index) => (
          <button
            key={index}
            onClick={() => onSelect(suggestion)}
            className="group relative px-6 py-3.5 bg-white/10 dark:bg-white/5 backdrop-blur-2xl border border-white/20 dark:border-white/10 rounded-2xl text-slate-700 dark:text-white text-[15px] font-medium shadow-[0_8px_32px_0_rgba(0,0,0,0.12)] hover:shadow-[0_12px_48px_0_rgba(0,0,0,0.18)] transition-all duration-500 hover:scale-[1.02] active:scale-[0.98] hover:bg-white/20 dark:hover:bg-white/10 overflow-hidden"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-teal-400/20 via-cyan-400/20 to-blue-400/20 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
            <span className="relative z-10">{suggestion}</span>
          </button>
        ))}
      </div>
    </div>
  );
}
