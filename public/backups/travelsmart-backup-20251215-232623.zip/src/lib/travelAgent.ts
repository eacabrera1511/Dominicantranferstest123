import { supabase, Hotel, Service } from './supabase';

export interface BookingAction {
  action: 'START_BOOKING';
  airport: string;
  hotel: string;
  region: string;
  vehicle: string;
  passengers: number;
  suitcases: number;
  tripType: string;
  price: number;
  currency: string;
  paymentProvider: string;
  paymentMethods: string[];
}

export interface PriceScanRequest {
  type: 'PRICE_SCAN';
  airport: string;
  hotel: string;
  region: string;
  basePrice: number;
  route: string;
}

export interface AgentResponse {
  message: string;
  hotels?: Hotel[];
  services?: Service[];
  suggestions?: string[];
  bookingAction?: BookingAction;
  priceScanRequest?: PriceScanRequest;
  vehicleImage?: {
    url: string;
    alt: string;
    caption: string;
  };
}

type BookingStep = 'IDLE' | 'AWAITING_AIRPORT' | 'AWAITING_HOTEL' | 'AWAITING_PASSENGERS' | 'AWAITING_LUGGAGE' | 'AWAITING_TRIP_TYPE' | 'AWAITING_CONFIRMATION';

interface BookingContext {
  step: BookingStep;
  airport?: string;
  hotel?: string;
  region?: string;
  vehicle?: string;
  passengers?: number;
  suitcases?: number;
  tripType?: 'One-way' | 'Round trip';
  price?: number;
  priceSource?: string;
  originalPrice?: number;
  matchedPrice?: number;
}

const AIRPORTS: Record<string, string> = {
  'PUJ': 'Punta Cana International Airport (PUJ)',
  'SDQ': 'Santo Domingo Las Americas (SDQ)',
  'LRM': 'La Romana International Airport (LRM)',
  'POP': 'Puerto Plata Gregorio Luperon (POP)'
};

const VEHICLES: Record<string, { minPax: number; maxPax: number; minLuggage: number; maxLuggage: number }> = {
  'Sedan': { minPax: 1, maxPax: 3, minLuggage: 2, maxLuggage: 3 },
  'SUV': { minPax: 1, maxPax: 4, minLuggage: 3, maxLuggage: 4 },
  'Minivan': { minPax: 5, maxPax: 7, minLuggage: 6, maxLuggage: 8 },
  'Minibus': { minPax: 8, maxPax: 14, minLuggage: 10, maxLuggage: 14 }
};

const PRICING: Record<string, Record<string, Record<string, { oneWay: number; roundTrip: number }>>> = {
  'PUJ': {
    'Bavaro / Punta Cana': {
      'Sedan': { oneWay: 30, roundTrip: 60 },
      'SUV': { oneWay: 45, roundTrip: 90 },
      'Minivan': { oneWay: 70, roundTrip: 140 },
      'Minibus': { oneWay: 120, roundTrip: 240 }
    },
    'Cap Cana / Uvero Alto': {
      'Sedan': { oneWay: 40, roundTrip: 80 },
      'SUV': { oneWay: 60, roundTrip: 120 },
      'Minivan': { oneWay: 90, roundTrip: 180 },
      'Minibus': { oneWay: 150, roundTrip: 300 }
    },
    'Santo Domingo City': {
      'Sedan': { oneWay: 135, roundTrip: 270 },
      'SUV': { oneWay: 155, roundTrip: 310 },
      'Minivan': { oneWay: 185, roundTrip: 370 },
      'Minibus': { oneWay: 240, roundTrip: 480 }
    },
    'La Romana / Bayahibe': {
      'Sedan': { oneWay: 80, roundTrip: 160 },
      'SUV': { oneWay: 100, roundTrip: 200 },
      'Minivan': { oneWay: 130, roundTrip: 260 },
      'Minibus': { oneWay: 190, roundTrip: 380 }
    }
  },
  'SDQ': {
    'Bavaro / Punta Cana': {
      'Sedan': { oneWay: 130, roundTrip: 260 },
      'SUV': { oneWay: 145, roundTrip: 290 },
      'Minivan': { oneWay: 170, roundTrip: 340 },
      'Minibus': { oneWay: 220, roundTrip: 440 }
    },
    'Cap Cana / Uvero Alto': {
      'Sedan': { oneWay: 140, roundTrip: 280 },
      'SUV': { oneWay: 160, roundTrip: 320 },
      'Minivan': { oneWay: 190, roundTrip: 380 },
      'Minibus': { oneWay: 250, roundTrip: 500 }
    },
    'Santo Domingo City': {
      'Sedan': { oneWay: 35, roundTrip: 70 },
      'SUV': { oneWay: 55, roundTrip: 110 },
      'Minivan': { oneWay: 85, roundTrip: 170 },
      'Minibus': { oneWay: 140, roundTrip: 280 }
    },
    'La Romana / Bayahibe': {
      'Sedan': { oneWay: 90, roundTrip: 180 },
      'SUV': { oneWay: 110, roundTrip: 220 },
      'Minivan': { oneWay: 140, roundTrip: 280 },
      'Minibus': { oneWay: 200, roundTrip: 400 }
    }
  },
  'LRM': {
    'Bavaro / Punta Cana': {
      'Sedan': { oneWay: 80, roundTrip: 160 },
      'SUV': { oneWay: 100, roundTrip: 200 },
      'Minivan': { oneWay: 130, roundTrip: 260 },
      'Minibus': { oneWay: 190, roundTrip: 380 }
    },
    'Cap Cana / Uvero Alto': {
      'Sedan': { oneWay: 70, roundTrip: 140 },
      'SUV': { oneWay: 90, roundTrip: 180 },
      'Minivan': { oneWay: 120, roundTrip: 240 },
      'Minibus': { oneWay: 180, roundTrip: 360 }
    },
    'Santo Domingo City': {
      'Sedan': { oneWay: 90, roundTrip: 180 },
      'SUV': { oneWay: 110, roundTrip: 220 },
      'Minivan': { oneWay: 140, roundTrip: 280 },
      'Minibus': { oneWay: 200, roundTrip: 400 }
    },
    'La Romana / Bayahibe': {
      'Sedan': { oneWay: 30, roundTrip: 60 },
      'SUV': { oneWay: 45, roundTrip: 90 },
      'Minivan': { oneWay: 70, roundTrip: 140 },
      'Minibus': { oneWay: 120, roundTrip: 240 }
    }
  },
  'POP': {
    'Puerto Plata / Playa Dorada': {
      'Sedan': { oneWay: 30, roundTrip: 60 },
      'SUV': { oneWay: 50, roundTrip: 100 },
      'Minivan': { oneWay: 80, roundTrip: 160 },
      'Minibus': { oneWay: 130, roundTrip: 260 }
    },
    'Santo Domingo City': {
      'Sedan': { oneWay: 180, roundTrip: 360 },
      'SUV': { oneWay: 200, roundTrip: 400 },
      'Minivan': { oneWay: 230, roundTrip: 460 },
      'Minibus': { oneWay: 290, roundTrip: 580 }
    }
  }
};

const HOTEL_TO_REGION: Record<string, string> = {
  'barcelo': 'Bavaro / Punta Cana',
  'barceló': 'Bavaro / Punta Cana',
  'bavaro': 'Bavaro / Punta Cana',
  'hard rock': 'Bavaro / Punta Cana',
  'paradisus': 'Bavaro / Punta Cana',
  'iberostar bavaro': 'Bavaro / Punta Cana',
  'iberostar selection': 'Bavaro / Punta Cana',
  'melia': 'Bavaro / Punta Cana',
  'meliá': 'Bavaro / Punta Cana',
  'riu': 'Bavaro / Punta Cana',
  'dreams punta cana': 'Bavaro / Punta Cana',
  'now larimar': 'Bavaro / Punta Cana',
  'grand palladium': 'Bavaro / Punta Cana',
  'lopesan': 'Bavaro / Punta Cana',
  'royalton bavaro': 'Bavaro / Punta Cana',
  'majestic': 'Bavaro / Punta Cana',
  'ocean blue': 'Bavaro / Punta Cana',
  'occidental': 'Bavaro / Punta Cana',
  'be live': 'Bavaro / Punta Cana',
  'bahia principe grand punta': 'Bavaro / Punta Cana',
  'princess': 'Bavaro / Punta Cana',
  'caribe club': 'Bavaro / Punta Cana',
  'cap cana': 'Cap Cana / Uvero Alto',
  'uvero alto': 'Cap Cana / Uvero Alto',
  'excellence': 'Cap Cana / Uvero Alto',
  'finest': 'Cap Cana / Uvero Alto',
  'zoetry': 'Cap Cana / Uvero Alto',
  'royalton chic': 'Cap Cana / Uvero Alto',
  'royalton splash': 'Cap Cana / Uvero Alto',
  'nickelodeon': 'Cap Cana / Uvero Alto',
  'hyatt zilara': 'Cap Cana / Uvero Alto',
  'hyatt ziva': 'Cap Cana / Uvero Alto',
  'sanctuary cap cana': 'Cap Cana / Uvero Alto',
  'secrets cap cana': 'Cap Cana / Uvero Alto',
  'breathless': 'Cap Cana / Uvero Alto',
  'eden roc': 'Cap Cana / Uvero Alto',
  'santo domingo': 'Santo Domingo',
  'jw marriott': 'Santo Domingo',
  'intercontinental': 'Santo Domingo',
  'sheraton': 'Santo Domingo',
  'renaissance': 'Santo Domingo',
  'jaragua': 'Santo Domingo',
  'crowne plaza': 'Santo Domingo',
  'hodelpa': 'Santo Domingo',
  'la romana': 'La Romana / Bayahibe',
  'bayahibe': 'La Romana / Bayahibe',
  'casa de campo': 'La Romana / Bayahibe',
  'dominicus': 'La Romana / Bayahibe',
  'dreams dominicus': 'La Romana / Bayahibe',
  'hilton la romana': 'La Romana / Bayahibe',
  'viva wyndham': 'La Romana / Bayahibe',
  'iberostar hacienda': 'La Romana / Bayahibe',
  'catalonia': 'La Romana / Bayahibe',
  'puerto plata': 'Puerto Plata / Playa Dorada',
  'playa dorada': 'Puerto Plata / Playa Dorada',
  'viva tangerine': 'Puerto Plata / Playa Dorada',
  'blue bay': 'Puerto Plata / Playa Dorada',
  'senator': 'Puerto Plata / Playa Dorada',
  'cofresi': 'Puerto Plata / Playa Dorada',
  'lifestyle': 'Puerto Plata / Playa Dorada',
  'samana': 'Samana / Las Terrenas',
  'las terrenas': 'Samana / Las Terrenas',
  'bahia principe samana': 'Samana / Las Terrenas',
  'sosua': 'Sosua / Cabarete',
  'cabarete': 'Sosua / Cabarete',
  'juan dolio': 'Juan Dolio / Boca Chica',
  'boca chica': 'Juan Dolio / Boca Chica'
};

interface VehicleType {
  id: string;
  name: string;
  passenger_capacity: number;
  luggage_capacity: number;
}

interface RoutePricing {
  id: string;
  origin: string;
  destination: string;
  vehicle_type_id: string;
  price: number;
  distance_km: number;
}

interface FleetVehicle {
  id: string;
  make: string;
  model: string;
  year: number;
  color: string;
  capacity: number;
  luggage_capacity: number;
  image_url: string;
  amenities: string[];
  vehicle_type_id: string;
}

export class TravelAgent {
  private context: BookingContext = { step: 'IDLE' };
  private hotels: Hotel[] = [];
  private services: Service[] = [];
  private vehicleTypes: VehicleType[] = [];
  private routePricing: RoutePricing[] = [];
  private fleetVehicles: FleetVehicle[] = [];
  private conversationHistory: Array<{ role: string; content: string }> = [];

  async initialize(): Promise<void> {
    try {
      const [hotelsResult, servicesResult, vehicleTypesResult, routePricingResult, vehiclesResult] = await Promise.all([
        supabase.from('hotels').select('*'),
        supabase.from('services').select('*'),
        supabase.from('vehicle_types').select('id, name, passenger_capacity, luggage_capacity').eq('is_active', true),
        supabase.from('route_pricing').select('id, origin, destination, vehicle_type_id, price, distance_km').eq('is_active', true),
        supabase.from('fleet_vehicles').select('id, make, model, year, color, capacity, luggage_capacity, image_url, amenities, vehicle_type_id').eq('status', 'available')
      ]);
      if (hotelsResult.data) this.hotels = hotelsResult.data;
      if (servicesResult.data) this.services = servicesResult.data;
      if (vehicleTypesResult.data) this.vehicleTypes = vehicleTypesResult.data;
      if (routePricingResult.data) this.routePricing = routePricingResult.data;
      if (vehiclesResult.data) this.fleetVehicles = vehiclesResult.data;
    } catch (error) {
      console.error('Failed to initialize TravelAgent:', error);
    }
  }

  async processQuery(userMessage: string): Promise<AgentResponse> {
    return this.processMessage(userMessage);
  }

  async processMessage(userMessage: string): Promise<AgentResponse> {
    const query = userMessage.toLowerCase().trim();

    if (query === 'start over' || query === 'reset' || query === 'cancel') {
      this.context = { step: 'IDLE' };
      this.conversationHistory = [];
      return this.startBookingFlow();
    }

    if (this.isReadyToBook(query)) {
      this.conversationHistory = [];
      return this.startBookingFlow();
    }

    if (this.context.step !== 'IDLE') {
      switch (this.context.step) {
        case 'AWAITING_AIRPORT':
          return this.handleAirportInput(query);
        case 'AWAITING_HOTEL':
          return this.handleHotelInput(query);
        case 'AWAITING_PASSENGERS':
          return this.handlePassengersInput(query);
        case 'AWAITING_LUGGAGE':
          return this.handleLuggageInput(query);
        case 'AWAITING_TRIP_TYPE':
          return this.handleTripTypeInput(query);
        case 'AWAITING_CONFIRMATION':
          return this.handleConfirmationInput(query);
      }
    }

    if (this.isGreeting(query) && this.context.step === 'IDLE') {
      return this.startBookingFlow();
    }

    if (this.isFAQQuery(query) && this.context.step === 'IDLE') {
      return this.handleFAQ(query);
    }

    if (this.context.step === 'IDLE') {
      const isBookingQuery = this.isBookingRelated(query);

      if (!isBookingQuery) {
        return this.handleGeneralQuestion(userMessage);
      }

      return this.handleIdleState(query);
    }

    return this.startBookingFlow();
  }

  private isReadyToBook(query: string): boolean {
    const readyPhrases = [
      'ready to book',
      'ready for booking',
      'want to book',
      'like to book',
      'book now',
      'start booking',
      'make a booking',
      'book a transfer',
      'book transfer'
    ];
    return readyPhrases.some(phrase => query.includes(phrase));
  }

  private isBookingRelated(query: string): boolean {
    const bookingKeywords = [
      'book', 'transfer', 'airport', 'hotel', 'price', 'cost', 'how much',
      'quote', 'rate', 'reservation', 'puj', 'sdq', 'lrm', 'pop',
      'punta cana', 'santo domingo', 'la romana', 'puerto plata',
      'bavaro', 'cap cana', 'ride', 'taxi', 'transport', 'pickup',
      'vehicle', 'car', 'van', 'suv', 'shuttle', 'passenger',
      'luggage', 'suitcase', 'one-way', 'round trip', 'private',
      'shared', 'driver', 'flight'
    ];

    return bookingKeywords.some(keyword => query.includes(keyword));
  }

  private async handleGeneralQuestion(userMessage: string): Promise<AgentResponse> {
    const fallbackResponses: Record<string, string> = {
      weather: "The Dominican Republic enjoys tropical weather year-round! Expect temperatures between 77-86F (25-30C). The dry season (December-April) is perfect for beach visits, while the rainy season (May-November) brings brief afternoon showers. Pack light clothes, sunscreen, and a light rain jacket!",
      beach: "The DR has some of the Caribbean's most beautiful beaches! Punta Cana offers powdery white sand and turquoise waters. Bavaro Beach is perfect for families, while Cap Cana has more secluded luxury spots. Puerto Plata's northern coast has golden sand beaches with great surfing.",
      food: "Dominican cuisine is delicious! Try 'La Bandera' - the national dish of rice, beans, and meat. Don't miss mofongo (mashed plantains), tostones (fried plantains), and fresh seafood. Wash it down with Presidente beer or mamajuana, a local herbal drink!",
      activities: "There's so much to do! Visit Saona Island for pristine beaches, explore Santo Domingo's historic Colonial Zone (UNESCO site), go zip-lining in Puerto Plata, swim in natural cenotes, or take a catamaran cruise. Golf lovers will find world-class courses!",
      safety: "The tourist areas are generally very safe! Stick to reputable tour operators and transportation services. Our private transfers ensure you travel safely from the airport to your resort. Keep valuables secure and use common sense, just like traveling anywhere.",
      currency: "The Dominican Peso (DOP) is the local currency, but US dollars are widely accepted in tourist areas. Credit cards work at most hotels and restaurants. ATMs are available, but let your bank know you're traveling. Tip in local currency when possible!",
      language: "Spanish is the official language, but English is widely spoken in tourist areas, especially at resorts and with tour operators. Our drivers speak English! Learning a few Spanish phrases like 'Hola' (hello) and 'Gracias' (thank you) is always appreciated.",
      default: "The Dominican Republic is a beautiful Caribbean destination with stunning beaches, rich culture, warm people, and delicious food! It's perfect for relaxation, adventure, or a mix of both. When you're ready to book your airport transfer, just let me know!"
    };

    const getLocalFallback = (msg: string): string => {
      const lower = msg.toLowerCase();
      if (lower.includes('weather') || lower.includes('climate') || lower.includes('temperature') || lower.includes('rain') || lower.includes('hot') || lower.includes('cold')) {
        return fallbackResponses.weather;
      }
      if (lower.includes('beach') || lower.includes('sand') || lower.includes('ocean') || lower.includes('swim') || lower.includes('coast')) {
        return fallbackResponses.beach;
      }
      if (lower.includes('food') || lower.includes('eat') || lower.includes('restaurant') || lower.includes('cuisine') || lower.includes('drink') || lower.includes('beer')) {
        return fallbackResponses.food;
      }
      if (lower.includes('do') || lower.includes('activit') || lower.includes('tour') || lower.includes('visit') || lower.includes('see') || lower.includes('attraction')) {
        return fallbackResponses.activities;
      }
      if (lower.includes('safe') || lower.includes('danger') || lower.includes('security') || lower.includes('crime')) {
        return fallbackResponses.safety;
      }
      if (lower.includes('money') || lower.includes('currency') || lower.includes('dollar') || lower.includes('peso') || lower.includes('pay') || lower.includes('tip') || lower.includes('atm')) {
        return fallbackResponses.currency;
      }
      if (lower.includes('language') || lower.includes('spanish') || lower.includes('english') || lower.includes('speak')) {
        return fallbackResponses.language;
      }
      return fallbackResponses.default;
    };

    try {
      const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
      const supabaseKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 8000);

      const response = await fetch(`${supabaseUrl}/functions/v1/gpt-chat`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${supabaseKey}`
        },
        body: JSON.stringify({
          message: userMessage,
          conversationHistory: this.conversationHistory
        }),
        signal: controller.signal
      });

      clearTimeout(timeoutId);

      if (!response.ok) {
        console.error('GPT chat response not ok:', response.status);
        const fallback = getLocalFallback(userMessage);
        return {
          message: fallback,
          suggestions: ['I\'m ready to book', 'Tell me more', 'Another question']
        };
      }

      const data = await response.json();

      if (!data.response) {
        console.error('GPT chat no response in data');
        const fallback = getLocalFallback(userMessage);
        return {
          message: fallback,
          suggestions: ['I\'m ready to book', 'Tell me more', 'Another question']
        };
      }

      this.conversationHistory.push(
        { role: 'user', content: userMessage },
        { role: 'assistant', content: data.response }
      );

      if (this.conversationHistory.length > 12) {
        this.conversationHistory = this.conversationHistory.slice(-8);
      }

      return {
        message: data.response,
        suggestions: ['I\'m ready to book', 'Tell me more', 'Another question']
      };
    } catch (error) {
      console.error('GPT chat error:', error);
      const fallback = getLocalFallback(userMessage);
      return {
        message: fallback,
        suggestions: ['I\'m ready to book', 'Tell me about beaches', 'What\'s the weather like?']
      };
    }
  }

  private isGreeting(query: string): boolean {
    const greetings = ['hello', 'hi', 'hey', 'hola', 'good morning', 'good afternoon', 'good evening', 'howdy', 'greetings'];
    return greetings.some(g => query === g || query.startsWith(g + ' ') || query.startsWith(g + ','));
  }

  private isFAQQuery(query: string): boolean {
    const faqKeywords = [
      'private', 'shared', 'shuttle', 'delay', 'delayed', 'late flight',
      'meet', 'driver', 'find', 'per person', 'per vehicle', 'include',
      'tip', 'tipping', 'gratuity', 'luggage', 'bags', 'suitcase',
      'child seat', 'baby seat', 'car seat', 'cancel', 'refund',
      'payment', 'secure', 'safe', 'stripe', 'support', 'contact',
      'wait', 'waiting', 'track', 'how does', 'what if', 'is it'
    ];
    return faqKeywords.some(k => query.includes(k));
  }

  private startBookingFlow(): AgentResponse {
    this.context = { step: 'AWAITING_AIRPORT' };
    return {
      message: "Welcome to Dominican Transfers! I'm here to help you book a safe, comfortable private transfer.\n\nWe're the #1 rated transportation service in the Dominican Republic, trusted by thousands of travelers.\n\nWhich airport will you be arriving at?",
      suggestions: ['PUJ - Punta Cana', 'SDQ - Santo Domingo', 'LRM - La Romana', 'POP - Puerto Plata']
    };
  }

  private handleIdleState(query: string): AgentResponse {
    const priceQuery = this.detectPriceQuery(query);
    if (priceQuery) {
      return priceQuery;
    }

    const airport = this.extractAirport(query);
    if (airport) {
      this.context.airport = airport;
      this.context.step = 'AWAITING_HOTEL';
      return this.askForHotel();
    }

    if (query.includes('book') || query.includes('transfer') || query.includes('price') || query.includes('taxi') || query.includes('ride')) {
      return this.startBookingFlow();
    }

    return this.startBookingFlow();
  }

  private detectPriceQuery(query: string): AgentResponse | null {
    const lowerQuery = query.toLowerCase();

    const priceKeywords = ['what\'s the price', 'how much', 'price from', 'cost from', 'transfer from', 'quote from', 'price for'];
    const isPriceQuery = priceKeywords.some(k => lowerQuery.includes(k));

    if (!isPriceQuery) return null;

    const airport = this.extractAirport(query);
    const region = this.detectRegionFromQuery(query);
    const hotelName = this.extractHotelName(query);

    if (airport && region) {
      const routePrices = this.routePricing.filter(
        route => route.origin === airport && route.destination === region
      );

      if (routePrices.length > 0) {
        const vehicle = this.vehicleTypes.find(v => v.id === routePrices[0].vehicle_type_id);
        const basePrice = vehicle ? Number(routePrices[0].price) : 0;

        const airportName = AIRPORTS[airport]?.split(' (')[0] || airport;
        const destination = hotelName.length > 2 ? hotelName : region;

        return {
          message: `Let me scan live market prices for transfers from ${airportName} to ${destination}...`,
          priceScanRequest: {
            type: 'PRICE_SCAN',
            airport,
            hotel: destination,
            region,
            basePrice,
            route: `${airportName} to ${destination}`
          },
          suggestions: []
        };
      }
    }

    return null;
  }

  private handleAirportInput(query: string): AgentResponse {
    const airport = this.extractAirport(query);

    if (airport) {
      this.context.airport = airport;
      this.context.step = 'AWAITING_HOTEL';
      return this.askForHotel();
    }

    return {
      message: "No problem! Just let me know which airport you'll be arriving at and I'll take care of the rest.",
      suggestions: ['PUJ - Punta Cana', 'SDQ - Santo Domingo', 'LRM - La Romana', 'POP - Puerto Plata']
    };
  }

  private askForHotel(): AgentResponse {
    const airportName = AIRPORTS[this.context.airport!]?.split(' (')[0] || this.context.airport;
    return {
      message: `Perfect! ${airportName} is a great choice.\n\nWhere would you like us to take you? Just tell me your hotel, resort, or destination.`,
      suggestions: ['Barcelo Bavaro Palace', 'Hard Rock Hotel', 'Dreams Punta Cana', 'Enter hotel name']
    };
  }

  private handleHotelInput(query: string): AgentResponse {
    const region = this.detectRegionFromQuery(query);
    const hotelName = this.extractHotelName(query);

    if (region) {
      this.context.hotel = hotelName;
      this.context.region = region;
      return this.triggerPriceScanner();
    }

    if (hotelName && hotelName.length > 2) {
      this.context.hotel = hotelName;
      return {
        message: `Great choice! To give you accurate pricing for ${hotelName}, which area is it located in?`,
        suggestions: ['Bavaro / Punta Cana', 'Cap Cana / Uvero Alto', 'Santo Domingo', 'La Romana / Bayahibe', 'Puerto Plata']
      };
    }

    const selectedRegion = this.detectRegionDirect(query);
    if (selectedRegion) {
      this.context.region = selectedRegion;
      this.context.hotel = `Hotel in ${selectedRegion}`;
      return this.triggerPriceScanner();
    }

    return {
      message: "I'd love to help! Where will you be staying?\n\nYou can tell me your hotel name, resort, or just the general area.",
      suggestions: ['Bavaro / Punta Cana', 'Cap Cana area', 'Santo Domingo', 'La Romana']
    };
  }

  private triggerPriceScanner(): AgentResponse {
    const airport = this.context.airport!;
    const region = this.context.region!;
    const hotelName = this.context.hotel!;

    const routePrices = this.routePricing.filter(
      route => route.origin === airport && route.destination === region
    );

    if (routePrices.length === 0) {
      const airportName = AIRPORTS[airport]?.split(' (')[0] || airport;
      return {
        message: `I apologize, but we don't currently offer direct transfers from ${airportName} to ${region}.\n\nWould you like to try a different route, or speak with our team for a custom solution?`,
        suggestions: ['Start over', 'Contact support']
      };
    }

    const vehicle = this.vehicleTypes.find(v => v.id === routePrices[0].vehicle_type_id);
    const basePrice = vehicle ? Number(routePrices[0].price) : 0;

    const airportName = AIRPORTS[airport]?.split(' (')[0] || airport;

    return {
      message: `Perfect! Let me check the best rates for your transfer from ${airportName} to ${hotelName}...`,
      priceScanRequest: {
        type: 'PRICE_SCAN',
        airport,
        hotel: hotelName,
        region,
        basePrice,
        route: `${airportName} to ${hotelName}`
      },
      suggestions: []
    };
  }

  private showPricesAndAskPassengers(): AgentResponse {
    const airportCode = this.context.airport!;
    const airportName = AIRPORTS[airportCode]?.split(' (')[0] || airportCode;

    const routePrices = this.routePricing.filter(
      route => route.origin === airportCode && route.destination === this.context.region
    );

    if (routePrices.length === 0) {
      return {
        message: `I apologize, but we don't currently offer direct transfers from ${airportName} to ${this.context.region}.\n\nWould you like to try a different route, or speak with our team for a custom solution?`,
        suggestions: ['Start over', 'Contact support']
      };
    }

    let message = `Excellent! Here are our private transfer rates from ${airportName} to ${this.context.hotel}:\n\n`;

    for (const route of routePrices) {
      const vehicle = this.vehicleTypes.find(v => v.id === route.vehicle_type_id);
      if (vehicle) {
        const oneWay = Number(route.price);
        const roundTrip = oneWay * 2;
        message += `- ${vehicle.name}: $${oneWay} one-way | $${roundTrip} round trip (up to ${vehicle.passenger_capacity} passengers)\n`;
      }
    }

    message += `\nAll prices are per vehicle (not per person) and include meet & greet, flight tracking, and 24/7 support.\n\nHow many travelers will be in your group?`;

    return {
      message,
      suggestions: ['1 passenger', '2 passengers', '4 passengers', '6 passengers']
    };
  }

  private handlePassengersInput(query: string): AgentResponse {
    const passengers = this.extractNumber(query);

    if (passengers && passengers > 0 && passengers <= 14) {
      this.context.passengers = passengers;
      this.context.step = 'AWAITING_LUGGAGE';
      return {
        message: `Perfect, ${passengers} traveler${passengers > 1 ? 's' : ''}!\n\nAnd how many suitcases or bags will you be bringing? Our drivers will handle all your luggage for you.`,
        suggestions: ['1 suitcase', '2 suitcases', '4 suitcases', '6 suitcases']
      };
    }

    if (query.includes('solo') || query.includes('alone') || query.includes('just me')) {
      this.context.passengers = 1;
      this.context.step = 'AWAITING_LUGGAGE';
      return {
        message: "Traveling solo - we've got you covered!\n\nHow many bags will you be bringing?",
        suggestions: ['1 suitcase', '2 suitcases', '3 suitcases']
      };
    }

    if (query.includes('couple') || query.includes('two of us')) {
      this.context.passengers = 2;
      this.context.step = 'AWAITING_LUGGAGE';
      return {
        message: "Wonderful, traveling as a couple!\n\nHow many suitcases will you have between you?",
        suggestions: ['2 suitcases', '3 suitcases', '4 suitcases']
      };
    }

    return {
      message: "No problem! How many travelers will be in your party?",
      suggestions: ['1 passenger', '2 passengers', '4 passengers', '6 passengers']
    };
  }

  private handleLuggageInput(query: string): AgentResponse {
    const suitcases = this.extractNumber(query);

    if (suitcases !== null && suitcases >= 0 && suitcases <= 14) {
      this.context.suitcases = suitcases;
      return this.recommendVehicleAndAskTripType();
    }

    return {
      message: "How many suitcases or bags will you be bringing? Don't worry - our drivers handle all luggage for you!",
      suggestions: ['1 suitcase', '2 suitcases', '4 suitcases', '6 suitcases']
    };
  }

  private recommendVehicleAndAskTripType(): AgentResponse {
    const passengers = this.context.passengers!;
    const suitcases = this.context.suitcases!;

    const routePrices = this.routePricing.filter(
      route => route.origin === this.context.airport && route.destination === this.context.region
    );

    let recommendedVehicle: VehicleType | null = null;
    let sampleFleetVehicle: FleetVehicle | null = null;

    for (const route of routePrices) {
      const vehicle = this.vehicleTypes.find(v => v.id === route.vehicle_type_id);
      if (vehicle && passengers <= vehicle.passenger_capacity && suitcases <= vehicle.luggage_capacity) {
        recommendedVehicle = vehicle;
        sampleFleetVehicle = this.fleetVehicles.find(fv => fv.vehicle_type_id === vehicle.id) || null;
        break;
      }
    }

    if (!recommendedVehicle) {
      return {
        message: `For ${passengers} passengers with ${suitcases} suitcases, we'll arrange multiple vehicles for your comfort. Our team would love to help you with a custom quote!`,
        suggestions: ['Contact support', 'Adjust group size', 'Start over']
      };
    }

    this.context.vehicle = recommendedVehicle.name;
    this.context.step = 'AWAITING_TRIP_TYPE';

    let message = `Perfect! I recommend a comfortable ${recommendedVehicle.name} for your group - plenty of space for everyone and all your luggage!\n\n`;

    if (sampleFleetVehicle) {
      message += `Here's an example from our fleet: ${sampleFleetVehicle.year} ${sampleFleetVehicle.make} ${sampleFleetVehicle.model}\n\n`;
      if (sampleFleetVehicle.amenities && sampleFleetVehicle.amenities.length > 0) {
        message += `Amenities: ${sampleFleetVehicle.amenities.join(', ')}\n\n`;
      }
    }

    message += `Will you need a one-way transfer or a round trip (airport pickup AND return)?`;

    return {
      message,
      suggestions: ['One-way', 'Round trip']
    };
  }

  private handleTripTypeInput(query: string): AgentResponse {
    if (query.includes('round') || query.includes('both') || query.includes('return')) {
      this.context.tripType = 'Round trip';
    } else if (query.includes('one') || query.includes('single')) {
      this.context.tripType = 'One-way';
    } else {
      return {
        message: "One last question! Would you like:\n\n• One-way: Just the airport pickup\n• Round trip: Airport pickup AND return transfer (best value!)",
        suggestions: ['One-way', 'Round trip']
      };
    }

    this.calculatePrice();
    this.context.step = 'AWAITING_CONFIRMATION';
    return this.showBookingSummary();
  }

  private showBookingSummary(): AgentResponse {
    const airportCode = this.context.airport || 'PUJ';
    const airportName = AIRPORTS[airportCode]?.split(' (')[0] || airportCode;

    return {
      message: `Here's your transfer summary:\n\n• Pickup: ${airportName}\n• Destination: ${this.context.hotel}\n• Vehicle: ${this.context.vehicle}\n• Travelers: ${this.context.passengers}\n• Luggage: ${this.context.suitcases} piece${this.context.suitcases !== 1 ? 's' : ''}\n• Service: ${this.context.tripType}\n• Total: $${this.context.price} USD\n\nThis includes meet & greet at arrivals, flight tracking, and free cancellation.\n\nReady to book?`,
      suggestions: ['Yes, book it!', 'Change vehicle', 'Start over']
    };
  }

  private handleConfirmationInput(query: string): AgentResponse {
    const positiveResponses = ['yes', 'book', 'confirm', 'proceed', 'sounds good', 'perfect', 'ok', 'okay', 'sure', 'yep', 'yeah', 'go ahead', 'do it', 'absolutely', 'definitely', 'please', 'ready'];

    if (query.includes('start over') || query.includes('cancel') || query.includes('no')) {
      this.context = { step: 'IDLE' };
      return this.startBookingFlow();
    }

    if (query.includes('change vehicle') || query.includes('different vehicle')) {
      const availableVehicles = this.vehicleTypes
        .map(v => `• ${v.name} - Up to ${v.passenger_capacity} passengers`)
        .join('\n');
      return {
        message: `Of course! Which vehicle would you prefer?\n\n${availableVehicles}`,
        suggestions: this.vehicleTypes.map(v => v.name)
      };
    }

    for (const vehicle of this.vehicleTypes) {
      if (query.toLowerCase() === vehicle.name.toLowerCase()) {
        this.context.vehicle = vehicle.name;
        this.calculatePrice();
        return this.showBookingSummary();
      }
    }

    if (positiveResponses.some(r => query.includes(r))) {
      return this.triggerBooking();
    }

    return {
      message: "Would you like me to secure this transfer for you? You can pay securely with card or iDEAL.",
      suggestions: ['Yes, book it!', 'Change vehicle', 'Start over']
    };
  }

  private triggerBooking(): AgentResponse {
    const bookingAction: BookingAction & { priceSource?: string; originalPrice?: number } = {
      action: 'START_BOOKING',
      airport: this.context.airport!,
      hotel: this.context.hotel!,
      region: this.context.region!,
      vehicle: this.context.vehicle!,
      passengers: this.context.passengers!,
      suitcases: this.context.suitcases!,
      tripType: this.context.tripType!,
      price: this.context.price!,
      currency: 'USD',
      paymentProvider: 'Stripe',
      paymentMethods: ['iDEAL', 'Card'],
      priceSource: this.context.priceSource || 'standard',
      originalPrice: this.context.originalPrice || this.context.price
    };

    this.context = { step: 'IDLE' };

    return {
      message: "Wonderful! Opening your secure booking form now...\n\nYou're just a few clicks away from a stress-free arrival in the Dominican Republic!",
      bookingAction: bookingAction as BookingAction,
      suggestions: []
    };
  }

  private calculatePrice(): void {
    if (this.context.matchedPrice) {
      this.context.price = this.context.matchedPrice;
      return;
    }

    if (!this.context.airport || !this.context.region || !this.context.vehicle || !this.context.tripType) return;

    const vehicle = this.vehicleTypes.find(v => v.name === this.context.vehicle);
    if (!vehicle) return;

    const route = this.routePricing.find(
      r => r.origin === this.context.airport &&
           r.destination === this.context.region &&
           r.vehicle_type_id === vehicle.id
    );

    if (!route) return;

    const basePrice = Number(route.price);
    this.context.price = this.context.tripType === 'Round trip' ? basePrice * 2 : basePrice;

    if (!this.context.originalPrice) {
      this.context.originalPrice = this.context.price;
    }
  }

  private extractAirport(query: string): string | null {
    if (query.includes('puj') || query.includes('punta cana')) return 'PUJ';
    if (query.includes('sdq') || query.includes('santo domingo')) return 'SDQ';
    if (query.includes('lrm') || query.includes('la romana')) return 'LRM';
    if (query.includes('pop') || query.includes('puerto plata')) return 'POP';
    return null;
  }

  private detectRegionFromQuery(query: string): string | null {
    const lowerQuery = query.toLowerCase();
    for (const [hotelKey, region] of Object.entries(HOTEL_TO_REGION)) {
      if (lowerQuery.includes(hotelKey)) {
        return region;
      }
    }
    return this.detectRegionDirect(query);
  }

  private detectRegionDirect(query: string): string | null {
    const lowerQuery = query.toLowerCase();
    if (lowerQuery.includes('bavaro') || (lowerQuery.includes('punta cana') && !lowerQuery.includes('cap'))) {
      return 'Bavaro / Punta Cana';
    }
    if (lowerQuery.includes('cap cana') || lowerQuery.includes('uvero alto')) {
      return 'Cap Cana / Uvero Alto';
    }
    if (lowerQuery.includes('santo domingo')) {
      return 'Santo Domingo';
    }
    if (lowerQuery.includes('la romana') || lowerQuery.includes('bayahibe') || lowerQuery.includes('dominicus')) {
      return 'La Romana / Bayahibe';
    }
    if (lowerQuery.includes('puerto plata') || lowerQuery.includes('playa dorada') || lowerQuery.includes('cofresi')) {
      return 'Puerto Plata / Playa Dorada';
    }
    if (lowerQuery.includes('samana') || lowerQuery.includes('las terrenas')) {
      return 'Samana / Las Terrenas';
    }
    if (lowerQuery.includes('sosua') || lowerQuery.includes('cabarete')) {
      return 'Sosua / Cabarete';
    }
    if (lowerQuery.includes('juan dolio') || lowerQuery.includes('boca chica')) {
      return 'Juan Dolio / Boca Chica';
    }
    return null;
  }

  private extractHotelName(query: string): string {
    const words = query.split(/\s+/);
    const capitalizedWords = words.map(w => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase());
    return capitalizedWords.join(' ');
  }

  private extractNumber(query: string): number | null {
    const match = query.match(/(\d+)/);
    if (match) return parseInt(match[1]);
    const wordNumbers: Record<string, number> = {
      'one': 1, 'two': 2, 'three': 3, 'four': 4, 'five': 5,
      'six': 6, 'seven': 7, 'eight': 8, 'nine': 9, 'ten': 10
    };
    for (const [word, num] of Object.entries(wordNumbers)) {
      if (query.includes(word)) return num;
    }
    return null;
  }

  private handleFAQ(query: string): AgentResponse {
    if (query.includes('private') || query.includes('shared') || query.includes('shuttle')) {
      return {
        message: "Great question! All our transfers are 100% private - it's just you and your party in the vehicle.\n\nNo shared rides, no waiting around for other passengers. Your professional driver takes you directly from the airport to your destination in comfort.\n\nReady to book your private transfer?",
        suggestions: ['Book a transfer', 'See prices', 'More questions']
      };
    }

    if (query.includes('delay') || query.includes('late flight') || query.includes('track')) {
      return {
        message: "Don't worry about flight delays! We track all flights in real-time, so your driver knows exactly when you'll land.\n\nIf your flight is delayed - even by several hours - your driver will adjust automatically. There's never any extra charge for delays.\n\nYour peace of mind is our priority!",
        suggestions: ['Book a transfer', 'See prices', 'More questions']
      };
    }

    if (query.includes('meet') || query.includes('find') || query.includes('where')) {
      return {
        message: "Finding your driver is easy! After you clear customs, look for your driver holding a sign with your name at the arrivals area.\n\nThey'll greet you with a smile, help you with all your luggage, and escort you to your comfortable, air-conditioned vehicle.\n\nWe make arriving stress-free!",
        suggestions: ['Book a transfer', 'See prices', 'More questions']
      };
    }

    if (query.includes('per person') || query.includes('per vehicle') || query.includes('include')) {
      return {
        message: "Our prices are per vehicle, not per person - so you get great value traveling with family or friends!\n\nEvery booking includes:\n• Meet & greet service\n• Flight tracking\n• Luggage assistance\n• All taxes and fees\n• No hidden charges - ever!\n\nWould you like to see prices for your route?",
        suggestions: ['Book a transfer', 'See prices', 'More questions']
      };
    }

    if (query.includes('cancel') || query.includes('refund')) {
      return {
        message: "We understand plans can change! You can cancel your booking free of charge up to 24 hours before your transfer.\n\nFull details are included in your confirmation email, and our support team is always here to help if you need to make changes.\n\nAnything else I can help with?",
        suggestions: ['Book a transfer', 'See prices', 'More questions']
      };
    }

    if (query.includes('payment') || query.includes('secure') || query.includes('stripe')) {
      return {
        message: "Your payment security is our top priority! We use Stripe, the world's most trusted payment processor.\n\nYour card details are encrypted and never stored on our servers. You can also pay with iDEAL, Apple Pay, or Google Pay.\n\nBook with confidence!",
        suggestions: ['Book a transfer', 'See prices', 'More questions']
      };
    }

    return {
      message: "Here's why thousands of travelers choose us:\n\n• 100% private transfers - no shared rides\n• Professional, English-speaking drivers\n• Free flight tracking & delay protection\n• Prices per vehicle, not per person\n• All taxes included - no surprises\n• Free cancellation up to 24hrs before\n• Secure payment via Stripe\n• 24/7 customer support\n\nHow can I help you today?",
      suggestions: ['Book a transfer', 'See prices', 'I have a question']
    };
  }

  getGreeting(): AgentResponse {
    return this.startBookingFlow();
  }

  resetContext(): void {
    this.context = { step: 'IDLE' };
    this.conversationHistory = [];
  }
}
