import { supabase, Hotel, Service } from './supabase';
import { detectLanguage, getTranslations, Language } from './translations';

export interface BookingAction {
  action: 'START_BOOKING';
  airport: string;
  hotel: string;
  region: string;
  vehicle: string;
  passengers: number;
  suitcases: number;
  tripType: string;
  price: number;
  currency: string;
  paymentProvider: string;
  paymentMethods: string[];
  priceSource?: string;
  originalPrice?: number;
}

export interface VehicleOption {
  name: string;
  capacity: number;
  luggageCapacity: number;
  oneWayPrice: number;
  roundTripPrice: number;
  recommended?: boolean;
}

export interface PriceScanRequest {
  type: 'PRICE_SCAN';
  airport: string;
  hotel: string;
  region: string;
  basePrice: number;
  route: string;
  passengers: number;
  luggage: number;
  vehicleOptions: VehicleOption[];
}

export interface AgentResponse {
  message: string;
  hotels?: Hotel[];
  services?: Service[];
  suggestions?: string[];
  bookingAction?: BookingAction;
  priceScanRequest?: PriceScanRequest;
  vehicleImage?: {
    url: string;
    alt: string;
    caption: string;
  };
  languageSwitch?: 'en' | 'nl' | 'es';
}

type BookingStep =
  | 'IDLE'
  | 'AWAITING_AIRPORT'
  | 'AWAITING_HOTEL'
  | 'AWAITING_PASSENGERS'
  | 'AWAITING_LUGGAGE'
  | 'AWAITING_VEHICLE_SELECTION'
  | 'AWAITING_TRIP_TYPE'
  | 'AWAITING_CONFIRMATION';

interface BookingContext {
  step: BookingStep;
  airport?: string;
  hotel?: string;
  region?: string;
  vehicle?: string;
  passengers?: number;
  suitcases?: number;
  tripType?: 'One-way' | 'Round trip';
  price?: number;
  priceSource?: string;
  originalPrice?: number;
  matchedPrice?: number;
}

const AIRPORTS: Record<string, string> = {
  'PUJ': 'Punta Cana International Airport (PUJ)',
  'SDQ': 'Santo Domingo Las Americas (SDQ)',
  'LRM': 'La Romana International Airport (LRM)',
  'POP': 'Puerto Plata Gregorio Luperon (POP)'
};

const ROUNDTRIP_MULTIPLIER = 1.9;

const FALLBACK_VEHICLE_PRICING: Record<string, { base: number; perKm: number; capacity: number; luggage: number }> = {
  'Sedan': { base: 25, perKm: 0.8, capacity: 3, luggage: 3 },
  'SUV': { base: 35, perKm: 1.0, capacity: 4, luggage: 4 },
  'Minivan': { base: 45, perKm: 1.2, capacity: 6, luggage: 6 },
  'Suburban': { base: 65, perKm: 1.4, capacity: 5, luggage: 5 },
  'Sprinter': { base: 95, perKm: 1.8, capacity: 12, luggage: 12 },
  'Mini Bus': { base: 150, perKm: 2.5, capacity: 20, luggage: 20 }
};

const DISTANCE_KEYWORDS: Record<string, { km: number; zone: string }> = {
  'downtown': { km: 15, zone: 'City Center' },
  'centro': { km: 15, zone: 'City Center' },
  'city center': { km: 15, zone: 'City Center' },
  'beach': { km: 25, zone: 'Beach Area' },
  'playa': { km: 25, zone: 'Beach Area' },
  'resort': { km: 30, zone: 'Resort Area' },
  'hotel': { km: 25, zone: 'Hotel Zone' },
  'villa': { km: 35, zone: 'Villa Area' },
  'airbnb': { km: 30, zone: 'Rental Area' },
  'apartment': { km: 20, zone: 'Residential' },
  'house': { km: 30, zone: 'Residential' },
  'marina': { km: 35, zone: 'Marina Area' },
  'golf': { km: 30, zone: 'Golf Resort' },
  'all inclusive': { km: 30, zone: 'All-Inclusive Resort' },
  'boutique': { km: 25, zone: 'Boutique Hotel' }
};

const AIRPORT_DEFAULT_DISTANCES: Record<string, number> = {
  'PUJ': 25,
  'SDQ': 30,
  'LRM': 20,
  'POP': 25
};

interface VehicleType {
  id: string;
  name: string;
  passenger_capacity: number;
  luggage_capacity: number;
}

interface PricingRule {
  id: string;
  origin: string;
  destination: string;
  vehicle_type_id: string;
  base_price: number;
  zone: string;
}

interface FleetVehicle {
  id: string;
  make: string;
  model: string;
  year: number;
  color: string;
  capacity: number;
  luggage_capacity: number;
  image_url: string;
  amenities: string[];
  vehicle_type_id: string;
}

interface HotelZone {
  id: string;
  hotel_name: string;
  zone_code: string;
  zone_name: string;
  search_terms: string[];
  is_active: boolean;
}

export class TravelAgent {
  private context: BookingContext = { step: 'IDLE' };
  private hotels: Hotel[] = [];
  private services: Service[] = [];
  private vehicleTypes: VehicleType[] = [];
  private pricingRules: PricingRule[] = [];
  private fleetVehicles: FleetVehicle[] = [];
  private hotelZones: HotelZone[] = [];
  private conversationHistory: Array<{ role: string; content: string }> = [];
  private currentLanguage: Language = 'en';

  async initialize(): Promise<void> {
    try {
      const [hotelsResult, servicesResult, vehicleTypesResult, pricingRulesResult, vehiclesResult, hotelZonesResult] = await Promise.all([
        supabase.from('hotels').select('*'),
        supabase.from('services').select('*'),
        supabase.from('vehicle_types').select('id, name, passenger_capacity, luggage_capacity').eq('is_active', true),
        supabase.from('pricing_rules').select('id, origin, destination, vehicle_type_id, base_price, zone').eq('is_active', true),
        supabase.from('fleet_vehicles').select('id, make, model, year, color, capacity, luggage_capacity, image_url, amenities, vehicle_type_id').eq('status', 'available'),
        supabase.from('hotel_zones').select('*').eq('is_active', true)
      ]);
      if (hotelsResult.data) this.hotels = hotelsResult.data;
      if (servicesResult.data) this.services = servicesResult.data;
      if (vehicleTypesResult.data) this.vehicleTypes = vehicleTypesResult.data;
      if (pricingRulesResult.data) this.pricingRules = pricingRulesResult.data;
      if (vehiclesResult.data) this.fleetVehicles = vehiclesResult.data;
      if (hotelZonesResult.data) this.hotelZones = hotelZonesResult.data;
    } catch (error) {
      console.error('Failed to initialize TravelAgent:', error);
    }
  }

  setLanguage(lang: Language): void {
    this.currentLanguage = lang;
  }

  async processQuery(userMessage: string): Promise<AgentResponse> {
    return this.processMessage(userMessage);
  }

  async processMessage(userMessage: string): Promise<AgentResponse> {
    const query = userMessage.toLowerCase().trim();

    const detectedLang = detectLanguage(userMessage);
    if (detectedLang) {
      this.currentLanguage = detectedLang;
      const t = getTranslations(detectedLang);
      return {
        message: t.chat.languageChanged,
        suggestions: [t.services.bookNow, t.agent.anotherQuestion, 'Tell me about services'],
        languageSwitch: detectedLang
      };
    }

    if (query === 'start over' || query === 'reset' || query === 'cancel booking') {
      this.context = { step: 'IDLE' };
      this.conversationHistory = [];
      return this.getWelcomeMessage();
    }

    if (this.context.step !== 'IDLE') {
      return this.handleBookingFlow(query, userMessage);
    }

    const transferQuery = this.detectTransferQuery(query);
    if (transferQuery) {
      return transferQuery;
    }

    if (this.isGreeting(query)) {
      return this.getWelcomeMessage();
    }

    if (this.isBookingRelated(query)) {
      return this.startGuidedBooking();
    }

    if (query.includes('fun facts') || query.includes('about dominican')) {
      return this.showDominicanFunFacts();
    }

    if (this.isAskingForPhotos(query)) {
      return this.showInstagramPhotos();
    }

    if (query.includes('pickup procedure') || query.includes('how does pickup work') || query.includes('real human')) {
      return this.showPickupProcedure();
    }

    if (this.isFAQQuery(query)) {
      return this.handleFAQ(query);
    }

    return this.handleGeneralQuestion(userMessage);
  }

  private handleBookingFlow(query: string, originalMessage: string): AgentResponse {
    switch (this.context.step) {
      case 'AWAITING_AIRPORT':
        return this.handleAirportInput(query);
      case 'AWAITING_HOTEL':
        return this.handleHotelInput(query);
      case 'AWAITING_PASSENGERS':
        return this.handlePassengersInput(query);
      case 'AWAITING_LUGGAGE':
        return this.handleLuggageInput(query);
      case 'AWAITING_VEHICLE_SELECTION':
        return this.handleVehicleSelection(query);
      case 'AWAITING_TRIP_TYPE':
        return this.handleTripTypeInput(query);
      case 'AWAITING_CONFIRMATION':
        return this.handleConfirmationInput(query);
      default:
        return this.getWelcomeMessage();
    }
  }

  private detectTransferQuery(query: string): AgentResponse | null {
    const airport = this.extractAirport(query);
    if (!airport) return null;

    const hotelMatch = this.findHotelInDatabase(query);
    let region: string | null = null;
    let hotelName: string = '';
    let useFallback = false;

    if (hotelMatch) {
      region = hotelMatch.zone_name;
      hotelName = hotelMatch.hotel_name;
    } else {
      region = this.detectRegionFromQuery(query);
      if (region) {
        hotelName = this.extractHotelName(query) || `Hotel in ${region}`;
      } else {
        hotelName = this.extractHotelName(query);
        if (hotelName && hotelName.length > 3) {
          const estimated = this.estimateDistanceFromQuery(query);
          region = estimated.zone;
          useFallback = true;
        }
      }
    }

    if (!region || !hotelName) return null;

    const pricingRules = this.pricingRules.filter(
      rule => rule.origin === airport && rule.destination === region
    );

    if (pricingRules.length === 0 && !useFallback) {
      const estimated = this.estimateDistanceFromQuery(query);
      region = estimated.zone;
      useFallback = true;
    }

    this.context = {
      step: 'AWAITING_PASSENGERS',
      airport,
      hotel: hotelName,
      region,
      priceSource: useFallback ? 'estimated' : 'standard'
    };

    const airportName = AIRPORTS[airport]?.split(' (')[0] || airport;

    const message = useFallback
      ? `I'll help you with a transfer from **${airportName}** to **${hotelName}**.\n\nI'll calculate estimated pricing based on typical distances for this area.\n\n**How many passengers will be traveling?**\n\n*Including yourself and any children*`
      : `Perfect! I can help you with a transfer from **${airportName}** to **${hotelName}**.\n\nTo recommend the ideal vehicle and provide accurate pricing, I need a few quick details.\n\n**How many passengers will be traveling?**\n\n*Including yourself and any children*`;

    return {
      message,
      suggestions: ['1 passenger', '2 passengers', '3-4 passengers', '5-6 passengers', '7+ passengers']
    };
  }

  private getWelcomeMessage(): AgentResponse {
    return {
      message: `Welcome to **Dominican Transfers** - Premium Private Airport Transportation\n\nI'm here to help you book a comfortable, stress-free transfer to your destination.\n\n**Our Services Include:**\n- Private airport pickups & drop-offs\n- Meet & greet at arrivals\n- Flight tracking & delay protection\n- Professional English-speaking drivers\n- 24/7 customer support\n\n**How can I help you today?**\n\nJust tell me your route (e.g., "PUJ to Hard Rock Hotel") or ask me anything about traveling in the Dominican Republic!`,
      suggestions: [
        'PUJ to Hard Rock Hotel',
        'PUJ to Iberostar Bavaro',
        'SDQ to JW Marriott',
        'What if my flight is delayed?',
        'How does pickup work?'
      ]
    };
  }

  private startGuidedBooking(): AgentResponse {
    this.context = { step: 'AWAITING_AIRPORT' };
    return {
      message: `Let's get your transfer booked!\n\n**Which airport will you be arriving at?**`,
      suggestions: ['PUJ - Punta Cana', 'SDQ - Santo Domingo', 'LRM - La Romana', 'POP - Puerto Plata']
    };
  }

  private handleAirportInput(query: string): AgentResponse {
    const airport = this.extractAirport(query);

    if (airport) {
      this.context.airport = airport;
      this.context.step = 'AWAITING_HOTEL';
      const airportName = AIRPORTS[airport]?.split(' (')[0] || airport;
      return {
        message: `Great, **${airportName}**!\n\n**Where would you like to be taken?**\n\nPlease tell me your hotel name, resort, or destination area.`,
        suggestions: ['Hard Rock Hotel', 'Iberostar Bavaro', 'Dreams Macao', 'Hyatt Zilara Cap Cana']
      };
    }

    return {
      message: "I didn't catch that. Which airport will you be arriving at?",
      suggestions: ['PUJ - Punta Cana', 'SDQ - Santo Domingo', 'LRM - La Romana', 'POP - Puerto Plata']
    };
  }

  private handleHotelInput(query: string): AgentResponse {
    const hotelMatch = this.findHotelInDatabase(query);

    if (hotelMatch) {
      this.context.hotel = hotelMatch.hotel_name;
      this.context.region = hotelMatch.zone_name;
      this.context.step = 'AWAITING_PASSENGERS';
      return this.askForPassengers();
    }

    const region = this.detectRegionFromQuery(query);
    const hotelName = this.extractHotelName(query);

    if (region) {
      this.context.hotel = hotelName.length > 3 ? hotelName : `Hotel in ${region}`;
      this.context.region = region;
      this.context.step = 'AWAITING_PASSENGERS';
      return this.askForPassengers();
    }

    const selectedRegion = this.detectRegionDirect(query);
    if (selectedRegion) {
      this.context.region = selectedRegion;
      this.context.hotel = `Hotel in ${selectedRegion}`;
      this.context.step = 'AWAITING_PASSENGERS';
      return this.askForPassengers();
    }

    if (hotelName && hotelName.length > 2) {
      const estimatedDistance = this.estimateDistanceFromQuery(query);
      this.context.hotel = hotelName;
      this.context.region = estimatedDistance.zone;
      this.context.priceSource = 'estimated';
      this.context.step = 'AWAITING_PASSENGERS';

      const airportName = AIRPORTS[this.context.airport!]?.split(' (')[0] || this.context.airport;
      return {
        message: `I'll provide pricing for **${hotelName}** based on estimated distance from ${airportName}.\n\n**How many passengers will be traveling?**\n\n*Including yourself and any children*`,
        suggestions: ['1 passenger', '2 passengers', '3-4 passengers', '5-6 passengers', '7+ passengers']
      };
    }

    return {
      message: "Where will you be staying? You can tell me your hotel name, address, or the general area.",
      suggestions: ['Hard Rock Hotel', 'Iberostar Bavaro', 'Dreams Macao', 'My hotel is not listed']
    };
  }

  private estimateDistanceFromQuery(query: string): { km: number; zone: string } {
    const lowerQuery = query.toLowerCase();

    for (const [keyword, data] of Object.entries(DISTANCE_KEYWORDS)) {
      if (lowerQuery.includes(keyword)) {
        return data;
      }
    }

    const defaultKm = AIRPORT_DEFAULT_DISTANCES[this.context.airport!] || 25;
    return { km: defaultKm, zone: 'General Area' };
  }

  private generateFallbackPricing(airport: string, estimatedKm: number): VehicleOption[] {
    const vehicleOptions: VehicleOption[] = [];

    for (const [vehicleName, pricing] of Object.entries(FALLBACK_VEHICLE_PRICING)) {
      const oneWayPrice = Math.round(pricing.base + (estimatedKm * pricing.perKm));
      const roundTripPrice = Math.round(oneWayPrice * ROUNDTRIP_MULTIPLIER);

      vehicleOptions.push({
        name: vehicleName,
        capacity: pricing.capacity,
        luggageCapacity: pricing.luggage,
        oneWayPrice,
        roundTripPrice,
        recommended: false
      });
    }

    return vehicleOptions.sort((a, b) => a.oneWayPrice - b.oneWayPrice);
  }

  private askForPassengers(): AgentResponse {
    const airportName = AIRPORTS[this.context.airport!]?.split(' (')[0] || this.context.airport;
    return {
      message: `Excellent! Transfer from **${airportName}** to **${this.context.hotel}**.\n\nTo recommend the perfect vehicle, I need a few details.\n\n**How many passengers will be traveling?**\n\n*Including yourself and any children*`,
      suggestions: ['1 passenger', '2 passengers', '3-4 passengers', '5-6 passengers', '7+ passengers']
    };
  }

  private handlePassengersInput(query: string): AgentResponse {
    let passengers = this.extractNumber(query);

    if (query.includes('solo') || query.includes('alone') || query.includes('just me')) {
      passengers = 1;
    } else if (query.includes('couple') || query.includes('two of us')) {
      passengers = 2;
    } else if (query.includes('3-4') || query.includes('3 to 4')) {
      passengers = 4;
    } else if (query.includes('5-6') || query.includes('5 to 6')) {
      passengers = 6;
    } else if (query.includes('7+') || query.includes('7 or more')) {
      passengers = 8;
    }

    if (passengers && passengers > 0 && passengers <= 30) {
      this.context.passengers = passengers;
      this.context.step = 'AWAITING_LUGGAGE';

      const luggageSuggestions = passengers <= 2
        ? ['1 suitcase', '2 suitcases', '3 suitcases']
        : passengers <= 4
          ? ['2 suitcases', '4 suitcases', '6 suitcases']
          : ['4 suitcases', '6 suitcases', '8+ suitcases'];

      return {
        message: `Got it, **${passengers} passenger${passengers > 1 ? 's' : ''}**.\n\n**How many pieces of luggage will you have?**\n\nPlease include:\n- Checked suitcases\n- Large carry-on bags\n- Golf clubs or oversized items`,
        suggestions: luggageSuggestions
      };
    }

    return {
      message: "How many passengers will be traveling? This helps me recommend the right vehicle.",
      suggestions: ['1 passenger', '2 passengers', '3-4 passengers', '5-6 passengers', '7+ passengers']
    };
  }

  private handleLuggageInput(query: string): AgentResponse {
    let suitcases = this.extractNumber(query);

    if (query.includes('8+') || query.includes('8 or more') || query.includes('lots')) {
      suitcases = 10;
    }

    if (suitcases !== null && suitcases >= 0 && suitcases <= 30) {
      this.context.suitcases = suitcases;
      return this.triggerPriceScanWithAllVehicles();
    }

    return {
      message: "How many pieces of luggage will you have? Include checked bags and large carry-ons.",
      suggestions: ['2 suitcases', '4 suitcases', '6 suitcases', '8+ suitcases']
    };
  }

  private triggerPriceScanWithAllVehicles(): AgentResponse {
    const airport = this.context.airport!;
    const region = this.context.region!;
    const hotelName = this.context.hotel!;
    const passengers = this.context.passengers!;
    const luggage = this.context.suitcases!;
    const airportName = AIRPORTS[airport]?.split(' (')[0] || airport;

    const pricingRules = this.pricingRules.filter(
      rule => rule.origin === airport && rule.destination === region
    );

    let vehicleOptions: VehicleOption[] = [];
    let recommendedVehicle: string | null = null;
    let lowestPrice = Infinity;
    let usingFallback = false;

    if (pricingRules.length === 0) {
      usingFallback = true;
      const estimatedDistance = this.estimateDistanceFromQuery(hotelName);
      vehicleOptions = this.generateFallbackPricing(airport, estimatedDistance.km);
      this.context.priceSource = 'estimated';

      for (const option of vehicleOptions) {
        const canFit = passengers <= option.capacity && luggage <= option.luggageCapacity;
        if (canFit && option.oneWayPrice < lowestPrice) {
          lowestPrice = option.oneWayPrice;
          recommendedVehicle = option.name;
        }
      }
    } else {
      for (const rule of pricingRules) {
        const vehicle = this.vehicleTypes.find(v => v.id === rule.vehicle_type_id);
        if (vehicle) {
          const oneWayPrice = Number(rule.base_price);
          const roundTripPrice = Math.round(oneWayPrice * ROUNDTRIP_MULTIPLIER);
          const canFit = passengers <= vehicle.passenger_capacity && luggage <= vehicle.luggage_capacity;

          const option: VehicleOption = {
            name: vehicle.name,
            capacity: vehicle.passenger_capacity,
            luggageCapacity: vehicle.luggage_capacity,
            oneWayPrice,
            roundTripPrice,
            recommended: false
          };

          vehicleOptions.push(option);

          if (canFit && oneWayPrice < lowestPrice) {
            lowestPrice = oneWayPrice;
            recommendedVehicle = vehicle.name;
          }
        }
      }
    }

    vehicleOptions.sort((a, b) => a.oneWayPrice - b.oneWayPrice);

    if (recommendedVehicle) {
      const recOption = vehicleOptions.find(v => v.name === recommendedVehicle);
      if (recOption) recOption.recommended = true;
    }

    const scanMessage = usingFallback
      ? `Calculating estimated rates for your transfer to ${hotelName}...`
      : `Scanning live market rates for your transfer...`;

    this.context.step = 'AWAITING_VEHICLE_SELECTION';

    return {
      message: scanMessage,
      priceScanRequest: {
        type: 'PRICE_SCAN',
        airport,
        hotel: hotelName,
        region: usingFallback ? 'Estimated Zone' : region,
        basePrice: lowestPrice === Infinity ? 45 : lowestPrice,
        route: `${airportName} to ${hotelName}`,
        passengers,
        luggage,
        vehicleOptions
      },
      suggestions: []
    };
  }

  private handleVehicleSelection(query: string): AgentResponse {
    const allVehicleNames = [
      ...this.vehicleTypes.map(v => v.name),
      ...Object.keys(FALLBACK_VEHICLE_PRICING)
    ];
    const uniqueVehicles = [...new Set(allVehicleNames)];

    for (const vehicleName of uniqueVehicles) {
      if (query.toLowerCase().includes(vehicleName.toLowerCase())) {
        this.context.vehicle = vehicleName;
        this.context.step = 'AWAITING_TRIP_TYPE';

        const dbVehicle = this.vehicleTypes.find(v => v.name === vehicleName);
        if (dbVehicle) {
          const pricingRule = this.pricingRules.find(
            r => r.origin === this.context.airport &&
                 r.destination === this.context.region &&
                 r.vehicle_type_id === dbVehicle.id
          );

          if (pricingRule) {
            this.context.originalPrice = Number(pricingRule.base_price);
          }
        } else if (FALLBACK_VEHICLE_PRICING[vehicleName]) {
          const fallback = FALLBACK_VEHICLE_PRICING[vehicleName];
          const estimatedDistance = this.estimateDistanceFromQuery(this.context.hotel || '');
          this.context.originalPrice = Math.round(fallback.base + (estimatedDistance.km * fallback.perKm));
        }

        return {
          message: `Excellent choice! The **${vehicleName}** is perfect for your group.\n\n**Would you like:**\n\n- **One-way** - Airport to hotel only\n- **Round trip** - Airport pickup AND return transfer (save 5%!)`,
          suggestions: ['One-way transfer', 'Round trip (best value!)']
        };
      }
    }

    if (query.includes('book') || query.includes('select') || query.includes('choose')) {
      return {
        message: "Which vehicle would you like to book? Please select from the options shown above.",
        suggestions: uniqueVehicles.slice(0, 4)
      };
    }

    return {
      message: "Please select a vehicle to continue with your booking.",
      suggestions: uniqueVehicles.slice(0, 4)
    };
  }

  private handleTripTypeInput(query: string): AgentResponse {
    if (query.includes('round') || query.includes('both') || query.includes('return')) {
      this.context.tripType = 'Round trip';
    } else if (query.includes('one') || query.includes('single') || query.includes('only')) {
      this.context.tripType = 'One-way';
    } else {
      return {
        message: "Would you prefer a one-way transfer or round trip?\n\n- **One-way**: Airport to hotel\n- **Round trip**: Airport pickup AND return (best value!)",
        suggestions: ['One-way', 'Round trip']
      };
    }

    this.calculatePrice();
    this.context.step = 'AWAITING_CONFIRMATION';
    return this.showBookingSummary();
  }

  private showBookingSummary(): AgentResponse {
    const airportCode = this.context.airport || 'PUJ';
    const airportName = AIRPORTS[airportCode]?.split(' (')[0] || airportCode;

    return {
      message: `**Booking Summary**\n\n**Route:** ${airportName} → ${this.context.hotel}\n**Vehicle:** ${this.context.vehicle}\n**Passengers:** ${this.context.passengers}\n**Luggage:** ${this.context.suitcases} piece${this.context.suitcases !== 1 ? 's' : ''}\n**Service:** ${this.context.tripType}\n\n**Total: $${this.context.price} USD**\n\n**Included:**\n- Meet & greet at arrivals\n- Flight tracking & delay protection\n- Professional driver\n- All taxes & fees\n- Free cancellation (24hrs)\n\n**Ready to secure your transfer?**`,
      suggestions: ['Yes, book now!', 'Change vehicle', 'Start over']
    };
  }

  private handleConfirmationInput(query: string): AgentResponse {
    const positiveResponses = ['yes', 'book', 'confirm', 'proceed', 'sounds good', 'perfect', 'ok', 'okay', 'sure', 'yep', 'yeah', 'go ahead', 'do it', 'absolutely', 'definitely', 'please', 'ready'];

    if (query.includes('start over') || query.includes('cancel') || query === 'no') {
      this.context = { step: 'IDLE' };
      return this.getWelcomeMessage();
    }

    if (query.includes('change vehicle') || query.includes('different vehicle')) {
      this.context.step = 'AWAITING_VEHICLE_SELECTION';
      return {
        message: "Which vehicle would you prefer?",
        suggestions: this.vehicleTypes.slice(0, 4).map(v => v.name)
      };
    }

    for (const vehicle of this.vehicleTypes) {
      if (query.toLowerCase() === vehicle.name.toLowerCase()) {
        this.context.vehicle = vehicle.name;
        this.calculatePrice();
        return this.showBookingSummary();
      }
    }

    if (positiveResponses.some(r => query.includes(r))) {
      return this.triggerBooking();
    }

    return {
      message: "Would you like to proceed with this booking?",
      suggestions: ['Yes, book now!', 'Change vehicle', 'Start over']
    };
  }

  private triggerBooking(): AgentResponse {
    const bookingAction: BookingAction = {
      action: 'START_BOOKING',
      airport: this.context.airport!,
      hotel: this.context.hotel!,
      region: this.context.region!,
      vehicle: this.context.vehicle!,
      passengers: this.context.passengers!,
      suitcases: this.context.suitcases!,
      tripType: this.context.tripType!,
      price: this.context.price!,
      currency: 'USD',
      paymentProvider: 'Stripe',
      paymentMethods: ['iDEAL', 'Card'],
      priceSource: this.context.priceSource || 'standard',
      originalPrice: this.context.originalPrice || this.context.price
    };

    this.context = { step: 'IDLE' };

    return {
      message: "Opening your secure booking form...\n\nYou're just a few clicks away from a stress-free arrival!",
      bookingAction,
      suggestions: []
    };
  }

  private calculatePrice(): void {
    if (this.context.matchedPrice) {
      this.context.price = this.context.matchedPrice;
      return;
    }

    if (!this.context.airport || !this.context.vehicle || !this.context.tripType) return;

    const vehicle = this.vehicleTypes.find(v => v.name === this.context.vehicle);
    let basePrice: number | null = null;

    if (vehicle && this.context.region) {
      const rule = this.pricingRules.find(
        r => r.origin === this.context.airport &&
             r.destination === this.context.region &&
             r.vehicle_type_id === vehicle.id
      );

      if (rule) {
        basePrice = Number(rule.base_price);
      }
    }

    if (basePrice === null) {
      const fallback = FALLBACK_VEHICLE_PRICING[this.context.vehicle!];
      if (fallback) {
        const estimatedDistance = this.estimateDistanceFromQuery(this.context.hotel || '');
        basePrice = Math.round(fallback.base + (estimatedDistance.km * fallback.perKm));
        this.context.priceSource = 'estimated';
      } else {
        basePrice = 45;
      }
    }

    this.context.price = this.context.tripType === 'Round trip' ? Math.round(basePrice * ROUNDTRIP_MULTIPLIER) : basePrice;

    if (!this.context.originalPrice) {
      this.context.originalPrice = this.context.price;
    }
  }

  private findHotelInDatabase(query: string): HotelZone | null {
    const lowerQuery = query.toLowerCase();

    for (const hotel of this.hotelZones) {
      if (hotel.search_terms.some(term => lowerQuery.includes(term.toLowerCase()))) {
        return hotel;
      }
      if (lowerQuery.includes(hotel.hotel_name.toLowerCase())) {
        return hotel;
      }
    }

    return null;
  }

  private extractAirport(query: string): string | null {
    const lower = query.toLowerCase();
    if (lower.includes('puj') || lower.includes('punta cana')) return 'PUJ';
    if (lower.includes('sdq') || lower.includes('santo domingo')) return 'SDQ';
    if (lower.includes('lrm') || lower.includes('la romana')) return 'LRM';
    if (lower.includes('pop') || lower.includes('puerto plata')) return 'POP';
    return null;
  }

  private detectRegionFromQuery(query: string): string | null {
    const hotelMatch = this.findHotelInDatabase(query);
    if (hotelMatch) {
      return hotelMatch.zone_name;
    }
    return this.detectRegionDirect(query);
  }

  private detectRegionDirect(query: string): string | null {
    const lowerQuery = query.toLowerCase();
    if (lowerQuery.includes('bavaro') || (lowerQuery.includes('punta cana') && !lowerQuery.includes('cap'))) {
      return 'Bavaro / Punta Cana';
    }
    if (lowerQuery.includes('cap cana')) {
      return 'Cap Cana';
    }
    if (lowerQuery.includes('uvero alto') || lowerQuery.includes('macao')) {
      return 'Uvero Alto';
    }
    if (lowerQuery.includes('santo domingo') || lowerQuery.includes('sdq')) {
      return 'Santo Domingo';
    }
    if (lowerQuery.includes('la romana') || lowerQuery.includes('bayahibe') || lowerQuery.includes('dominicus')) {
      return 'Bayahibe';
    }
    if (lowerQuery.includes('puerto plata') || lowerQuery.includes('playa dorada') || lowerQuery.includes('cofresi')) {
      return 'Puerto Plata / Playa Dorada';
    }
    if (lowerQuery.includes('samana') || lowerQuery.includes('las terrenas')) {
      return 'Samana / Las Terrenas';
    }
    if (lowerQuery.includes('sosua') || lowerQuery.includes('cabarete')) {
      return 'Sosua / Cabarete';
    }
    if (lowerQuery.includes('juan dolio') || lowerQuery.includes('boca chica')) {
      return 'Juan Dolio / Boca Chica';
    }
    return null;
  }

  private extractHotelName(query: string): string {
    const stopWords = ['to', 'from', 'the', 'a', 'an', 'at', 'in', 'for', 'puj', 'sdq', 'lrm', 'pop', 'price', 'transfer', 'how', 'much', 'is', 'what'];
    const words = query.split(/\s+/).filter(w => !stopWords.includes(w.toLowerCase()));
    const capitalizedWords = words.map(w => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase());
    return capitalizedWords.join(' ');
  }

  private extractNumber(query: string): number | null {
    const match = query.match(/(\d+)/);
    if (match) return parseInt(match[1]);
    const wordNumbers: Record<string, number> = {
      'one': 1, 'two': 2, 'three': 3, 'four': 4, 'five': 5,
      'six': 6, 'seven': 7, 'eight': 8, 'nine': 9, 'ten': 10,
      'eleven': 11, 'twelve': 12
    };
    for (const [word, num] of Object.entries(wordNumbers)) {
      if (query.includes(word)) return num;
    }
    return null;
  }

  private isGreeting(query: string): boolean {
    const greetings = ['hello', 'hi', 'hey', 'hola', 'good morning', 'good afternoon', 'good evening', 'howdy', 'greetings', 'start'];
    return greetings.some(g => query === g || query.startsWith(g + ' ') || query.startsWith(g + ','));
  }

  private isBookingRelated(query: string): boolean {
    const bookingKeywords = [
      'book', 'transfer', 'airport', 'price', 'cost', 'how much',
      'quote', 'rate', 'reservation', 'ride', 'taxi', 'transport', 'pickup',
      'vehicle', 'car', 'van', 'suv', 'shuttle'
    ];
    return bookingKeywords.some(keyword => query.includes(keyword));
  }

  private isAskingForPhotos(query: string): boolean {
    const photoKeywords = [
      'photo', 'photos', 'picture', 'pictures', 'pic', 'pics',
      'image', 'images', 'gallery', 'see your', 'show me',
      'instagram', 'insta', 'look like', 'what do your',
      'vehicle photos', 'car photos', 'fleet photos'
    ];
    return photoKeywords.some(keyword => query.includes(keyword));
  }

  private isFAQQuery(query: string): boolean {
    const faqKeywords = [
      'private', 'shared', 'shuttle', 'delay', 'delayed', 'late flight',
      'meet', 'driver', 'find', 'per person', 'per vehicle', 'include',
      'tip', 'tipping', 'gratuity', 'luggage', 'bags', 'suitcase',
      'child seat', 'baby seat', 'car seat', 'cancel', 'refund',
      'payment', 'secure', 'safe', 'stripe', 'support', 'contact',
      'wait', 'waiting', 'track', 'how does', 'what if', 'is it'
    ];
    return faqKeywords.some(k => query.includes(k));
  }

  private showDominicanFunFacts(): AgentResponse {
    const funFacts = [
      "The Dominican Republic was the first place Columbus landed in 1492 - and he loved it so much he's buried in Santo Domingo!",
      "Baseball is basically a religion here. The DR has produced more MLB players per capita than any other country!",
      "Pico Duarte is the highest peak in the Caribbean at 3,098m!",
      "The merengue dance was invented here!",
      "Larimar, a beautiful blue stone, is found ONLY in the Dominican Republic.",
      "Santo Domingo has the first cathedral, hospital, and university in the Americas!",
      "Dominican coffee was once used as currency!",
      "The DR shares the island of Hispaniola with Haiti."
    ];

    const randomFacts = funFacts.sort(() => Math.random() - 0.5).slice(0, 3);

    return {
      message: `**Fun Facts about the Dominican Republic:**\n\n${randomFacts.map((fact, i) => `${i + 1}. ${fact}`).join('\n\n')}\n\nWant to explore this amazing island? I can help you book your airport transfer!`,
      suggestions: ['Book a transfer', 'More fun facts', 'PUJ to Hard Rock Hotel']
    };
  }

  private showInstagramPhotos(): AgentResponse {
    return {
      message: `Check out our Instagram for photos of our fleet and happy customers!\n\n**@dominicantransfers**\nhttps://www.instagram.com/dominicantransfers/\n\nYou'll find:\n- Our premium vehicles\n- Happy travelers\n- Beautiful Dominican destinations\n\nFollow us for travel tips and special offers!`,
      suggestions: ['Book a transfer', 'See vehicles', 'PUJ - Punta Cana']
    };
  }

  private showPickupProcedure(): AgentResponse {
    return {
      message: `**How Your Pickup Works:**\n\n1. **Before You Land** - Your driver tracks your flight in real-time\n\n2. **At Arrivals** - Your driver waits with a **sign showing YOUR NAME**\n\n3. **Easy to Spot** - Drivers wear branded shirts and stand in the designated pickup zone\n\n4. **Full Assistance** - They'll help with your luggage and escort you to your vehicle\n\n5. **Direct Transfer** - No stops, no waiting - straight to your hotel!\n\nYou'll receive a WhatsApp message with your driver's name, photo, and contact number before pickup.\n\nNo bots, no confusion - just a warm Dominican welcome!`,
      suggestions: ['Book now', 'What if my flight is delayed?', 'See prices']
    };
  }

  private handleFAQ(query: string): AgentResponse {
    const suggestions = ['Book a transfer', 'See prices', 'More questions'];

    if (query.includes('delay') || query.includes('late flight') || query.includes('track')) {
      return {
        message: `**Flight Delays? No Problem!**\n\n- We track your flight in real-time\n- Your driver adjusts automatically to any delays\n- No extra charges - ever!\n- Whether 30 minutes or 3 hours late, price stays the same\n\nYou'll never be stranded. It's included in every booking!`,
        suggestions
      };
    }

    if (query.includes('private') || query.includes('shared') || query.includes('shuttle')) {
      return {
        message: "All our transfers are **100% private** - just you and your party in the vehicle.\n\nNo shared rides, no waiting for others. Your driver takes you directly to your destination in comfort.",
        suggestions
      };
    }

    if (query.includes('per person') || query.includes('per vehicle') || query.includes('include')) {
      return {
        message: "Our prices are **per vehicle**, not per person!\n\n**Every booking includes:**\n- Meet & greet service\n- Flight tracking\n- Luggage assistance\n- All taxes and fees\n- No hidden charges",
        suggestions
      };
    }

    if (query.includes('cancel') || query.includes('refund')) {
      return {
        message: "**Free Cancellation** up to 24 hours before your transfer.\n\nPlans change - we understand! Full details in your confirmation email.",
        suggestions
      };
    }

    if (query.includes('payment') || query.includes('secure') || query.includes('stripe')) {
      return {
        message: "**Secure Payments via Stripe**\n\nYour card details are encrypted and never stored. Pay with:\n- Credit/Debit Card\n- iDEAL\n- Apple Pay\n- Google Pay",
        suggestions
      };
    }

    return {
      message: "**Why Choose Dominican Transfers?**\n\n- 100% private transfers\n- Professional English-speaking drivers\n- Free flight tracking\n- Prices per vehicle, not per person\n- All taxes included\n- Free cancellation (24hrs)\n- Secure Stripe payments\n- 24/7 support\n\nHow can I help you today?",
      suggestions
    };
  }

  private async handleGeneralQuestion(userMessage: string): Promise<AgentResponse> {
    const suggestions = this.context.step !== 'IDLE'
      ? ['Continue booking', 'Start over']
      : ['Book a transfer', 'See prices'];

    try {
      const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
      const supabaseKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 8000);

      const response = await fetch(`${supabaseUrl}/functions/v1/gpt-chat`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${supabaseKey}`
        },
        body: JSON.stringify({
          message: userMessage,
          conversationHistory: this.conversationHistory,
          isInBookingFlow: this.context.step !== 'IDLE'
        }),
        signal: controller.signal
      });

      clearTimeout(timeoutId);

      if (!response.ok) {
        return {
          message: "I'd be happy to help! For questions about Dominican Republic travel, bookings, or our services, just ask. Or tell me your route to get started with a transfer quote!",
          suggestions
        };
      }

      const data = await response.json();

      if (!data.response) {
        return {
          message: "I'd be happy to help! For questions about Dominican Republic travel, bookings, or our services, just ask. Or tell me your route to get started with a transfer quote!",
          suggestions
        };
      }

      this.conversationHistory.push(
        { role: 'user', content: userMessage },
        { role: 'assistant', content: data.response }
      );

      if (this.conversationHistory.length > 12) {
        this.conversationHistory = this.conversationHistory.slice(-8);
      }

      return {
        message: data.response,
        suggestions
      };
    } catch {
      return {
        message: "I'd be happy to help! For questions about Dominican Republic travel, bookings, or our services, just ask. Or tell me your route to get started with a transfer quote!",
        suggestions
      };
    }
  }

  getGreeting(): AgentResponse {
    return this.getWelcomeMessage();
  }

  resetContext(): void {
    this.context = { step: 'IDLE' };
    this.conversationHistory = [];
  }

  setContextForPriceScan(data: { airport: string; hotel: string; region: string; passengers: number; luggage: number }): void {
    this.context = {
      step: 'AWAITING_VEHICLE_SELECTION',
      airport: data.airport,
      hotel: data.hotel,
      region: data.region,
      passengers: data.passengers,
      suitcases: data.luggage
    };
  }
}
