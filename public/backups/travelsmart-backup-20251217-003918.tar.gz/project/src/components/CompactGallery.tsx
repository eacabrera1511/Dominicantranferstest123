import { useState, useEffect } from 'react';
import { Camera, MapPin, Users, Star, Play, Image as ImageIcon } from 'lucide-react';
import { supabase } from '../lib/supabase';

interface GalleryItem {
  id: string;
  title: string;
  description: string;
  media_url: string;
  media_type: 'photo' | 'video';
  category: 'fleet' | 'punta_cana' | 'drivers' | 'reviews' | 'general';
  display_order: number;
}

const categoryConfig = {
  fleet: {
    label: 'Fleet',
    icon: Camera,
    gradient: 'from-blue-500 to-cyan-500'
  },
  punta_cana: {
    label: 'Destinations',
    icon: MapPin,
    gradient: 'from-emerald-500 to-teal-500'
  },
  drivers: {
    label: 'Team',
    icon: Users,
    gradient: 'from-orange-500 to-amber-500'
  },
  reviews: {
    label: 'Reviews',
    icon: Star,
    gradient: 'from-pink-500 to-rose-500'
  },
  general: {
    label: 'Gallery',
    icon: Camera,
    gradient: 'from-violet-500 to-purple-500'
  }
};

interface CompactGalleryProps {
  onViewFull: () => void;
}

export function CompactGallery({ onViewFull }: CompactGalleryProps) {
  const [items, setItems] = useState<GalleryItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadGalleryItems();
  }, []);

  async function loadGalleryItems() {
    try {
      const { data, error } = await supabase
        .from('experience_gallery')
        .select('*')
        .eq('is_active', true)
        .order('display_order', { ascending: true })
        .limit(6);

      if (error) throw error;
      if (data) {
        setItems(data);
      }
    } catch (error) {
      console.error('Error loading gallery:', error);
    } finally {
      setLoading(false);
    }
  }

  if (loading) {
    return (
      <div className="w-full max-w-md mx-auto py-2">
        <div className="grid grid-cols-3 gap-1.5 animate-pulse">
          {[1, 2, 3].map((i) => (
            <div key={i} className="aspect-square bg-slate-200 dark:bg-slate-700 rounded-lg" />
          ))}
        </div>
      </div>
    );
  }

  if (items.length === 0) {
    return null;
  }

  return (
    <div className="w-full max-w-md mx-auto animate-fadeIn">
      <div className="bg-white/60 dark:bg-slate-800/60 backdrop-blur-xl border border-slate-200/50 dark:border-slate-700/50 rounded-xl p-3 hover:bg-white/80 dark:hover:bg-slate-800/80 transition-all duration-300 shadow-lg">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-1.5">
            <div className="w-6 h-6 rounded-lg bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center">
              <ImageIcon className="w-3 h-3 text-white" />
            </div>
            <div>
              <h3 className="text-xs font-semibold text-slate-900 dark:text-white">Gallery</h3>
              <p className="text-[10px] text-slate-500 dark:text-slate-400">Fleet & destinations</p>
            </div>
          </div>
          <button
            onClick={onViewFull}
            className="text-[10px] font-medium text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300 transition-colors px-2 py-1 rounded-lg hover:bg-blue-50 dark:hover:bg-blue-900/20"
          >
            View All
          </button>
        </div>

        <div className="grid grid-cols-3 gap-1.5">
          {items.map((item, index) => {
            const Icon = categoryConfig[item.category]?.icon || Camera;
            const gradient = categoryConfig[item.category]?.gradient || 'from-slate-500 to-slate-600';

            return (
              <div
                key={item.id}
                onClick={onViewFull}
                style={{ animationDelay: `${index * 50}ms` }}
                className="group relative aspect-square rounded-lg overflow-hidden cursor-pointer animate-scaleIn hover:scale-105 transition-transform duration-300 shadow-sm hover:shadow-md"
              >
                <img
                  src={item.media_url}
                  alt={item.title}
                  className="w-full h-full object-cover"
                  loading="lazy"
                />

                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <div className="absolute bottom-1 left-1 right-1">
                    <p className="text-white text-[10px] font-medium truncate">{item.title}</p>
                  </div>
                </div>

                {item.media_type === 'video' && (
                  <div className="absolute top-1 right-1">
                    <div className="p-1 bg-black/60 backdrop-blur-sm rounded-full">
                      <Play size={8} className="text-white fill-white" />
                    </div>
                  </div>
                )}

                <div className="absolute top-1 left-1 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <div className={`p-0.5 rounded-full bg-gradient-to-r ${gradient}`}>
                    <Icon className="w-2.5 h-2.5 text-white" />
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        <div className="mt-2 pt-2 border-t border-slate-200/50 dark:border-slate-700/50">
          <div className="flex items-center justify-center gap-1 text-[10px] text-slate-500 dark:text-slate-400">
            <Camera className="w-2.5 h-2.5" />
            <span>Premium service</span>
          </div>
        </div>
      </div>
    </div>
  );
}
